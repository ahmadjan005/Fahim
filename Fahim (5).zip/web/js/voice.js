/* الغرفة الصوتية في فهيم: اتصال صوتي مباشر بين الجوالات (WebRTC عبر PeerJS)
   - نظام الفرق: كل فريق يسمع نفسه فقط، وقائد الفريق يحوّل صوت فريقه "عاماً" فيسمعه الجميع.
   - بدون فرق: الجميع يسمع الجميع.
   - يبدأ الاستماع تلقائياً، والمايك مغلق حتى تضغط زر المايك. */
(function () {
  const V = { peer: null, pid: null, code: null, calls: {}, mic: null, micOn: false, silent: null, ac: null, spk: {}, an: {}, retry: {}, info: null, denied: false };
  const $ = s => document.querySelector(s);
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const vid = (code, id) => 'fahimv-' + code + '-' + id;

  function ctx() { if (!V.ac) { try { V.ac = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) { } } if (V.ac && V.ac.state === 'suspended') V.ac.resume().catch(() => { }); return V.ac; }
  // مسار صامت يُرسل بدل المايك حين يكون مغلقاً أو ممنوعاً عن مستمع معيّن
  function silentTrack() {
    if (V.silent && V.silent.readyState === 'live') return V.silent;
    const ac = ctx(); if (!ac) return null;
    const dst = ac.createMediaStreamDestination(); const o = ac.createOscillator(); const g = ac.createGain(); g.gain.value = 0; o.connect(g); g.connect(dst); o.start();
    V.silent = dst.stream.getAudioTracks()[0]; return V.silent;
  }

  // ---------- قواعد من يسمع من ----------
  const I = () => V.info || {};
  const teamOf = id => { const m = (I().members || []).find(x => x.id === id); return m ? m.team : null; };
  const pubT = t => t == null || !!(I().pub || {})[t];
  function canSend(to) { const i = I(); if (!i.teams) return true; const a = teamOf(V.pid), b = teamOf(to); return (a != null && a === b) || pubT(a); }
  function canHear(from) { const i = I(); if (!i.teams) return true; const a = teamOf(V.pid), b = teamOf(from); return (a != null && a === b) || (b != null && pubT(b)); }

  function route() {
    for (const id in V.calls) {
      const c = V.calls[id]; if (!c.call || !c.call.peerConnection) continue;
      const want = V.micOn && V.mic && canSend(id) ? V.mic : silentTrack();
      const snd = c.call.peerConnection.getSenders().find(s => s.track ? s.track.kind === 'audio' : true);
      if (snd && want && snd.track !== want) snd.replaceTrack(want).catch(() => { });
      if (c.el) c.el.muted = !canHear(id);
    }
    bar();
  }

  // ---------- الاتصالات ----------
  function stream() { const t = silentTrack(); return t ? new MediaStream([t]) : null; }
  function attach(id, call) {
    const old = V.calls[id]; if (old && old.call && old.call !== call) { try { old.call.close(); } catch (e) { } }
    const c = V.calls[id] = { call, el: null };
    call.on('stream', rs => {
      if (V.calls[id] !== c) return;
      if (!c.el) { c.el = document.createElement('audio'); c.el.autoplay = true; c.el.setAttribute('playsinline', ''); ($('#vaudio') || document.body).appendChild(c.el); }
      c.el.srcObject = rs; c.el.muted = !canHear(id); c.el.play().catch(() => { });
      meter(id, rs); route();
    });
    const drop = () => { if (V.calls[id] !== c) return; if (c.el) { c.el.srcObject = null; c.el.remove(); } delete V.calls[id]; delete V.an[id]; V.spk[id] = false; bar(); schedule(id); };
    call.on('close', drop); call.on('error', drop);
    setTimeout(() => { try { const pc = call.peerConnection; if (pc) pc.addEventListener('connectionstatechange', () => { if (['failed', 'closed'].includes(pc.connectionState)) drop(); }); } catch (e) { } }, 0);
  }
  function schedule(id) { clearTimeout(V.retry[id]); V.retry[id] = setTimeout(() => { if (V.peer && !V.calls[id]) dial(id); }, 3000); }
  function dial(id) {
    if (!V.peer || V.peer.disconnected || V.calls[id] || id === V.pid) return;
    // الطرف ذو المعرّف الأصغر هو من يتصل، لتفادي اتصالين مكررين
    if (!(V.pid < id)) return;
    const s = stream(); if (!s) return;
    let call; try { call = V.peer.call(vid(V.code, id), s); } catch (e) { return schedule(id); }
    if (!call) return schedule(id);
    attach(id, call);
    setTimeout(() => { const c = V.calls[id]; if (c && c.call === call && !c.el) { try { call.close(); } catch (e) { } } }, 15000);
  }
  function start(code, pid) {
    stop();
    V.code = code; V.pid = pid;
    const opts = window.FNET && FNET.peerOpts ? FNET.peerOpts() : {};
    let pr; try { pr = new Peer(vid(code, pid), opts); } catch (e) { return; }
    V.peer = pr;
    pr.on('open', () => { if (V.peer !== pr) return; mesh(); bar(); });
    pr.on('call', call => {
      const from = String(call.peer || '').replace(vid(code, ''), '');
      const s = stream(); if (!s) return;
      call.answer(s); attach(from, call); setTimeout(route, 300);
    });
    pr.on('disconnected', () => { if (V.peer === pr) setTimeout(() => { try { if (V.peer === pr && pr.disconnected && !pr.destroyed) pr.reconnect(); } catch (e) { } }, 1500); });
    pr.on('error', e => { if (V.peer !== pr) return; if (e.type === 'unavailable-id') setTimeout(() => { if (V.peer === pr) start(code, pid); }, 8000); else if (e.type === 'peer-unavailable') { /* الطرف الآخر لم يتصل بعد */ } });
    V.mt = setInterval(() => { mesh(); route(); }, 4000);
  }
  function stop() {
    clearInterval(V.mt);
    for (const id in V.calls) { const c = V.calls[id]; try { c.call.close(); } catch (e) { } if (c.el) c.el.remove(); }
    V.calls = {}; V.an = {}; V.spk = {}; for (const k in V.retry) clearTimeout(V.retry[k]); V.retry = {};
    try { V.peer && V.peer.destroy(); } catch (e) { } V.peer = null; V.code = null; V.pid = null;
  }
  function mesh() { if (!V.peer || !V.peer.open) return; (I().members || []).forEach(m => { if (m.id !== V.pid && !V.calls[m.id]) dial(m.id); }); for (const id in V.calls) if (!(I().members || []).some(m => m.id === id)) { try { V.calls[id].call.close(); } catch (e) { } } }

  // ---------- مؤشر من يتكلم ----------
  function meter(id, st) {
    const ac = ctx(); if (!ac) return;
    try { const src = ac.createMediaStreamSource(st); const an = ac.createAnalyser(); an.fftSize = 512; src.connect(an); V.an[id] = { an, buf: new Uint8Array(an.fftSize) }; } catch (e) { }
  }
  setInterval(() => {
    let ch = false;
    for (const id in V.an) {
      const { an, buf } = V.an[id]; an.getByteTimeDomainData(buf); let mx = 0; for (let i = 0; i < buf.length; i += 4) mx = Math.max(mx, Math.abs(buf[i] - 128));
      const on = mx > 10 && (id === V.pid ? V.micOn : canHear(id)); if (!!V.spk[id] !== on) { V.spk[id] = on; ch = true; }
    }
    if (ch) bar();
  }, 220);

  // ---------- المايك ----------
  async function micToggle() {
    ctx();
    if (V.micOn) { V.micOn = false; route(); return; }
    if (!V.mic || V.mic.readyState !== 'live') {
      try {
        const st = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true } });
        V.mic = st.getAudioTracks()[0]; V.denied = false; meter(V.pid, st);
        try { if (window.FahimAndroid && FahimAndroid.mic) FahimAndroid.mic(true); } catch (e) { }
      } catch (e) { V.denied = true; bar(); window.fahimToast && fahimToast('لم يُسمح باستخدام المايكروفون. فعّل الإذن من إعدادات الجوال ← التطبيقات ← فهيم ← الأذونات', 5000); return; }
    }
    V.micOn = true; route();
  }

  // ---------- الشريط العائم ----------
  function bar() {
    let b = $('#vbar'); const i = I();
    if (!i.on || !V.peer) { if (b) b.remove(); return; }
    if (!b) { b = document.createElement('div'); b.id = 'vbar'; document.body.appendChild(b); b.addEventListener('click', onClick); }
    const IC = window.ICON || {};
    const myT = teamOf(V.pid); const pub = pubT(myT); const canToggle = i.teams && myT != null && i.canPub;
    const talkers = Object.keys(V.spk).filter(k => V.spk[k]).map(k => k === V.pid ? 'أنت' : ((i.members || []).find(m => m.id === k) || {}).name).filter(Boolean);
    const n = Object.values(V.calls).filter(c => c.el).length;
    b.className = V.micOn ? 'live' : '';
    b.innerHTML = `<button class="vmic ${V.micOn ? 'on' : ''}" data-v="mic" aria-label="المايك">${V.micOn ? (IC.mic || '🎙') : (IC.micoff || '🔇')}</button>
      <div class="vinfo"><b>${i.teams ? (myT == null ? 'تسمع الفرق المفتوحة' : pub ? 'صوت فريقك: عام' : 'صوت فريقك: خاص') : 'الغرفة الصوتية'}</b><small>${talkers.length ? '🔊 ' + esc(talkers.join('، ')) : n ? 'متصل مع ' + n : 'جارٍ الاتصال…'}</small></div>
      ${canToggle ? `<button class="vpub ${pub ? 'on' : ''}" data-v="pub">${pub ? (IC.globe || '🌐') + ' عام' : (IC.lock || '🔒') + ' خاص'}</button>` : ''}`;
  }
  function onClick(e) {
    const t = e.target.closest('[data-v]'); if (!t) return;
    if (t.dataset.v === 'mic') micToggle();
    else if (t.dataset.v === 'pub') { const myT = teamOf(V.pid); window.fahimVoicePub && fahimVoicePub(myT, !pubT(myT)); }
  }

  // ---------- مزامنة مع حالة الغرفة ----------
  function sync() {
    const i = window.fahimVoiceInfo ? window.fahimVoiceInfo() : null; V.info = i;
    if (!i || !i.on || !i.code || !i.me) { if (V.peer) stop(); bar(); return; }
    if (!V.peer || V.code !== i.code || V.pid !== i.me) start(i.code, i.me);
    else { if (V.peer.destroyed) start(i.code, i.me); else mesh(); }
    route();
  }
  window.FVOICE = { sync, stop: () => { V.micOn = false; try { V.mic && V.mic.stop(); } catch (e) { } V.mic = null; stop(); bar(); }, revive: () => { if (V.peer && V.peer.disconnected && !V.peer.destroyed) { try { V.peer.reconnect(); } catch (e) { } } sync(); }, state: V };
})();
