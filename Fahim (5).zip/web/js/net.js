/* شبكة فهيم: اتصال مباشر (WebRTC عبر PeerJS + خوادم TURN) مع ترحيل احتياطي عبر MQTT فوق WSS
   - المعرّف المنطقي لكل لاعب (uid) ثابت على جهازه، فإعادة الاتصال تحفظ مقعده ونقاطه
   - المضيف يستمع على القناتين معاً، والعميل يجرب المباشر ثم الترحيل تلقائياً */
(function () {
  const NS = 'fahimq/v2/';
  const BROKERS = window.FAHIM_BROKERS || ['wss://broker.emqx.io:8084/mqtt', 'wss://broker.hivemq.com:8884/mqtt', 'wss://test.mosquitto.org:8081/mqtt'];
  const enc = new TextEncoder(), dec = new TextDecoder();

  // ---------- عميل MQTT 3.1.1 مصغّر (QoS 0) ----------
  function MQ(url, onMsg, onState) {
    this.url = url; this.onMsg = onMsg; this.onState = onState || (() => { }); this.subs = new Set(); this.ok = false; this.buf = new Uint8Array(0); this.closed = false;
    this.cid = 'fh' + Math.random().toString(36).slice(2, 12); this.lastRx = Date.now();
    this.open();
  }
  const str = s => { const b = enc.encode(s); const o = new Uint8Array(2 + b.length); o[0] = b.length >> 8; o[1] = b.length & 255; o.set(b, 2); return o; };
  const cat = (...a) => { const n = a.reduce((x, y) => x + y.length, 0); const o = new Uint8Array(n); let k = 0; a.forEach(x => { o.set(x, k); k += x.length; }); return o; };
  const remLen = n => { const o = []; do { let d = n % 128; n = Math.floor(n / 128); if (n > 0) d |= 128; o.push(d); } while (n > 0); return new Uint8Array(o); };
  const pkt = (h, body) => cat(new Uint8Array([h]), remLen(body.length), body);
  MQ.prototype.open = function () {
    let ws; try { ws = new WebSocket(this.url, ['mqtt']); } catch (e) { this.onState('fail'); return; }
    ws.binaryType = 'arraybuffer'; this.ws = ws;
    // مهلة الاتصال: إن لم يكتمل خلال 8 ثوانٍ نعتبره فاشلاً وننتقل
    this.ct = setTimeout(() => { if (!this.ok) { try { ws.close(); } catch (e) { } } }, 8000);
    ws.onopen = () => { const vh = cat(str('MQTT'), new Uint8Array([4, 2, 0, 180])); ws.send(pkt(0x10, cat(vh, str(this.cid)))); };
    ws.onmessage = e => { this.lastRx = Date.now(); this.buf = cat(this.buf, new Uint8Array(e.data)); this.parse(); };
    ws.onclose = () => { if (this.dead) return; this.dead = true; clearTimeout(this.ct); const was = this.ok; this.ok = false; clearInterval(this.pi); if (!this.closed) this.onState(was ? 'lost' : 'fail'); };
    ws.onerror = () => { };
  };
  MQ.prototype.parse = function () {
    for (; ;) {
      const b = this.buf; if (b.length < 2) return;
      let mul = 1, len = 0, i = 1, d;
      do { if (i >= b.length) return; d = b[i++]; len += (d & 127) * mul; mul *= 128; } while (d & 128);
      if (b.length < i + len) return;
      const type = b[0] >> 4, body = b.subarray(i, i + len); this.buf = b.slice(i + len);
      if (type === 2) { if (body[1] === 0) { this.ok = true; this.subs.forEach(t => this._sub(t)); clearTimeout(this.ct); this.pi = setInterval(() => { try { this.ws.send(new Uint8Array([0xC0, 0])); } catch (e) { } if (Date.now() - this.lastRx > 45000) this.kill(); }, 15000); this.onState('ok'); } else this.onState('fail'); }
      else if (type === 3) { const tl = (body[0] << 8) | body[1]; const topic = dec.decode(body.subarray(2, 2 + tl)); const qos = (b[0] >> 1) & 3; const off = 2 + tl + (qos ? 2 : 0); try { this.onMsg(topic, JSON.parse(dec.decode(body.subarray(off)))); } catch (e) { } }
    }
  };
  MQ.prototype._sub = function (t) { const id = 1 + Math.floor(Math.random() * 60000); try { this.ws.send(pkt(0x82, cat(new Uint8Array([id >> 8, id & 255]), str(t), new Uint8Array([0])))); } catch (e) { } };
  MQ.prototype.sub = function (t) { this.subs.add(t); if (this.ok) this._sub(t); };
  MQ.prototype.pub = function (t, obj) { if (!this.ok) return false; try { this.ws.send(pkt(0x30, cat(str(t), enc.encode(JSON.stringify(obj))))); return true; } catch (e) { return false; } };
  // قتل الاتصال الميت فوراً (بعد العودة من الخلفية أو تغيّر الشبكة) ليعاد فتحه
  MQ.prototype.kill = function () { try { this.ws.onclose && this.ws.onclose(); this.ws.close(); } catch (e) { } };
  MQ.prototype.close = function () { this.closed = true; clearInterval(this.pi); try { this.ws.send(new Uint8Array([0xE0, 0])); this.ws.close(); } catch (e) { } };
  // ترحيل عبر كل الوسطاء بالتوازي: لو سقط أحدها يبقى الآخران، ولا يمكن أن يفترق المضيف والعميل على وسطاء مختلفين
  function relay(onMsg, onState) {
    const R = { ms: [], subs: [], closed: false, state: 'connecting' };
    const upd = () => { const ok = R.ms.some(x => x.m && x.m.ok); const st = ok ? 'ok' : 'down'; if (st !== R.state) { R.state = st; onState(st); } else if (ok) onState('ok+'); };
    BROKERS.forEach((url, k) => {
      const slot = { m: null, fails: 0, tm: null };
      const open = () => {
        if (R.closed) return; clearTimeout(slot.tm);
        slot.m = new MQ(url, onMsg, st => {
          if (R.closed) return;
          if (st === 'ok') { slot.fails = 0; upd(); }
          else { slot.fails++; upd(); slot.tm = setTimeout(open, Math.min(8000, st === 'lost' ? 300 : 600 * slot.fails)); }
        });
        R.subs.forEach(t => slot.m.sub(t));
      };
      slot.open = open; R.ms.push(slot); open();
    });
    R.sub = t => { R.subs.push(t); R.ms.forEach(x => x.m && x.m.sub(t)); };
    R.pub = (t, o) => { let any = false; R.ms.forEach(x => { if (x.m && x.m.pub(t, o)) any = true; }); return any; };
    // إعادة فتح فورية لكل اتصال قديم أو ساكن
    R.kick = (force) => { R.ms.forEach(x => { if (!x.m) return; if (force || !x.m.ok || Date.now() - x.m.lastRx > 6000) { x.fails = 0; const old = x.m; x.m = null; old.closed = true; try { old.ws.close(); } catch (e) { } clearTimeout(old.ct); clearInterval(old.pi); x.open(); } }); };
    R.close = () => { R.closed = true; R.ms.forEach(x => { clearTimeout(x.tm); x.m && x.m.close(); }); };
    return R;
  }
  // منع تكرار الرسالة نفسها القادمة من أكثر من طريق (مباشر + عدة وسطاء)
  function Dedup() { const seen = new Set(), q = []; return m => { if (!m || !m._i) return true; if (seen.has(m._i)) return false; seen.add(m._i); q.push(m._i); if (q.length > 600) seen.delete(q.shift()); return true; }; }
  const mid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);

  // ---------- إعدادات ICE ----------
  function iceServers() {
    let custom = [];
    try { const c = JSON.parse(localStorage.getItem('fahim_turn') || 'null'); if (c) { if (Array.isArray(c.json)) custom = c.json; else if (c.url) custom = [{ urls: c.url.split(/[\s,]+/).filter(Boolean), username: c.user || undefined, credential: c.pass || undefined }]; } } catch (e) { }
    return custom.concat([
      { urls: ['stun:stun.l.google.com:19302', 'stun:stun1.l.google.com:19302', 'stun:stun.cloudflare.com:3478'] },
      { urls: 'turn:openrelay.metered.ca:80', username: 'openrelayproject', credential: 'openrelayproject' },
      { urls: 'turn:openrelay.metered.ca:443', username: 'openrelayproject', credential: 'openrelayproject' },
      { urls: 'turn:openrelay.metered.ca:443?transport=tcp', username: 'openrelayproject', credential: 'openrelayproject' },
      { urls: 'turns:openrelay.metered.ca:443?transport=tcp', username: 'openrelayproject', credential: 'openrelayproject' }
    ]);
  }
  const forceRelay = () => { try { return (JSON.parse(localStorage.getItem('fahim_turn') || '{}') || {}).relayOnly; } catch (e) { return false; } };
  const peerOpts = () => Object.assign({ debug: 0, config: { iceServers: window.FAHIM_PEER ? [] : iceServers(), iceTransportPolicy: 'all' } }, window.FAHIM_PEER || {});

  // ---------- المضيف ----------
  // cb.onOpen(code) cb.onMsg(uid, msg) cb.onPresence(uid, online, via) cb.onStatus(H)
  // fixedCode: لاستئناف غرفة سابقة بنفس الرمز بعد إعادة فتح التطبيق
  function Host(cb, fixedCode) {
    const H = { peers: {}, last: {}, via: {}, code: null, rl: null, peer: null, p2p: false, relayOk: false, closed: false };
    const code = fixedCode && /^\d{4}$/.test(fixedCode) ? fixedCode : String(1000 + Math.floor(Math.random() * 9000));
    H.code = code;
    const fresh = Dedup();
    const deliver = (uid, msg, via, conn) => {
      if (!uid || H.closed || !fresh(msg)) return;
      H.last[uid] = Date.now();
      if (via === 'p2p' && conn) { H.peers[uid] = conn; H.via[uid] = 'p2p'; }
      else if (!(H.peers[uid] && H.peers[uid].open)) H.via[uid] = 'relay';
      if (!H['on_' + uid] || H['pv_' + uid] !== H.via[uid]) { H['on_' + uid] = true; H['pv_' + uid] = H.via[uid]; cb.onPresence(uid, true, H.via[uid]); }
      if (msg.t !== 'hb') cb.onMsg(uid, msg);
    };
    // القناة المباشرة
    const startPeer = () => {
      if (H.closed || forceRelay()) return;
      try { H.peer && H.peer.destroy(); } catch (e) { }
      let pr; try { pr = new Peer('fahim-' + code, peerOpts()); } catch (e) { return; }
      H.peer = pr;
      pr.on('open', () => { if (H.peer !== pr) return; H.p2p = true; cb.onStatus && cb.onStatus(H); });
      pr.on('error', e => {
        if (H.peer !== pr) return;
        // الرمز ما زال محجوزاً من جلسة سابقة: نعمل بالترحيل ونعيد المحاولة حتى يتحرر
        if (e.type === 'unavailable-id') { H.p2p = false; clearTimeout(H.pt); H.pt = setTimeout(startPeer, 12000); }
        else if (['network', 'server-error', 'socket-error', 'socket-closed', 'disconnected'].includes(e.type)) { H.p2p = false; cb.onStatus && cb.onStatus(H); clearTimeout(H.pt); H.pt = setTimeout(fixPeer, 2500); }
      });
      pr.on('disconnected', () => { if (H.peer !== pr) return; H.p2p = false; cb.onStatus && cb.onStatus(H); clearTimeout(H.pt); H.pt = setTimeout(fixPeer, 1500); });
      pr.on('close', () => { if (H.peer !== pr || H.closed) return; H.p2p = false; clearTimeout(H.pt); H.pt = setTimeout(startPeer, 3000); });
      pr.on('connection', c => {
        let uid = null;
        c.on('data', m => { if (m && m.uid) uid = m.uid; deliver(uid, m, 'p2p', c); });
        c.on('close', () => { if (uid && H.peers[uid] === c) { delete H.peers[uid]; if (H.via[uid] === 'p2p') H.via[uid] = 'relay'; } });
        c.on('error', () => { });
      });
    };
    const fixPeer = () => {
      if (H.closed || forceRelay()) return;
      const pr = H.peer;
      if (!pr || pr.destroyed) return startPeer();
      if (pr.disconnected) { try { pr.reconnect(); } catch (e) { startPeer(); } }
    };
    startPeer();
    // قناة الترحيل (كل الوسطاء معاً)
    H.rl = relay((topic, m) => { if (m && m.uid) deliver(m.uid, m, 'relay'); }, st => { H.relayOk = H.rl ? H.rl.state === 'ok' : st === 'ok'; cb.onStatus && cb.onStatus(H); });
    H.rl.sub(NS + code + '/h');
    setTimeout(() => cb.onOpen(code), 50);
    // مراقبة الحضور: 12 ثانية بلا أي رسالة = منقطع (مقعده محفوظ)
    H.watch = setInterval(() => {
      if (H.closed) return;
      const t = Date.now();
      for (const uid in H.last) { const on = t - H.last[uid] < 12000; if (on !== !!H['on_' + uid]) { H['on_' + uid] = on; cb.onPresence(uid, on, H.via[uid]); } }
      H.bcast({ t: 'ping' });
    }, 2500);
    H.send = (uid, m) => {
      if (H.closed) return; m._i = m._i || mid();
      const c = H.peers[uid];
      let sent = false;
      if (H.via[uid] === 'p2p' && c && c.open) { try { c.send(m); sent = true; } catch (e) { } }
      // الرسائل المهمة (الترحيب) تُرسل من الطريقين لضمان الوصول
      if (!sent || m.t === 'hello') H.rl.pub(NS + code + '/c/' + uid, m);
    };
    H.bcast = (m) => {
      if (H.closed) return; m._i = mid();
      let anyRelay = false;
      for (const uid in H.last) { if (H.via[uid] === 'p2p' && H.peers[uid] && H.peers[uid].open) { try { H.peers[uid].send(m); } catch (e) { anyRelay = true; } } else anyRelay = true; }
      // الحالة تُرسل دائماً عبر الترحيل أيضاً: من فقد الاتصال المباشر بصمت يبقى متابعاً
      if (anyRelay || m.t === 'state' || m.t === 'lobby') H.rl.pub(NS + code + '/b', m);
    };
    // عند العودة للتطبيق أو تغيّر الشبكة: إنعاش كل القنوات فوراً
    H.kick = () => { if (H.closed) return; H.rl.kick(); fixPeer(); };
    H.drop = uid => { delete H.last[uid]; delete H.via[uid]; delete H.peers[uid]; delete H['on_' + uid]; };
    H.close = () => { H.closed = true; clearInterval(H.watch); clearTimeout(H.pt); try { H.peer && H.peer.destroy(); } catch (e) { } H.rl && H.rl.close(); };
    return H;
  }

  // ---------- العميل ----------
  // cb.onMsg(msg) cb.onLink(state: 'p2p'|'relay'|'connecting'|'lost') cb.onFail(text)
  // لا يستسلم أبداً: يبقى يحاول حتى يغلقه المستخدم بنفسه
  function Client(code, uid, hello, cb) {
    const C = { via: null, conn: null, rl: null, peer: null, lastHost: 0, closed: false, gotHello: false, tries: 0 };
    const fresh = Dedup();
    const setVia = v => { if (C.via !== v) { C.via = v; cb.onLink(v || 'lost'); } };
    const got = (m, via) => {
      if (C.closed || !fresh(m)) return;
      C.lastHost = Date.now();
      if (!C.via || (via === 'p2p' && C.via !== 'p2p') || (via === 'relay' && C.via === 'p2p' && !(C.conn && C.conn.open))) setVia(via);
      if (m.t === 'hello') { C.gotHello = true; clearTimeout(C.fail); }
      if (m.t !== 'ping') cb.onMsg(m);
    };
    const sendJoin = () => {
      if (C.closed) return;
      const m = Object.assign({ t: 'join', uid, _i: mid() }, hello);
      if (C.conn && C.conn.open) try { C.conn.send(m); } catch (e) { }
      C.rl && C.rl.pub(NS + code + '/h', m);
    };
    // الترحيل يبدأ فوراً بالتوازي على كل الوسطاء
    C.rl = relay((topic, m) => got(m, 'relay'), st => { if (st === 'ok' || st === 'ok+') sendJoin(); });
    C.rl.sub(NS + code + '/b'); C.rl.sub(NS + code + '/c/' + uid);
    const startP2P = () => {
      if (C.closed || forceRelay()) return;
      clearTimeout(C.pt);
      try { C.peer && C.peer.destroy(); } catch (e) { }
      C.conn = null;
      let pr; try { pr = new Peer(peerOpts()); } catch (e) { C.pt = setTimeout(startP2P, 5000); return; }
      C.peer = pr;
      pr.on('open', () => {
        if (C.peer !== pr) return;
        const c = pr.connect('fahim-' + code, { reliable: true }); C.conn = c;
        // إن لم يُفتح المسار المباشر خلال 12 ثانية نعيد المحاولة لاحقاً (الترحيل يعمل بالتوازي)
        const to = setTimeout(() => { if (C.conn === c && !c.open) { C.pt = setTimeout(startP2P, 6000); } }, 12000);
        c.on('open', () => { clearTimeout(to); try { c.send(Object.assign({ t: 'join', uid, _i: mid() }, hello)); } catch (e) { } });
        c.on('data', m => got(m, 'p2p'));
        c.on('error', () => { });
        c.on('close', () => {
          clearTimeout(to);
          if (C.conn !== c) return; C.conn = null;
          if (C.via === 'p2p') { setVia(C.rl && C.rl.state === 'ok' ? 'relay' : null); sendJoin(); }
          if (!C.closed) C.pt = setTimeout(startP2P, 3000);
        });
      });
      pr.on('error', e => { if (C.peer !== pr) return; clearTimeout(C.pt); C.pt = setTimeout(startP2P, e.type === 'peer-unavailable' ? 6000 : 3000); });
      pr.on('disconnected', () => { if (C.peer !== pr || C.closed) return; try { pr.reconnect(); } catch (e) { } });
    };
    startP2P();
    C.send = m => {
      if (C.closed) return;
      m.uid = uid; m._i = mid();
      if (C.via === 'p2p' && C.conn && C.conn.open) { try { C.conn.send(m); return; } catch (e) { } }
      C.rl.pub(NS + code + '/h', m);
    };
    // إنعاش فوري: بعد العودة من الخلفية أو رجوع النت
    C.kick = (force) => {
      if (C.closed) return;
      const age = Date.now() - C.lastHost;
      if (force || !C.lastHost || age > 3500) {
        C.rl.kick(force);
        if (!(C.conn && C.conn.open) || force) startP2P();
        sendJoin();
      }
    };
    // نبض + اكتشاف الانقطاع + إعادة الاتصال
    C.hb = setInterval(() => {
      if (C.closed) return;
      C.send({ t: 'hb' });
      const age = Date.now() - C.lastHost;
      if (C.lastHost && age > 8000 && C.via) setVia(null);
      if (!C.lastHost || age > 6000) { sendJoin(); C.tries++; if (C.tries % 4 === 0) C.rl.kick(); }
      else C.tries = 0;
    }, 2500);
    C.fail = setTimeout(() => { if (!C.gotHello && !C.closed) cb.onFail('لم نصل للغرفة ' + code + ' بعد. تأكد من الرمز ومن أن المضيف ما زال في الغرفة — نستمر في المحاولة تلقائياً.'); }, 15000);
    C.close = () => { C.closed = true; clearInterval(C.hb); clearTimeout(C.fail); clearTimeout(C.pt); try { C.peer && C.peer.destroy(); } catch (e) { } C.rl && C.rl.close(); };
    return C;
  }
  window.FNET = { Host, Client, iceServers, BROKERS, peerOpts };
})();
