/* بنك الأسئلة: التحليل + المولّدات + الاختيار */
(function () {
  const QB = {
    cats: {}, mcq: [], who: [], lists: [], orders: [], gens: [], emoji: [], near: [], hex: [], chain: [],
    order: []
  };
  window.QB = QB;

  // ---------- أدوات ----------
  const rnd = (n) => Math.floor(Math.random() * n);
  const pick = (a) => a[rnd(a.length)];
  const shuffle = (a) => { a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = rnd(i + 1); [a[i], a[j]] = [a[j], a[i]]; } return a; };
  QB.rnd = rnd; QB.pick = pick; QB.shuffle = shuffle;

  function hash(s) { let h = 5381; for (let i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) | 0; return (h >>> 0).toString(36); }
  QB.hash = hash;
  // مولد عشوائي ثابت حسب البذرة: نفس السؤال = نفس الخيارات دائماً
  function seeded(seed) { let h = (parseInt(hash(String(seed)), 36) | 0) || 7; return () => { h ^= h << 13; h ^= h >>> 17; h ^= h << 5; return ((h >>> 0) % 1000003) / 1000003; }; }
  function sshuffle(a, r) { a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; }
  QB.seeded = seeded; QB.sshuffle = sshuffle;
  // نص الخيار للعرض: بدون الشروح بين الأقواس
  const show = v => String(v).replace(/\s*[(（][^)）]*[)）]\s*/g, ' ').replace(/\s+/g, ' ').trim() || String(v);
  QB.show = show;

  // ---------- مطابقة الإجابات المكتوبة (مرنة) ----------
  const DIAC = /[ً-ٰٟـۖ-ۭ]/g;
  QB.norm = function (s) {
    s = String(s || '').toLowerCase().replace(DIAC, '');
    s = s.replace(/[أإآٱ]/g, 'ا').replace(/ة/g, 'ه').replace(/ى/g, 'ي').replace(/ؤ/g, 'و').replace(/ئ/g, 'ي').replace(/ء/g, '');
    s = s.replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d));
    s = s.replace(/[^ا-يa-z0-9 ]/g, ' ');
    s = s.split(/\s+/).filter(Boolean).map(w => (w.length > 3 && w.startsWith('ال')) ? w.slice(2) : ((w.length > 4 && /^(وال|بال|فال|كال)/.test(w)) ? w.slice(3) : w)).join(' ');
    return s;
  };
  // تقريب صوتي: الحروف المتشابهة نطقاً حرف واحد
  const PHO = { 'ص': 'س', 'ش': 'س', 'ث': 'س', 'ط': 'ت', 'ظ': 'ز', 'ذ': 'ز', 'ض': 'ز', 'ق': 'ك', 'ح': 'ه', 'غ': 'خ', 'ع': 'ا' };
  const pho = s => s.replace(/[صشثطظذضقحغع]/g, c => PHO[c]).replace(/(.)\1+/g, '$1');
  const flat = s => s.replace(/ /g, '');
  function lev(a, b, max) {
    if (Math.abs(a.length - b.length) > max) return max + 1;
    let pp = null, prev = Array.from({ length: b.length + 1 }, (_, j) => j);
    for (let i = 1; i <= a.length; i++) {
      const cur = [i]; let best = i;
      for (let j = 1; j <= b.length; j++) {
        cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
        if (pp && j > 1 && a[i - 1] === b[j - 2] && a[i - 2] === b[j - 1]) cur[j] = Math.min(cur[j], pp[j - 2] + 1); // تبديل حرفين متجاورين
        if (cur[j] < best) best = cur[j];
      }
      if (best > max) return max + 1;
      pp = prev; prev = cur;
    }
    return prev[b.length];
  }
  const tolFor = n => n <= 3 ? 0 : n <= 5 ? 1 : n <= 8 ? 2 : 3;
  const STOP = new Set(['بن', 'ابن', 'ابو', 'ابي', 'عبد', 'ام', 'بنت', 'دي', 'فان', 'فون', 'de', 'the', 'of', 'and', 'سان']);
  // مسافة الإجابة من البديل (كلما قلّت كان أقرب)، أو null إذا غير مقبولة
  QB.dist = function (input, alias) {
    const x = QB.norm(input), y = QB.norm(alias); if (!x || !y) return null;
    const fx = flat(x), fy = flat(y);
    if (fx === fy) return 0;
    const px = pho(fx), py = pho(fy);
    if (px === py) return 0.3;
    const t = tolFor(py.length);
    const d = lev(px, py, t);
    if (d <= t) return d;
    // الجزء المميز من الأسماء الطويلة: "رونالدو" تكفي لـ"كريستيانو رونالدو"
    const words = y.split(' ').filter(w => w.length >= 4 && !STOP.has(w));
    if (words.length >= 2 && fx.length >= 4) {
      for (const w of words) {
        const pw = pho(w), tw = tolFor(pw.length);
        if (lev(px, pw, tw) <= tw) return 1.5 + lev(px, pw, tw);
      }
    }
    // كتب الاسم كاملاً والمطلوب جزء منه أو العكس
    if (px.length >= 5 && py.length >= 5 && (py.includes(px) && px.length >= py.length * .6 || px.includes(py) && py.length >= px.length * .6)) return 2;
    return null;
  };
  QB.match = function (input, aliases) {
    for (const al of aliases) if (QB.dist(input, al) !== null) return true;
    return false;
  };
  // أقرب عنصر في قائمة (لتفادي احتساب إجابة لعنصر آخر قريب منها): items = [[alias...], ...]
  QB.bestMatch = function (input, items, skip) {
    if (Array.isArray(skip)) skip = new Set(skip);
    let best = -1, bd = 99;
    items.forEach((al, i) => {
      for (const a of al) { const d = QB.dist(input, a); if (d !== null && d < bd) { bd = d; best = i; } }
    });
    if (best >= 0 && skip && skip.has(best)) {
      // الأقرب مُستخدم؛ هل يوجد عنصر آخر مطابق تماماً تقريباً؟
      let alt = -1, ad = 99;
      items.forEach((al, i) => { if (skip.has(i)) return; for (const a of al) { const d = QB.dist(input, a); if (d !== null && d <= 0.3 && d < ad) { ad = d; alt = i; } } });
      return alt >= 0 ? alt : { dup: best };
    }
    return best;
  };

  // ---------- الفئات ----------
  QB.cat = function (id, name, icon, group) { QB.cats[id] = { id, name, icon, group, n: 0 }; QB.order.push(id); };

  // ---------- أسئلة مكتوبة ----------
  // الصيغة: مستوى|السؤال|الصحيح|خطأ1|خطأ2|خطأ3   ## معلومة "هل تعلم" اختيارية
  function splitInfo(line) { const k = line.indexOf(' ## '); return k < 0 ? [line, ''] : [line.slice(0, k), line.slice(k + 4).trim()]; }
  QB.add = function (cat, text) {
    for (let line of text.split('\n')) {
      line = line.trim(); if (!line || line.startsWith('#')) continue;
      const [body, info] = splitInfo(line);
      const p = body.split('|').map(s => s.trim());
      if (p.length < 5) continue;
      const l = Math.min(4, Math.max(1, +p[0] || 2));
      const q = { id: hash(cat + p[1]), c: cat, l, q: p[1], a: p[2], w: p.slice(3).filter(Boolean).slice(0, 3) };
      if (info) q.i = info;
      if (q.w.length >= 2) QB.mcq.push(q);
    }
  };
  // من أنا: مستوى|الإجابة/بديل/بديل|تلميح1;تلميح2;تلميح3;تلميح4
  QB.addWho = function (cat, text) {
    for (let line of text.split('\n')) {
      line = line.trim(); if (!line || line.startsWith('#')) continue;
      const p = line.split('|').map(s => s.trim()); if (p.length < 3) continue;
      const al = p[1].split('/').map(s => s.trim());
      QB.who.push({ id: hash('w' + p[1]), c: cat, l: +p[0] || 2, a: al[0], al, clues: p[2].split(';').map(s => s.trim()).filter(Boolean) });
    }
  };
  // قوائم (ماذا تعرف/المزاد): مستوى|الموضوع|عنصر/بديل،عنصر،...
  QB.addList = function (cat, text) {
    for (let line of text.split('\n')) {
      line = line.trim(); if (!line || line.startsWith('#')) continue;
      const p = line.split('|').map(s => s.trim()); if (p.length < 3) continue;
      const items = p[2].split(/[،,]/).map(s => s.trim()).filter(Boolean).map(s => s.split('/').map(x => x.trim()));
      QB.lists.push({ id: hash('l' + p[1]), c: cat, l: +p[0] || 2, t: p[1], items });
    }
  };
  QB.addListRaw = function (cat, l, t, items) { QB.lists.push({ id: hash('l' + t), c: cat, l, t, items }); };
  // ترتيب: مستوى|السؤال|عنصر:قيمة،عنصر:قيمة ...
  QB.addOrder = function (cat, text) {
    for (let line of text.split('\n')) {
      line = line.trim(); if (!line || line.startsWith('#')) continue;
      const p = line.split('|').map(s => s.trim()); if (p.length < 3) continue;
      const items = p[2].split('،').map(s => { const [k, v] = s.split(':'); return { k: k.trim(), v: parseFloat(v) }; });
      QB.orders.push({ id: hash('o' + p[1] + p[2]), c: cat, l: +p[0] || 2, q: p[1], items });
    }
  };
  QB.orderPools = [];
  QB.addOrderPool = function (cat, l, q, items, unit) { QB.orderPools.push({ c: cat, l, q, items, unit }); };

  // صورة وتخمين: مستوى|الرموز|الإجابة/بديل|نوع|خطأ1;خطأ2;خطأ3
  QB.addEmoji = function (cat, text) {
    for (let line of text.split('\n')) {
      line = line.trim(); if (!line || line.startsWith('#')) continue;
      const p = line.split('|').map(s => s.trim()); if (p.length < 4) continue;
      const al = p[2].split('/').map(s => s.trim());
      QB.emoji.push({ id: hash('e' + p[1] + p[2]), c: cat, l: +p[0] || 2, e: p[1], a: al[0], al, t: p[3], w: (p[4] || '').split(';').map(s => s.trim()).filter(Boolean) });
    }
  };
  // الأقرب يربح: مستوى|السؤال|الرقم|الوحدة  ## معلومة
  QB.addNear = function (cat, text) {
    for (let line of text.split('\n')) {
      line = line.trim(); if (!line || line.startsWith('#')) continue;
      const [body, info] = splitInfo(line);
      const p = body.split('|').map(s => s.trim()); if (p.length < 3) continue;
      const v = parseFloat(p[2].replace(/[,٬]/g, '')); if (isNaN(v)) continue;
      QB.near.push({ id: hash('n' + p[1]), c: cat, l: +p[0] || 2, q: p[1], v, u: p[3] || '', i: info });
    }
  };
  // خلية الحروف: الحرف|مستوى|السؤال|الإجابة/بديل
  QB.addHex = function (cat, text) {
    for (let line of text.split('\n')) {
      line = line.trim(); if (!line || line.startsWith('#')) continue;
      const p = line.split('|').map(s => s.trim()); if (p.length < 4) continue;
      const al = p[3].split('/').map(s => s.trim());
      QB.hex.push({ id: hash('h' + p[2]), c: cat, ch: p[0], l: +p[1] || 2, q: p[2], a: al[0], al });
    }
  };
  // السلسلة: مستوى|الموضوع|عنصر/بديل،عنصر... (القائمة الكاملة للتحقق)
  QB.addChain = function (cat, text) {
    for (let line of text.split('\n')) {
      line = line.trim(); if (!line || line.startsWith('#')) continue;
      const p = line.split('|').map(s => s.trim()); if (p.length < 3) continue;
      const seen = new Set(); const items = p[2].split('،').map(s => s.trim()).filter(Boolean).map(s => s.split('/').map(x => x.trim()).filter(Boolean)).filter(a => { const k = a.map(x => QB.norm(x)); if (k.some(x => seen.has(x))) return false; k.forEach(x => seen.add(x)); return true; });
      QB.chain.push({ id: hash('c' + p[1]), c: cat, l: +p[0] || 2, t: p[1], items });
    }
  };

  // ---------- اختيار المشتتات الذكي ----------
  const isNum = v => /^-?\d+(\.\d+)?$/.test(String(v).trim());
  const tokens = s => new Set(QB.norm(s).split(' ').filter(w => w.length > 1));
  function simWords(a, b) { const A = tokens(a), B = tokens(b); let n = 0; for (const x of A) if (B.has(x)) n++; return n / Math.max(1, Math.min(A.size, B.size)); }
  // أرقام قريبة ومحيرة
  function closeNums(a, r, pool, yearLike) {
    a = +a; const out = new Set();
    const cand = (pool || []).filter(v => isNum(v) && +v !== a).map(Number).sort((x, y) => Math.abs(x - a) - Math.abs(y - a));
    const span = yearLike ? 6 : Math.max(2, Math.round(Math.abs(a) * .12));
    // من القيم الحقيقية القريبة أولاً
    for (const v of cand.slice(0, 5)) if (Math.abs(v - a) <= span * 2 && out.size < 2 && r() < .8) out.add(v);
    let t = 0;
    while (out.size < 3 && t++ < 80) {
      const d = (r() < .5 ? -1 : 1) * (1 + Math.floor(r() * span));
      const v = a + d; if (v !== a && v > 0 && !out.has(v)) out.add(v);
    }
    return [...out].slice(0, 3).map(String);
  }
  QB.closeNums = closeNums;
  // يختار 3 مشتتات من نفس النوع والسياق
  function smartW(rows, i, getV, r, fwdQ) {
    const me = rows[i], a = getV(me);
    if (me.w && me.w.length >= 3) return me.w.slice(0, 3);
    const vals = rows.map(getV);
    if (isNum(a) && vals.filter(isNum).length >= vals.length * .8) return closeNums(a, r, vals, /عام|سنة|year/i.test(fwdQ || '') && +a > 30 && +a < 2100);
    const seenV = new Set([QB.norm(show(a))]);
    const cands = [];
    rows.forEach((x, j) => {
      const v = getV(x); const nv = QB.norm(show(v));
      if (j === i || seenV.has(nv)) return; seenV.add(nv);
      let s = Math.abs(j - i) / rows.length * 3;                       // القرب في القائمة (نفس العصر/الموضوع)
      if (me.g && x.g) s += me.g === x.g ? -2 : 1.5;                    // نفس المجموعة
      s += Math.abs(Math.abs(x.l - me.l)) * .35;                        // صعوبة متقاربة = شهرة متقاربة
      const la = show(a).length, lb = show(v).length;
      s += Math.abs(la - lb) / Math.max(la, lb) * .8;                   // طول متقارب
      const wa = show(a).trim().split(/\s+/).length, wb = show(v).trim().split(/\s+/).length;
      s += Math.min(2, Math.abs(wa - wb)) * .9;                         // عدد كلمات متقارب
      s -= simWords(a, v) * .6;                                         // كلمات مشتركة (نفس الصيغة)
      s += r() * .5;
      cands.push({ v, s });
    });
    cands.sort((x, y) => x.s - y.s);
    return cands.slice(0, 3).map(x => x.v);
  }
  QB.smartW = smartW;

  // ---------- مولّد الأزواج ----------
  // كل سطر: مستوى|المفتاح|القيمة[|مجموعة][|خطأ1;خطأ2;خطأ3]  ## معلومة
  QB.parseRows = function (text) {
    const rows = [];
    for (let line of text.split('\n')) {
      line = line.trim(); if (!line || line.startsWith('#')) continue;
      const [body, info] = splitInfo(line);
      const p = body.split('|').map(s => s.trim()); if (p.length < 3) continue;
      const r = { l: +p[0] || 2, k: p[1], v: p[2] };
      for (const extra of p.slice(3)) { if (extra.includes(';')) r.w = extra.split(';').map(s => s.trim()).filter(Boolean); else if (extra) r.g = extra; }
      if (info) r.i = info;
      rows.push(r);
    }
    return rows;
  };
  QB.addPairs = function (cat, fwd, rev, text, opts) {
    const rows = QB.parseRows(text);
    QB.addPairRows(cat, fwd, rev, rows, opts);
    return rows;
  };
  QB.addPairRows = function (cat, fwd, rev, rows, opts) {
    opts = opts || {};
    rows.forEach((r, i) => {
      if (fwd) {
        const id = hash(cat + fwd + r.k);
        const w = smartW(rows, i, x => x.v, seeded(id), fwd);
        const lv = r.lf || Math.min(4, Math.max(1, r.l + (opts.fl || 0)));
        if (w.length === 3) QB.mcq.push({ id, c: cat, l: lv, q: fwd.replace('{k}', r.k), a: r.v, w, gen: 1, i: r.i });
      }
      if (rev && !r.norev && rows.filter(x => QB.norm(show(x.v)) === QB.norm(show(r.v))).length === 1) {
        const id = hash(cat + rev + r.v);
        const rr = rows.map(x => ({ ...x, w: null }));
        const w = smartW(rr, i, x => x.k, seeded(id), rev);
        const lv = r.lr || Math.min(4, Math.max(1, r.l + (opts.rl || 0)));
        if (w.length === 3) QB.mcq.push({ id, c: cat, l: lv, q: rev.replace('{v}', show(r.v)), a: r.k, w, gen: 1, i: r.i });
      }
    });
  };

  // ---------- مولّد الرياضيات (لا نهائي) ----------
  QB.mathQ = function (l) {
    let q, a;
    if (l === 1) { const x = 2 + rnd(30), y = 2 + rnd(30); if (Math.random() < .5) { q = `${x} + ${y} = ؟`; a = x + y; } else { const m = Math.max(x, y), n = Math.min(x, y); q = `${m} − ${n} = ؟`; a = m - n; } }
    else if (l === 2) { const t = rnd(3); if (t === 0) { const x = 3 + rnd(10), y = 3 + rnd(10); q = `${x} × ${y} = ؟`; a = x * y; } else if (t === 1) { const y = 2 + rnd(9), a0 = 2 + rnd(12); q = `${a0 * y} ÷ ${y} = ؟`; a = a0; } else { const x = 10 + rnd(90), y = 10 + rnd(90), z = 2 + rnd(20); q = `${x} + ${y} − ${z} = ؟`; a = x + y - z; } }
    else if (l === 3) { const t = rnd(4); if (t === 0) { const x = 11 + rnd(15), y = 11 + rnd(15); q = `${x} × ${y} = ؟`; a = x * y; } else if (t === 1) { const p = pick([15, 35, 45, 12.5, 30, 40]), b = pick([40, 60, 80, 120, 200, 240, 360, 480]); q = `كم يساوي ${p}% من ${b}؟`; a = p * b / 100; } else if (t === 2) { const x = 2 + rnd(9), y = 2 + rnd(9), z = 2 + rnd(9), k = 2 + rnd(5); q = `${x} + ${y} × ${z} − ${k} = ؟`; a = x + y * z - k; } else { const n = 13 + rnd(17); q = `${n}² = ؟`; a = n * n; } }
    else { const t = rnd(5); if (t === 0) { const x = 2 + rnd(9), b = 3 + rnd(20), c = x * (2 + rnd(6)); const k = c / x; q = `إذا كان ${k}س + ${b} = ${c + b}، فما قيمة س؟`; a = x; } else if (t === 1) { const n = pick([2, 3]), e = n === 2 ? 7 + rnd(5) : 4 + rnd(3); q = `${n} أس ${e} = ؟`; a = Math.pow(n, e); } else if (t === 2) { const s = pick([5, 6, 8, 9, 10, 12]); q = `ما مجموع الزوايا الداخلية لمضلع عدد أضلاعه ${s}؟`; a = (s - 2) * 180; } else if (t === 3) { const x = 4 + rnd(9), y = 6 + rnd(9); q = `ما المضاعف المشترك الأصغر للعددين ${x} و ${y}؟`; a = lcm(x, y); } else { const n = 5 + rnd(5); q = `كم عدد أقطار مضلع عدد أضلاعه ${n * 2}؟`; a = n * 2 * (n * 2 - 3) / 2; } }
    const w = closeNums(a, Math.random, null, false);
    return { id: 'm' + hash(q), c: 'math', l, q, a: String(a), w, gen: 1 };
  };
  function gcd(a, b) { return b ? gcd(b, a % b) : a; } function lcm(a, b) { return a * b / gcd(a, b); }

  // ---------- صعوبة متكيفة حسب أداء اللاعبين ----------
  let st = {};
  try { st = JSON.parse(localStorage.getItem('qb_st') || '{}'); } catch (e) { st = {}; }
  QB.record = function (id, ok) { if (!id || /^[gm]/.test(String(id))) return; const s = st[id] || [0, 0]; s[0]++; if (ok) s[1]++; st[id] = s; try { localStorage.setItem('qb_st', JSON.stringify(st)); } catch (e) { } };
  QB.rate = function (id) { const s = st[id]; return s && s[0] >= 3 ? Math.round(100 * s[1] / s[0]) : null; };
  QB.lvl = function (q) { const s = st[q.id]; if (s && s[0] >= 8) { const r = s[1] / s[0]; const e = r > .85 ? 1 : r > .6 ? 2 : r > .3 ? 3 : 4; if (Math.abs(e - q.l) >= 2) return q.l + Math.sign(e - q.l); } return q.l; };

  // ---------- الذاكرة: منع التكرار ----------
  let seen = {};
  try { seen = JSON.parse(localStorage.getItem('qb_seen') || '{}'); } catch (e) { seen = {}; }
  let seenTimer = null;
  function saveSeen() { clearTimeout(seenTimer); seenTimer = setTimeout(() => { try { localStorage.setItem('qb_seen', JSON.stringify(seen)); } catch (e) { } }, 300); }
  function markSeen(id) { seen[id] = 1; if (Object.keys(seen).length > 30000) seen = {}; saveSeen(); }
  QB.markSeen = markSeen;
  QB.resetSeen = function () { seen = {}; try { localStorage.removeItem('qb_seen'); } catch (e) { } };
  QB.seenCount = () => Object.keys(seen).length;

  const used = new Set();      // معرّفات داخل الجلسة
  const usedText = new Set();  // نص السؤال داخل الجلسة: نفس النص لا يتكرر حتى لو تغيّرت الخيارات
  const usedAns = new Set();   // نفس الجواب بنفس الفكرة
  QB.newSession = function () { used.clear(); usedText.clear(); usedAns.clear(); };
  const tkey = q => hash(QB.norm(q.q));
  const akey = q => q.c + '|' + QB.norm(show(q.a));
  const REP = new Set(); try { JSON.parse(localStorage.getItem('qb_reports') || '[]').forEach(r => { if (r.reason !== 'level') REP.add(r.id); }); } catch (e) { }
  QB._rep = REP;
  const isFree = q => !used.has(q.id) && !usedText.has(tkey(q)) && !REP.has(q.id);
  function take(q) { used.add(q.id); usedText.add(tkey(q)); usedAns.add(akey(q)); markSeen(q.id); markSeen(tkey(q)); return q; }
  QB.take = take; QB.isFree = isFree;

  function choose(pool, excludeFn) {
    const ok = x => !excludeFn || excludeFn(x);
    let fresh = pool.filter(x => isFree(x) && !seen[x.id] && !usedAns.has(akey(x)) && ok(x));
    if (!fresh.length) fresh = pool.filter(x => isFree(x) && !seen[x.id] && ok(x));
    if (!fresh.length) fresh = pool.filter(x => isFree(x) && ok(x));
    if (!fresh.length) return null;
    return take(pick(fresh));
  }
  QB.choose = choose;
  function chooseAny(pool) { // للأنواع الأخرى (من أنا، قوائم...)
    let fresh = pool.filter(x => !used.has(x.id) && !seen[x.id]);
    if (!fresh.length) fresh = pool.filter(x => !used.has(x.id));
    if (!fresh.length) { pool.forEach(x => used.delete(x.id)); fresh = pool; }
    if (!fresh.length) return null;
    const x = pick(fresh); used.add(x.id); markSeen(x.id); return x;
  }
  QB.chooseAny = chooseAny;

  // فهرس حسب الفئة لتسريع البحث
  let IDX = null;
  QB.reindex = function () { IDX = {}; for (const q of QB.mcq) (IDX[q.c] = IDX[q.c] || []).push(q); };
  const byCat = c => { if (!IDX) QB.reindex(); return IDX[c] || []; };

  function genTry(c, lv) {
    for (let t = 0; t < 8; t++) {
      const g = c === 'math' && Math.random() < .5 ? QB.mathQ(lv) : (QB.genQ(c, lv) || (c === 'math' ? QB.mathQ(lv) : null));
      if (!g) return null;
      if (isFree(g) && (!seen[tkey(g)] || t >= 5)) return take(g);
    }
    return null;
  }
  // سؤال اختيار من متعدد جاهز للعرض
  QB.getMCQ = function (cats, levels, opt) {
    opt = opt || {};
    cats = cats && cats.length ? cats : QB.order;
    levels = levels && levels.length ? levels : [1, 2, 3, 4];
    const order = shuffle(cats);
    // المحاولة الأولى بالمستوى المطلوب بالضبط، ثم المستويات المجاورة، بدون تكرار أبداً
    for (const strict of [true, false]) {
      for (const c of order) {
        const lv = pick(levels);
        const hasGen = c === 'math' || (QB.generators && QB.generators[c]);
        const all = byCat(c);
        const near = strict ? [lv] : [lv, lv - 1, lv + 1, lv - 2, lv + 2].filter(x => x >= 1 && x <= 4);
        let q = null;
        const genRate = c === 'math' ? .6 : (c === 'logic' ? .35 : .12);
        if (hasGen && Math.random() < genRate) q = genTry(c, lv);
        for (const L of near) { if (q) break; q = choose(all.filter(x => QB.lvl(x) === L)); }
        if (!q && hasGen) q = genTry(c, lv);
        if (q) return QB.present(q);
      }
    }
    // كل شيء استُهلك في هذه الجلسة: ابدأ دورة جديدة
    QB.newSession();
    return QB.present(choose(byCat(order[0]).length ? byCat(order[0]) : QB.mcq) || QB.mathQ(2));
  };
  QB.present = function (q) {
    const w = q.w.slice(0, 3).map(show);
    const a = show(q.a);
    const opts = shuffle([a, ...w]);
    return { id: q.id, c: q.c, l: q.l, q: q.q, opts, ans: opts.indexOf(a), a, i: q.i || '' };
  };
  // صح أم خطأ
  QB.getTF = function (cats, levels) {
    const m = QB.getMCQ(cats, levels);
    const truth = Math.random() < .5;
    const shown = truth ? m.a : m.opts.filter((_, i) => i !== m.ans)[rnd(m.opts.length - 1)];
    return { id: m.id, c: m.c, l: m.l, q: m.q, shown, truth, a: m.a, i: m.i };
  };
  const filt = (arr, cats, levels, extra) => {
    cats = cats && cats.length ? cats : QB.order;
    let pool = arr.filter(x => cats.includes(x.c) && (!levels || levels.includes(x.l)) && (!extra || extra(x)));
    if (pool.length < 3) pool = arr.filter(x => cats.includes(x.c) && (!extra || extra(x)));
    if (pool.length < 3) pool = arr.filter(x => !extra || extra(x));
    return pool;
  };
  QB.getWho = (cats, levels) => chooseAny(filt(QB.who, cats, levels));
  QB.getList = (cats, levels, minItems) => chooseAny(filt(QB.lists, cats, levels, x => x.items.length >= (minItems || 5)));
  QB.getEmoji = (cats, levels) => chooseAny(filt(QB.emoji, cats, levels));
  QB.getNear = (cats, levels) => chooseAny(filt(QB.near, cats, levels));
  QB.getChain = (cats, levels) => chooseAny(filt(QB.chain, cats, levels, x => x.items.length >= 15));
  QB.getHex = function (ch, cats, levels) {
    const n = x => QB.norm(x.ch);
    let pool = QB.hex.filter(x => n(x) === QB.norm(ch));
    const p2 = pool.filter(x => (!levels || levels.includes(x.l)));
    return chooseAny(p2.length ? p2 : pool);
  };
  QB.hexLetters = () => [...new Set(QB.hex.map(x => x.ch))];
  QB.getOrder = function (cats, levels) {
    cats = cats && cats.length ? cats : QB.order;
    const fixed = QB.orders.filter(x => cats.includes(x.c));
    const pools = QB.orderPools.filter(x => cats.includes(x.c));
    const usePool = pools.length && (!fixed.length || Math.random() < .6);
    let o;
    if (usePool) {
      const P = pick(pools);
      let items = []; let tries = 0;
      while (items.length < 4 && tries++ < 60) { const it = pick(P.items); if (!items.some(x => x.k === it.k || x.v === it.v)) items.push(it); }
      o = { id: 'op' + hash(P.q + items.map(i => i.k).join()), c: P.c, l: P.l, q: P.q, items };
    } else {
      const all = fixed.length ? fixed : QB.orders;
      o = chooseAny(all);
      if (!o) { const P = pick(QB.orderPools); return QB.getOrder([P.c]); }
      o = { ...o, items: shuffle(o.items).slice(0, 4) };
    }
    const correct = o.items.slice().sort((a, b) => a.v - b.v).map(i => i.k);
    return { id: o.id, c: o.c, l: o.l, q: o.q, shown: shuffle(o.items.map(i => i.k)), correct, vals: o.items };
  };

  // ---------- تنظيف البنك بعد التحميل: حذف المكرر ----------
  QB.finalize = function () {
    const byText = new Map(), out = [];
    let dropped = 0;
    for (const q of QB.mcq) {
      if (QB.drop && QB.drop.has(q.id)) { dropped++; continue; }
      if (QB.fix && QB.fix[q.id]) Object.assign(q, QB.fix[q.id]);
      const a = QB.norm(show(q.a));
      q.w = q.w.filter(x => QB.norm(show(x)) !== a);
      const k = QB.norm(q.q) + '|' + a;
      if (byText.has(k)) { dropped++; continue; }
      byText.set(k, 1);
      if (q.w.length < 3 && !q.gen) { /* نُبقيه بثلاثة خيارات */ }
      out.push(q);
    }
    QB.mcq = out; IDX = null; QB.reindex();
    return dropped;
  };

  QB.stats = function () {
    for (const id in QB.cats) QB.cats[id].n = 0;
    for (const arr of [QB.mcq, QB.who, QB.lists]) for (const q of arr) if (QB.cats[q.c]) QB.cats[q.c].n++;
    return { mcq: QB.mcq.length, who: QB.who.length, lists: QB.lists.length, orders: QB.orders.length + QB.orderPools.length, emoji: QB.emoji.length, near: QB.near.length, hex: QB.hex.length, chain: QB.chain.length };
  };

  // أسئلة المستخدم المضافة
  QB.loadCustom = function () {
    try { const arr = JSON.parse(localStorage.getItem('qb_custom') || '[]'); for (const q of arr) QB.mcq.push(q); IDX = null; return arr; } catch (e) { return []; }
  };
  QB.saveCustom = function (q) {
    let arr = []; try { arr = JSON.parse(localStorage.getItem('qb_custom') || '[]'); } catch (e) { }
    q.id = hash('u' + q.q + Date.now()); arr.push(q); QB.mcq.push(q); IDX = null;
    try { localStorage.setItem('qb_custom', JSON.stringify(arr)); } catch (e) { }
  };

  // ---------- الإبلاغ عن سؤال ----------
  QB.reports = function () { try { return JSON.parse(localStorage.getItem('qb_reports') || '[]'); } catch (e) { return []; } };
  QB.report = function (q, reason) {
    const arr = QB.reports();
    if (arr.some(r => r.id === q.id && r.reason === reason)) return;
    arr.push({ id: q.id, c: q.c, l: q.l, q: q.q, a: q.a, reason, t: Date.now() });
    if (reason !== 'level' && QB._rep) QB._rep.add(q.id);
    try { localStorage.setItem('qb_reports', JSON.stringify(arr.slice(-500))); } catch (e) { }
  };
  QB.clearReports = function () { try { localStorage.removeItem('qb_reports'); } catch (e) { } if (QB._rep) QB._rep.clear(); };
  QB.unreport = function (t) { const arr = QB.reports().filter(r => r.t !== t); try { localStorage.setItem('qb_reports', JSON.stringify(arr)); } catch (e) { } QB._rep.clear(); arr.forEach(r => { if (r.reason !== 'level') QB._rep.add(r.id); }); };
  QB.findAny = function (id) { return QB.mcq.find(q => q.id === id) || QB.hex.find(q => q.id === id) || QB.emoji.find(q => q.id === id) || QB.near.find(q => q.id === id) || null; };
})();
