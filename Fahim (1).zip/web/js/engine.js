/* محرك فهيم: يعمل على جهاز المضيف فقط ويبث الحالة للجميع */
const MODES = {
  board: { name: 'لوح التحدي', e: '🎯', d: 'لوحة من 6 فئات وأسئلة بقيم 200 / 400 / 600 / 800 حسب الصعوبة.', rules: [
    'يختار الفريق صاحب الدور خانة (فئة + قيمة). كلما ارتفعت القيمة صعب السؤال: 200 سهل، 400 متوسط، 600 صعب، 800 خبير.',
    'الإجابة الصحيحة تمنح قيمة الخانة كاملة.',
    'الإجابة الخاطئة تفتح فرصة سرقة للفريق التالي (يُخفى الخيار الخاطئ)، فإن أصاب أخذ القيمة.',
    'لكل فريق ثلاث وسائل مساعدة مرة واحدة: اتصال بصديق (+30 ثانية)، جاوب جوابين (اختيار إجابتين)، الحفرة (إن أصبت تُخصم القيمة نفسها من المتصدر).',
    'يمكن للمضيف اختيار "الإجابة المفتوحة": يُقرأ السؤال بلا خيارات ويحكم المضيف بصح أو خطأ.',
    'تنتهي الجولة عند فتح كل الخانات.'] },
  kahoot: { name: 'تحدي السرعة', e: '⚡', d: 'الجميع يجاوب معاً على السؤال نفسه، والأسرع يكسب أكثر.', rules: [
    'يظهر السؤال مع أربعة خيارات للجميع في الوقت نفسه.',
    'الإجابة الصحيحة تمنح بين 500 و1000 نقطة حسب سرعتك.',
    'سلسلة الإجابات الصحيحة المتتالية تضيف مكافأة 100 لكل إجابة (حتى 500).',
    'على جهاز واحد: يتناوب الفرق على الأسئلة.'] },
  buzzer: { name: 'الجرس', e: '🔔', d: 'أول من يضغط الجرس يحق له الإجابة.', rules: [
    'يظهر نص السؤال بلا خيارات، والجرس مقفل ثانية واحدة حتى يقرأ الجميع (يظهر مؤشر "استعد").',
    'أول فريق يضغط الجرس يُعلن اسمه لثانية ثم تظهر له الخيارات وحده.',
    'الصحيح = 100 × مستوى السؤال، والخطأ يخصم نصفها ويُقفل الجرس على هذا الفريق في هذا السؤال.',
    'بعد الخطأ تنتقل الفرصة لبقية الفرق.'] },
  know: { name: 'ماذا تعرف؟', e: '⏱️', d: 'موضوع ووقت محدد: اكتب أكبر عدد من الإجابات.', rules: [
    'يظهر موضوع (مثل: دول تبدأ بحرف الميم) ويبدأ العدّ عند ضغط "ابدأ".',
    'اكتب كل إجابة واضغط إدخال. كل إجابة صحيحة = 100 نقطة.',
    'التصحيح ذكي: يتجاهل الهمزات والتاء المربوطة و"ال" والأخطاء الإملائية البسيطة والحروف المتقاربة صوتياً.',
    'يستطيع المضيف إضافة إجابة صحيحة يدوياً إن لم يتعرف عليها التطبيق.',
    'في النهاية تُعرض الإجابات التي فاتتك.'] },
  auction: { name: 'المزاد', e: '🔨', d: 'زايدوا على عدد ما تستطيعون ذكره، ثم أثبتوا ذلك.', rules: [
    'يظهر موضوع وعدد إجاباته الممكنة، ويزايد الفرق بالتناوب على عدد الإجابات التي يستطيعون ذكرها.',
    'يمكن الانسحاب في أي دور. يفوز بالمزاد صاحب أعلى رقم بعد انسحاب الباقين.',
    'على الفائز أن يكتب العدد الذي زايد عليه خلال الوقت.',
    'إن نجح كسب 100 × العدد، وإن فشل حصل كل خصم على 50 × العدد.'] },
  who: { name: 'من أنا؟', e: '🕵️', d: 'تلميحات تتكشف من الأصعب إلى الأسهل.', rules: [
    'تظهر تلميحات عن شخصية أو مكان أو شيء، تلميحاً بعد تلميح.',
    'التخمين مع التلميح الأول = 400، الثاني = 300، الثالث = 200، الرابع = 100.',
    'التخمين الخاطئ يقفل الفريق حتى ظهور التلميح التالي.',
    'تُكتب الإجابة كتابةً، والتصحيح يتسامح مع الأخطاء الإملائية والأسماء الجزئية المميزة.'] },
  tf: { name: 'صح أم خطأ', e: '✅', d: 'سؤال وإجابة مقترحة: صحيحة أم خاطئة؟', rules: [
    'يظهر سؤال وإجابة مقترحة، وعليك الحكم: صح أم خطأ.',
    'الصحيح يمنح 300 إلى 600 حسب السرعة.',
    'عند الخطأ تظهر الإجابة الصحيحة.'] },
  order: { name: 'رتّب', e: '🔢', d: 'رتّب 4 عناصر زمنياً أو حسب الحجم.', rules: [
    'تظهر أربعة عناصر بترتيب عشوائي مع معيار الترتيب (الأقدم، الأكبر...).',
    'اضغطها بالترتيب الصحيح ثم أكّد.',
    'الترتيب الكامل = 600 إلى 1000 حسب السرعة، وإلا 100 لكل عنصر في مكانه الصحيح.'] },
  survival: { name: 'الصمود', e: '🛡️', d: 'محاولات محدودة وأسئلة تزداد صعوبة.', rules: [
    'لكل فريق عدد محاولات (1 إلى 3 حسب الإعداد).',
    'الصعوبة ترتفع كل 3 أسئلة.',
    'كل خطأ يُفقدك محاولة، وعند نفادها تخرج من الجولة.',
    'آخر الصامدين يحصل على مكافأة 1000.'] },
  hex: { name: 'خلية الحروف', e: '⬢', d: 'شبكة حروف سداسية: الأحمر يصل اليمين باليسار، والأزرق يصل الأعلى بالأسفل.', rules: [
    'يلعبها فريقان: الأحمر (الفريق الأول) والأزرق (الفريق الثاني).',
    'يختار صاحب الدور خلية، فيظهر سؤال جوابه يبدأ بحرفها.',
    'الجرس مفتوح للفريقين: أول من يضغط يكتب الإجابة. الصحيح يلوّن الخلية بلونه (+100).',
    'الخطأ ينقل الفرصة للفريق الآخر. وإن أخطأ الاثنان تبقى الخلية فارغة.',
    'يفوز من يصنع مساراً متصلاً: الأحمر من الجهة اليمنى إلى اليسرى، والأزرق من الأعلى إلى الأسفل (+1000).',
    'من يأخذ الخلية يختار الخلية التالية.'] },
  catwar: { name: 'حرب الفئات', e: '⚔️', d: 'كل فريق يختار الفئة والصعوبة لخصمه.', rules: [
    'في كل دور يختار فريق فئةً ومستوى صعوبة، ويُطرح السؤال على الفريق التالي.',
    'إن أجاب الخصم صحيحاً كسب 100 × المستوى (سهل 100 حتى خبير 400).',
    'وإن أخطأ كسب الفريق المختار 50 × المستوى.',
    'اختر الفئة التي يضعف فيها خصمك… لكن احذر: السؤال الخبير يمنحه نقاطاً أكثر إن عرفه.'] },
  emoji: { name: 'صورة وتخمين', e: '🧩', d: 'رموز تعبيرية تصف فيلماً أو مثلاً أو دولة أو قصة.', rules: [
    'تظهر مجموعة رموز مع نوع الجواب (فيلم، مثل، دولة...).',
    'اختر الجواب الصحيح من الخيارات. الجميع يجاوب معاً.',
    'الصحيح = 300 إلى 700 حسب السرعة.'] },
  chain: { name: 'السلسلة', e: '🔗', d: 'كل إجابة تبدأ بآخر حرف من الإجابة السابقة.', rules: [
    'يظهر موضوع (دول، عواصم، حيوانات…) وحرف البداية.',
    'يكتب صاحب الدور عنصراً من الموضوع يبدأ بالحرف المطلوب، ثم ينتقل الدور ويصبح الحرف المطلوب هو آخر حرف من الإجابة.',
    'لا يُعتد بـ"ال" في البداية، والتاء المربوطة تُحسب هاءً أو تاءً، والهمزة الأخيرة تُتجاوز.',
    'لا يجوز تكرار إجابة سبق ذكرها. لكل دور وقت محدد.',
    'كل إجابة صحيحة = 100. من يخطئ أو ينفد وقته يخرج من السلسلة، وآخر الباقين يكسب 500.'] },
  near: { name: 'الأقرب يربح', e: '🎯', d: 'سؤال جوابه رقم: الأقرب إلى الرقم الصحيح يفوز.', rules: [
    'يكتب كل فريق تخمينه الرقمي سراً.',
    'الأقرب إلى الجواب يحصل على 500، والثاني 250.',
    'الإصابة الدقيقة تمنح 500 إضافية.',
    'على جهاز واحد: يكتب كل فريق رقمه بدوره دون أن يراه الآخرون.'] }
};
const LVL = ['', 'سهل', 'متوسط', 'صعب', 'خبير'];
const BOARD_VALS = [0, 200, 400, 600, 800];
const HEX_N = 5;

const E = (function () {
  let G = null, TT = null, TFN = null;
  const now = () => Date.now();
  const S = id => G.sides.find(s => s.id === id);
  const alive = () => G.sides.filter(s => !s.gone);
  const nameOf = id => (S(id) || {}).name || '';
  function setT(ms, fn) { clearT(); G.tEnd = now() + ms; G.tTot = ms; TFN = fn; TT = setTimeout(() => { TT = null; TFN = null; G.tEnd = 0; fn(); }, ms); }
  function clearT() { if (TT) clearTimeout(TT); TT = null; TFN = null; if (G) G.tEnd = 0; }
  function add(id, n) { const s = S(id); if (s) { s.score += n; s.last = n; } }
  function levelFor(i, n) {
    const L = G.cfg.levels.slice().sort();
    if (!G.cfg.curve) return QB.pick(L);
    return L[Math.min(L.length - 1, Math.floor(i / Math.max(1, n) * L.length))];
  }

  // ---------- إحصائيات نهاية اللعبة ----------
  function stat(side, pid, ok, ms, cat) {
    if (!G.st) return; const st = G.st;
    const s = st.s[side] = st.s[side] || { ok: 0, n: 0, streak: 0, best: 0, cats: {} };
    s.n++; if (ok) { s.ok++; s.streak++; s.best = Math.max(s.best, s.streak); } else s.streak = 0;
    if (cat) { const c = s.cats[cat] = s.cats[cat] || [0, 0]; c[0]++; if (ok) c[1]++; }
    if (ok && ms != null && ms > 300 && (!st.fast || ms < st.fast.ms)) st.fast = { side, pid, ms };
    if (pid && G.players[pid]) { const p = st.p[pid] = st.p[pid] || { ok: 0, n: 0 }; p.n++; if (ok) p.ok++; }
  }
  function summary() {
    const st = G.st; const out = { sides: {}, fast: null, mvp: null };
    for (const id in st.s) {
      const s = st.s[id]; let best = null;
      for (const c in s.cats) { const [n, k] = s.cats[c]; if (k && (!best || k / n > best.r || (k / n === best.r && k > best.k))) best = { c, r: k / n, k, n }; }
      out.sides[id] = { ok: s.ok, n: s.n, best: s.best, cat: best ? { name: (QB.cats[best.c] || {}).name || (MODES[best.c] || {}).name || '', k: best.k, n: best.n } : null };
    }
    if (st.fast) out.fast = { side: st.fast.side, name: (G.players[st.fast.pid] || {}).name || nameOf(st.fast.side), sec: (st.fast.ms / 1000).toFixed(1) };
    let mvp = null; for (const pid in st.p) { const p = st.p[pid]; if (!mvp || p.ok > mvp.ok) mvp = { pid, ok: p.ok, n: p.n }; }
    if (mvp && mvp.ok) out.mvp = { name: (G.players[mvp.pid] || {}).name || '', ok: mvp.ok, n: mvp.n, side: (G.players[mvp.pid] || {}).side };
    return out;
  }

  // ---------- الحالة العامة ----------
  function view() {
    return {
      sides: G.sides, players: G.players, local: G.local, ri: G.ri, rounds: G.rounds, mode: G.mode, ph: G.ph, d: G.d,
      t: G.paused ? G.paused.rem : (G.tEnd ? Math.max(0, G.tEnd - now()) : 0), tot: G.tTot, paused: !!G.paused,
      cfg: { style: G.cfg.style, timer: G.cfg.timer, n: G.cfg.n }, seq: ++G.seq, host: G.hostPid, online: G.online || {}
    };
  }
  function push() { const v = view(); if (E.onState) E.onState(v); }

  function init(cfg, sides, players, local, hostPid) {
    clearT();
    QB.newSession();
    const r = cfg.modes.filter(m => MODES[m]);
    G = { cfg, sides: sides.map(s => ({ ...s, score: 0, streak: 0, last: 0 })), players, local, rounds: r, ri: -1, mode: null, ph: 'idle', d: {}, m: {}, seq: 0, hostPid, _next: null, st: { s: {}, p: {} }, online: {} };
    nextRound();
  }
  function nextRound() {
    clearT();
    G.ri++;
    if (G.ri >= G.rounds.length) { G.ph = 'podium'; G.mode = null; G.d = { ranking: G.sides.slice().sort((a, b) => b.score - a.score).map(s => s.id), sum: summary() }; G._next = null; push(); return; }
    G.mode = G.rounds[G.ri]; G.ph = 'banner'; G.d = { mode: G.mode }; G.m = {};
    G._next = () => M[G.mode].start();
    push();
    setT(3200, () => M[G.mode].start());
  }
  function lb(next) { G.ph = 'lb'; G.d = { ranking: G.sides.slice().sort((a, b) => b.score - a.score).map(s => s.id) }; G._next = next; push(); setT(3500, next); }

  // ---------- إيقاف مؤقت ----------
  function pause() { if (!G || G.paused || G.ph === 'podium') return; G.paused = { rem: G.tEnd ? Math.max(0, G.tEnd - now()) : 0, fn: TFN, tot: G.tTot }; if (TT) clearTimeout(TT); TT = null; G.tEnd = 0; push(); }
  function resume() { if (!G || !G.paused) return; const p = G.paused; G.paused = null; if (p.fn && p.rem > 0) { setT(p.rem, p.fn); G.tTot = p.tot; } else if (p.fn) p.fn(); push(); }

  // ---------- آلية السؤال الموحدة ----------
  function ask(o) {
    clearT();
    G.ask = o; o.res = {}; o.t0 = now();
    G.ph = 'q';
    const q = o.q;
    G.d = { kind: o.kind, title: o.title || '', who: o.who, done: [], c: q.c, l: q.l, value: o.value || 0, hide: o.hide || [], two: false, helpers: o.helpers || null, sub: o.sub || '', qid: q.id, emo: o.emo || null, unit: o.unit || '' };
    if (o.kind === 'mcq') { G.d.text = q.q; G.d.opts = q.opts; }
    else if (o.kind === 'tf') { G.d.text = q.q; G.d.shown = q.shown; }
    else if (o.kind === 'order') { G.d.text = q.q; G.d.items = q.shown; }
    else if (o.kind === 'near') { G.d.text = q.q; }
    if (G.cfg.style === 'open' && o.kind === 'mcq' && o.openOk) { G.ph = 'open'; G.d.step = 'ask'; }
    setT(o.time * 1000, () => { if (G.ph === 'open') { G.d.timeout = true; push(); } else finishAsk(); });
    push();
  }
  function answer(side, pid, a) {
    const o = G.ask; if (!o || G.ph !== 'q' || G.paused) return;
    if (!o.who.includes(side) || o.res[side]) return;
    let ok = false, part = 0;
    if (o.kind === 'mcq') ok = a.i === o.q.ans || (G.d.two && a.j === o.q.ans);
    else if (o.kind === 'tf') ok = (!!a.v) === o.q.truth;
    else if (o.kind === 'order') { const arr = a.arr || []; part = arr.filter((k, i) => k === o.q.correct[i]).length; ok = part === o.q.correct.length; }
    else if (o.kind === 'near') { const n = parseFloat(String(a.n).replace(/[٫,]/g, '.').replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d))); if (isNaN(n)) return; a.n = n; ok = n === o.q.v; }
    o.res[side] = { ok, part, t: now() - o.t0, ch: a.i, ch2: a.j, v: a.v, n: a.n, pid, arr: a.arr };
    G.d.done.push(side);
    if (o.who.every(s => o.res[s])) finishAsk(); else push();
  }
  function finishAsk() {
    const o = G.ask; if (!o) return; clearT();
    o.who.forEach(s => { if (!o.res[s]) o.res[s] = { ok: false, part: 0, t: o.time * 1000, timeout: true }; });
    if (o.decide && o.decide(o.res) === false) return;
    reveal(o);
  }
  function reveal(o) {
    const deltas = o.score ? o.score(o.res) : {};
    if (o.kind === 'mcq' || o.kind === 'tf') o.who.forEach(s => QB.record && QB.record(o.q.id, o.res[s].ok));
    if (o.kind !== 'near') o.who.forEach(s => { const r = o.res[s]; if (!r.timeout || o.who.length === 1) stat(s, r.pid, r.ok, r.timeout ? null : r.t, o.q.c); });
    G.ph = 'reveal';
    G.d.res = o.who.map(s => ({ s, ok: o.kind === 'near' ? (deltas[s] || 0) > 0 : o.res[s].ok, part: o.res[s].part, d: deltas[s] || 0, ch: o.res[s].ch, ch2: o.res[s].ch2, v: o.res[s].v, n: o.res[s].n, timeout: o.res[s].timeout }));
    if (o.kind === 'mcq') G.d.ans = o.q.ans;
    if (o.kind === 'tf') { G.d.truth = o.q.truth; G.d.real = o.q.a; }
    if (o.kind === 'order') { G.d.correct = o.q.correct; G.d.vals = o.q.vals; }
    if (o.kind === 'near') { G.d.real = o.q.v; }
    G.d.info = o.q.i || '';
    G.d.qa = o.q.a != null ? String(o.q.a) : '';
    G.d.rate = QB.rate ? QB.rate(o.q.id) : null;
    G.ask = null;
    G._next = o.after;
    push();
    if (o.auto) setT(o.auto + (G.d.info ? 2500 : 0), o.after);
  }
  function revealPlain(q, title, next) {
    clearT(); G.ph = 'reveal';
    G.d = { kind: 'mcq', title, text: q.q, opts: q.opts, ans: q.ans, c: q.c, l: q.l, res: [], hide: [], who: [], info: q.i || '', qid: q.id, qa: q.a };
    G._next = next; push(); setT(5000 + (q.i ? 2500 : 0), next);
  }
  function rotateWho(i) { const al = alive(); return [al[i % al.length].id]; }
  function speedScore(T, base, span) { return (res) => { const d = {}; for (const s in res) { const r = res[s], sd = S(s); if (r.ok) { sd.streak = (sd.streak || 0) + 1; d[s] = Math.round(base + span * (1 - r.t / (T * 1000))) + (base >= 500 ? Math.min(sd.streak - 1, 5) * 100 : 0); } else { sd.streak = 0; d[s] = 0; } add(s, d[s]); } return d; }; }

  // ---------- الأنماط ----------
  const M = {};
  M.kahoot = {
    start() { G.m = { i: 0, n: G.cfg.n }; this.next(); },
    next() {
      const m = G.m; const total = m.n * (G.local ? alive().length : 1); if (m.i >= total) return nextRound();
      const lv = levelFor(m.i, total); const q = QB.getMCQ(G.cfg.cats, [lv]);
      const who = G.local ? rotateWho(m.i) : alive().map(s => s.id); m.i++;
      const T = G.cfg.timer;
      ask({ kind: 'mcq', q, who, time: T, title: `سؤال ${m.i} من ${total}`, sub: G.local ? 'دور: ' + nameOf(who[0]) : '', score: speedScore(T, 500, 500), after: () => lb(() => M.kahoot.next()), auto: 4000 });
    }
  };
  M.tf = {
    start() { G.m = { i: 0, n: Math.max(5, G.cfg.n) }; this.next(); },
    next() {
      const m = G.m; const total = m.n * (G.local ? alive().length : 1); if (m.i >= total) return nextRound();
      const q = QB.getTF(G.cfg.cats, [levelFor(m.i, total)]); const who = G.local ? rotateWho(m.i) : alive().map(s => s.id); m.i++;
      const T = Math.min(G.cfg.timer, 12);
      ask({ kind: 'tf', q, who, time: T, title: `صح أم خطأ ${m.i}/${total}`, sub: G.local ? 'دور: ' + nameOf(who[0]) : '', score: speedScore(T, 300, 300), after: () => { if (m.i % 3 === 0) lb(() => M.tf.next()); else M.tf.next(); }, auto: 3000 });
    }
  };
  M.order = {
    start() { G.m = { i: 0, n: Math.max(3, Math.ceil(G.cfg.n / 2)) }; this.next(); },
    next() {
      const m = G.m; const total = m.n * (G.local ? alive().length : 1); if (m.i >= total) return nextRound();
      const q = QB.getOrder(G.cfg.cats, G.cfg.levels); const who = G.local ? rotateWho(m.i) : alive().map(s => s.id); m.i++;
      const T = G.cfg.timer + 15;
      ask({
        kind: 'order', q, who, time: T, title: `رتّب ${m.i}/${total}`, sub: G.local ? 'دور: ' + nameOf(who[0]) : '',
        score(res) { const d = {}; for (const s in res) { const r = res[s]; d[s] = r.ok ? Math.round(600 + 400 * (1 - r.t / (T * 1000))) : (r.part || 0) * 100; add(s, d[s]); } return d; },
        after: () => lb(() => M.order.next()), auto: 6000
      });
    }
  };
  M.survival = {
    start() { G.m = { i: 0, lives: {}, out: [] }; alive().forEach(s => G.m.lives[s.id] = G.cfg.lives); this.next(); },
    left() { return alive().filter(s => !G.m.out.includes(s.id)); },
    next() {
      const m = G.m, L = this.left();
      const multi = alive().length > 1;
      if ((multi && L.length <= 1) || L.length === 0 || m.i >= 30) { L.forEach(s => add(s.id, 1000)); G.d = {}; return lb(() => nextRound()); }
      const step = Math.floor(m.i / (G.local ? 3 * L.length : 3));
      const Ls = G.cfg.levels.slice().sort(); const lv = Ls[Math.min(Ls.length - 1, step)];
      const q = QB.getMCQ(G.cfg.cats, [lv]);
      const who = G.local ? [L[m.i % L.length].id] : L.map(s => s.id); m.i++;
      ask({
        kind: 'mcq', q, who, time: G.cfg.timer, title: `الصمود — سؤال ${m.i}`, sub: who.length === 1 ? 'دور: ' + nameOf(who[0]) + ' — ' + '❤️'.repeat(m.lives[who[0]]) : `الصامدون: ${L.length}`,
        score(res) { const d = {}; for (const s in res) { if (res[s].ok) { d[s] = 200 * lv; add(s, d[s]); } else { m.lives[s]--; d[s] = 0; if (m.lives[s] <= 0) m.out.push(s); } } return d; },
        after: () => M.survival.next(), auto: 4000
      });
      G.d.lives = m.lives; G.d.out = m.out; push();
    }
  };
  M.board = {
    start() {
      let cats = G.cfg.cats.filter(c => QB.mcq.some(q => q.c === c) || c === 'math');
      cats = QB.shuffle(cats).slice(0, 6);
      if (cats.length < 2) cats = QB.shuffle(QB.order.filter(c => QB.mcq.some(q => q.c === c))).slice(0, 6);
      const cells = []; let id = 0;
      cats.forEach((c, ci) => [1, 2, 3, 4].forEach(lv => { for (let k = 0; k < G.cfg.copies; k++) cells.push({ id: id++, ci, lv, v: BOARD_VALS[lv], used: false }); }));
      const helpers = {}; alive().forEach(s => helpers[s.id] = { call: 1, two: 1, hole: 1 });
      G.m = { cats, cells, turn: 0, helpers };
      this.pick();
    },
    turnSide() { const al = alive(); return al[G.m.turn % al.length].id; },
    pick() {
      clearT();
      if (G.m.cells.every(c => c.used)) return lb(() => nextRound());
      G.ph = 'pick';
      G.d = { cats: G.m.cats.map(c => ({ id: c, name: QB.cats[c].name, icon: QB.cats[c].icon })), cells: G.m.cells, turn: this.turnSide(), helpers: G.m.helpers, copies: G.cfg.copies };
      G._next = null; push();
    },
    open(cell) {
      cell.used = true;
      const cat = G.m.cats[cell.ci]; const side = this.turnSide();
      const q = QB.getMCQ([cat], [cell.lv]);
      G.m.cur = { cell, q, side, hole: false };
      const self = this;
      const al = alive(); const other = al.length > 1 ? al[(G.m.turn + 1) % al.length].id : null;
      ask({
        kind: 'mcq', q, who: [side], time: G.cfg.timer, title: `${QB.cats[cat].icon} ${QB.cats[cat].name} — ${cell.v}`, value: cell.v, openOk: true,
        helpers: { side, h: G.m.helpers[side] },
        decide(res) {
          if (res[side].ok || !other) return true;
          stat(side, res[side].pid, false, null, q.c);
          const hide = [res[side].ch, res[side].ch2].filter(x => x !== undefined);
          ask({
            kind: 'mcq', q, who: [other], time: Math.max(10, Math.round(G.cfg.timer * .6)), title: 'فرصة سرقة', sub: `${nameOf(side)} أخطأ — الفرصة لـ ${nameOf(other)}`, value: cell.v, hide,
            score(r2) { const d = { [side]: 0 }; if (r2[other].ok) { d[other] = cell.v; add(other, cell.v); } else d[other] = 0; return d; },
            after: () => self.nextTurn()
          });
          return false;
        },
        score(res) {
          const d = {};
          if (res[side].ok) {
            d[side] = cell.v; add(side, cell.v);
            if (G.m.cur.hole) { const opp = alive().filter(s => s.id !== side).sort((a, b) => b.score - a.score)[0]; if (opp) { add(opp.id, -cell.v); d[opp.id] = -cell.v; } }
          } else d[side] = 0;
          return d;
        },
        after: () => self.nextTurn()
      });
    },
    nextTurn() { G.m.turn++; this.pick(); },
    helper(side, h) {
      const hs = G.m.helpers[side]; if (!hs || !hs[h] || G.ph !== 'q' || !G.ask || !G.ask.who.includes(side)) return;
      hs[h] = 0;
      if (h === 'call') { const rem = Math.max(0, G.tEnd - now()); setT(rem + 30000, () => finishAsk()); G.d.msg = 'اتصال بصديق: أُضيفت 30 ثانية'; }
      if (h === 'two') { G.d.two = true; G.d.msg = 'جاوب جوابين: اختر إجابتين'; }
      if (h === 'hole') { G.m.cur.hole = true; G.d.msg = 'الحفرة: إن أصبت تُخصم القيمة من المتصدر'; }
      push();
    },
    judge(a) {
      if (G.ph !== 'open') return;
      const cur = G.m.cur; const al = alive(); const other = al.length > 1 ? al[(G.m.turn + 1) % al.length].id : null;
      if (a.step === 'show') { G.d.step = 'shown'; G.d.answer = cur.q.a; clearT(); push(); return; }
      const fin = (deltas) => { G.ph = 'reveal'; G.d.kind = 'mcq'; G.d.ans = cur.q.ans; G.d.info = cur.q.i || ''; G.d.res = Object.keys(deltas).map(s => ({ s, ok: deltas[s] > 0, d: deltas[s] })); G._next = () => M.board.nextTurn(); push(); };
      if (G.d.step === 'shown' || G.d.step === 'ask') {
        stat(cur.side, null, !!a.ok, null, cur.q.c);
        if (a.ok) { add(cur.side, cur.cell.v); const d = { [cur.side]: cur.cell.v }; if (cur.hole) { const opp = al.filter(s => s.id !== cur.side).sort((x, y) => y.score - x.score)[0]; if (opp) { add(opp.id, -cur.cell.v); d[opp.id] = -cur.cell.v; } } fin(d); }
        else if (other) { G.d.step = 'steal'; G.d.stealer = other; G.d.answer = cur.q.a; push(); }
        else fin({ [cur.side]: 0 });
      } else if (G.d.step === 'steal') {
        stat(other, null, !!a.ok, null, cur.q.c);
        if (a.ok) { add(other, cur.cell.v); fin({ [other]: cur.cell.v, [cur.side]: 0 }); } else fin({ [cur.side]: 0, [other]: 0 });
      }
    }
  };
  // الجرس: قفل ثانية عند ظهور السؤال، وإعلان الضاغط لثانية قبل الخيارات
  M.buzzer = {
    start() { G.m = { i: 0, n: G.cfg.n }; this.next(); },
    next() {
      const m = G.m; if (m.i >= m.n) return lb(() => nextRound());
      const lv = levelFor(m.i, m.n); const q = QB.getMCQ(G.cfg.cats, [lv]); m.i++;
      m.q = q; m.lv = lv; m.locked = [];
      G.ph = 'buzzq'; G.d = { text: q.q, c: q.c, l: q.l, title: `الجرس — سؤال ${m.i} من ${m.n}`, locked: [], value: lv * 100, armAt: now() + 1000, qid: q.id };
      G._next = null;
      setT((G.cfg.timer + 6) * 1000, () => revealPlain(q, 'لم يضغط أحد الجرس!', () => M.buzzer.next()));
      push();
    },
    buzz(side) {
      const m = G.m; if (G.ph !== 'buzzq' || m.locked.includes(side) || G.paused) return;
      if (G.d.armAt && now() < G.d.armAt) return; // الجرس مقفل في الثانية الأولى
      const lv = m.lv, q = m.q;
      clearT();
      G.ph = 'buzzed'; G.d = Object.assign({}, G.d, { buzzer: side });
      push();
      setT(1000, () => {
        ask({
          kind: 'mcq', q, who: [side], time: Math.max(8, Math.round(G.cfg.timer * .6)), title: `${nameOf(side)} ضغط الجرس`, value: lv * 100, openOk: false,
          decide(res) {
            if (res[side].ok) return true;
            stat(side, res[side].pid, false, null, q.c);
            add(side, -lv * 50); m.locked.push(side);
            const rest = alive().filter(s => !m.locked.includes(s.id));
            if (rest.length) {
              G.ph = 'buzzq'; G.d = { text: q.q, c: q.c, l: q.l, title: 'إجابة خاطئة! الفرصة للباقين', locked: m.locked, value: lv * 100, wrong: side, armAt: now() + 1000, qid: q.id };
              setT(11000, () => revealPlain(q, 'انتهى الوقت', () => M.buzzer.next())); push(); return false;
            }
            return true;
          },
          score(res) { if (res[side].ok) { add(side, lv * 100); return { [side]: lv * 100 }; } return { [side]: -lv * 50 }; },
          after: () => M.buzzer.next(), auto: 4500
        });
      });
    }
  };
  M.know = {
    start() { const q = []; for (let k = 0; k < G.cfg.knowTurns; k++) alive().forEach(s => q.push(s.id)); G.m = { queue: q, idx: 0 }; this.next(); },
    next() {
      const m = G.m; if (m.idx >= m.queue.length) return lb(() => nextRound());
      const side = m.queue[m.idx++]; const L = QB.getList(G.cfg.cats, G.cfg.levels, 6);
      m.cur = { side, L, found: [] };
      G.ph = 'kready'; G.d = { side, topic: L.t, total: L.items.length, c: L.c, l: L.l, title: `ماذا تعرف؟ ${m.idx}/${m.queue.length}`, time: G.cfg.knowTime };
      clearT(); G._next = () => M.know.go(); push();
    },
    go() { if (G.ph !== 'kready') return; G.ph = 'know'; G.d.found = []; G._next = null; setT(G.cfg.knowTime * 1000, () => M.know.end()); push(); },
    text(side, s, pid) { const cur = G.m.cur; if (G.ph !== 'know' || side !== cur.side || G.paused) return; if (tryItem(cur, s, side, 100)) stat(side, pid, true, null, cur.L.c); },
    manual() { const cur = G.m.cur; if (G.ph !== 'know') return; cur.found.push(-1); G.d.found.push('إجابة صحيحة (حَكَم)'); add(cur.side, 100); G.d.flash = 'ok'; G.d.fx = (G.d.fx || 0) + 1; push(); },
    end() { const cur = G.m.cur; clearT(); G.ph = 'kres'; G.d.missed = cur.L.items.filter((_, i) => !cur.found.includes(i)).map(x => x[0]).slice(0, 60); G.d.score = cur.found.length * 100; G._next = () => M.know.next(); push(); }
  };
  function tryItem(cur, s, side, pts) {
    let idx = cur.L.items.findIndex((al, i) => !cur.found.includes(i) && QB.match(s, al));
    if (idx < 0 && QB.bestMatch) { const b = QB.bestMatch(s, cur.L.items, cur.found); if (b >= 0) idx = b; }
    if (idx >= 0) { cur.found.push(idx); G.d.found.push(cur.L.items[idx][0]); add(side, pts); G.d.flash = 'ok'; }
    else { const dup = cur.L.items.findIndex((al, i) => cur.found.includes(i) && QB.match(s, al)); G.d.flash = dup >= 0 ? 'dup' : 'bad'; G.d.lastBad = s; }
    G.d.fx = (G.d.fx || 0) + 1;
    push();
    return idx >= 0;
  }
  M.auction = {
    start() { G.m = { k: 0, rounds: Math.max(2, Math.min(4, alive().length * 2)), starter: 0 }; this.topic(); },
    topic() {
      const m = G.m; clearT();
      if (m.k >= m.rounds || alive().length < 1) return lb(() => nextRound());
      const L = QB.getList(G.cfg.cats, G.cfg.levels, 8); const al = alive();
      m.cur = { L, bid: 0, bidder: null, passed: [], turn: m.starter % al.length, found: [] };
      G.ph = 'bid'; G.d = { topic: L.t, total: L.items.length, c: L.c, l: L.l, bid: 0, bidder: null, turn: al[m.cur.turn].id, passed: [], title: `المزاد ${m.k + 1}/${m.rounds}` };
      G._next = null; push();
    },
    advance() {
      const cur = G.m.cur, al = alive();
      const live = al.filter(s => !cur.passed.includes(s.id));
      if (cur.bidder && live.length === 1 && live[0].id === cur.bidder) return this.prove();
      if (!cur.bidder && live.length === 0) { G.m.k++; G.m.starter++; return this.topic(); }
      if (al.length === 1 && cur.bidder) return this.prove();
      let t = cur.turn; for (let k = 0; k < al.length; k++) { t = (t + 1) % al.length; const id = al[t].id; if (!cur.passed.includes(id) && id !== cur.bidder) break; }
      cur.turn = t; G.d.turn = al[t].id; G.d.bid = cur.bid; G.d.bidder = cur.bidder; G.d.passed = cur.passed; push();
    },
    bid(side, n) { const cur = G.m.cur; if (G.ph !== 'bid' || G.d.turn !== side) return; n = Math.floor(+n); if (!(n > cur.bid) || n > cur.L.items.length) return; cur.bid = n; cur.bidder = side; this.advance(); },
    pass(side) { const cur = G.m.cur; if (G.ph !== 'bid' || G.d.turn !== side) return; cur.passed.push(side); this.advance(); },
    prove() {
      const cur = G.m.cur; const T = Math.min(120, Math.max(30, 15 + cur.bid * 5));
      G.ph = 'know'; G.d = { side: cur.bidder, topic: cur.L.t, total: cur.L.items.length, target: cur.bid, found: [], c: cur.L.c, l: cur.L.l, title: `${nameOf(cur.bidder)} يجب أن يذكر ${cur.bid}`, auction: true };
      setT(T * 1000, () => M.auction.end()); push();
    },
    text(side, s) { const cur = G.m.cur; if (G.ph !== 'know' || side !== cur.bidder || G.paused) return; if (tryItem(cur, s, side, 0) && cur.found.length >= cur.bid) this.end(); },
    manual() { const cur = G.m.cur; if (G.ph !== 'know') return; cur.found.push(-1); G.d.found.push('إجابة صحيحة (حَكَم)'); G.d.flash = 'ok'; G.d.fx = (G.d.fx || 0) + 1; if (cur.found.length >= cur.bid) this.end(); else push(); },
    end() {
      const cur = G.m.cur; clearT(); const ok = cur.found.length >= cur.bid; const deltas = {};
      stat(cur.bidder, null, ok, null, cur.L.c);
      if (ok) { add(cur.bidder, cur.bid * 100); deltas[cur.bidder] = cur.bid * 100; }
      else { alive().filter(s => s.id !== cur.bidder).forEach(s => { add(s.id, cur.bid * 50); deltas[s.id] = cur.bid * 50; }); deltas[cur.bidder] = 0; }
      G.ph = 'kres'; G.d.auctionOk = ok; G.d.deltas = deltas; G.d.missed = cur.L.items.filter((_, i) => !cur.found.includes(i)).map(x => x[0]).slice(0, 60);
      G._next = () => { G.m.k++; G.m.starter++; M.auction.topic(); }; push();
    }
  };
  M.who = {
    start() { G.m = { i: 0, n: Math.max(3, Math.ceil(G.cfg.n / 2)) }; this.next(); },
    next() {
      const m = G.m; if (m.i >= m.n) return lb(() => nextRound());
      const w = QB.getWho(G.cfg.cats, G.cfg.levels); m.i++; m.w = w; m.shown = 1; m.locked = [];
      G.ph = 'who'; G.d = { clues: [w.clues[0]], total: w.clues.length, locked: [], buzzer: null, title: `من أنا؟ ${m.i}/${m.n}`, c: w.c, l: w.l, pts: 400 };
      G._next = null; this.tick(); push();
    },
    tick() {
      const m = G.m;
      setT(G.cfg.whoStep * 1000, () => {
        if (m.shown < m.w.clues.length) { m.shown++; G.d.clues = m.w.clues.slice(0, m.shown); m.locked = []; G.d.locked = []; G.d.pts = [400, 300, 200, 100][m.shown - 1] || 100; G.d.buzzer = null; this.tick(); push(); }
        else this.reveal(null, 0);
      });
    },
    buzz(side) { if (G.ph !== 'who' || G.m.locked.includes(side) || G.d.buzzer) return; G.d.buzzer = side; push(); },
    guess(side, s, pid) {
      const m = G.m; if (G.ph !== 'who' || m.locked.includes(side) || G.paused) return;
      if (G.local && G.d.buzzer !== side) return;
      if (QB.match(s, m.w.al)) { const pts = [400, 300, 200, 100][m.shown - 1] || 100; add(side, pts); stat(side, pid, true, null, m.w.c); this.reveal(side, pts); }
      else { m.locked.push(side); G.d.locked = m.locked.slice(); G.d.buzzer = null; G.d.wrong = { s: side, txt: s }; G.d.fx = (G.d.fx || 0) + 1; push(); }
    },
    giveup() { this.reveal(null, 0); },
    reveal(side, pts) { clearT(); const w = G.m.w; G.ph = 'reveal'; G.d = { kind: 'who', title: G.d.title, answer: w.a, clues: w.clues, res: side ? [{ s: side, ok: true, d: pts }] : [], c: w.c, l: w.l }; G._next = () => M.who.next(); push(); setT(6000, () => M.who.next()); }
  };

  // ---------- خلية الحروف ----------
  // شبكة 5×5 بإزاحة الصفوف الفردية. الأحمر (الفريق الأول) يصل العمود 0 بالعمود 4، والأزرق يصل الصف 0 بالصف 4
  function hexNb(r, c) {
    const odd = r % 2 === 1;
    const d = odd ? [[0, -1], [0, 1], [-1, 0], [-1, 1], [1, 0], [1, 1]] : [[0, -1], [0, 1], [-1, -1], [-1, 0], [1, -1], [1, 0]];
    return d.map(([a, b]) => [r + a, c + b]).filter(([a, b]) => a >= 0 && b >= 0 && a < HEX_N && b < HEX_N);
  }
  function hexWin(cells, owner, axis) {
    const own = (r, c) => cells[r * HEX_N + c].o === owner;
    const seen = new Set(); const st = [];
    for (let k = 0; k < HEX_N; k++) { const [r, c] = axis === 'h' ? [k, 0] : [0, k]; if (own(r, c)) { st.push([r, c]); seen.add(r * HEX_N + c); } }
    while (st.length) {
      const [r, c] = st.pop();
      if ((axis === 'h' && c === HEX_N - 1) || (axis === 'v' && r === HEX_N - 1)) return true;
      for (const [a, b] of hexNb(r, c)) { const k = a * HEX_N + b; if (!seen.has(k) && own(a, b)) { seen.add(k); st.push([a, b]); } }
    }
    return false;
  }
  M.hex = {
    start() {
      const al = alive(); const two = al.slice(0, 2).map(s => s.id);
      if (two.length < 2) two.push(null);
      let letters = QB.shuffle(QB.hexLetters()); while (letters.length < HEX_N * HEX_N) letters = letters.concat(QB.shuffle(QB.hexLetters()));
      const cells = letters.slice(0, HEX_N * HEX_N).map((ch, i) => ({ i, ch, o: null }));
      G.m = { two, cells, turn: two[0], used: new Set() };
      this.board();
    },
    board(msg) {
      clearT(); const m = G.m;
      G.ph = 'hexpick'; G.d = { cells: m.cells, two: m.two, turn: m.turn, msg: msg || '', title: 'خلية الحروف' };
      G._next = null; push();
    },
    pick(side, i) {
      const m = G.m; if (G.ph !== 'hexpick' || side !== m.turn) return;
      const cell = m.cells[i]; if (!cell || cell.o) return;
      const h = QB.getHex(cell.ch, G.cfg.cats, G.cfg.levels);
      if (!h) { cell.o = 'x'; return this.board('لا توجد أسئلة لهذا الحرف'); }
      m.cur = { cell, h, tried: [] };
      G.ph = 'hexq'; G.d = { cells: m.cells, two: m.two, cell: i, ch: cell.ch, text: h.q, c: h.c, l: h.l, buzzer: null, tried: [], title: `حرف «${cell.ch}»`, armAt: now() + 1000, qid: h.id };
      setT((G.cfg.timer + 10) * 1000, () => this.fail(null));
      push();
    },
    buzz(side) {
      const m = G.m; if (G.ph !== 'hexq' || G.d.buzzer || m.cur.tried.includes(side) || !m.two.includes(side) || G.paused) return;
      if (G.d.armAt && now() < G.d.armAt) return;
      G.d.buzzer = side; setT(Math.max(12, G.cfg.timer) * 1000, () => this.wrong(side, '')); push();
    },
    text(side, s, pid) {
      const m = G.m; if (G.ph !== 'hexq' || G.paused) return;
      if (!G.d.buzzer && !m.cur.tried.includes(side) && m.two.includes(side)) { G.d.buzzer = side; }
      if (G.d.buzzer !== side) return;
      if (QB.match(s, m.cur.h.al)) this.win(side, pid); else this.wrong(side, s, pid);
    },
    judge(ok) { const m = G.m; if (G.ph !== 'hexq' || !G.d.buzzer) return; if (ok) this.win(G.d.buzzer); else this.wrong(G.d.buzzer, ''); },
    win(side, pid) {
      const m = G.m; clearT(); m.cur.cell.o = side; add(side, 100); stat(side, pid, true, null, m.cur.h.c);
      const ax = side === m.two[0] ? 'h' : 'v';
      if (hexWin(m.cells, side, ax)) { add(side, 1000); G.ph = 'hexend'; G.d = { cells: m.cells, two: m.two, winner: side, answer: m.cur.h.a, title: 'خلية الحروف' }; G._next = () => lb(() => nextRound()); push(); return; }
      m.turn = side;
      G.ph = 'hexres'; G.d = Object.assign({}, G.d, { ok: side, answer: m.cur.h.a, cells: m.cells });
      G._next = () => this.board(); push(); setT(3000, () => this.board());
    },
    wrong(side, txt, pid) {
      const m = G.m; clearT(); m.cur.tried.push(side); stat(side, pid, false, null, m.cur.h.c);
      const other = m.two.find(s => s && s !== side && !m.cur.tried.includes(s));
      if (other) { G.d.buzzer = other; G.d.tried = m.cur.tried.slice(); G.d.wrong = { s: side, txt }; G.d.fx = (G.d.fx || 0) + 1; setT(Math.max(12, G.cfg.timer) * 1000, () => this.wrong(other, '')); push(); }
      else this.fail(txt);
    },
    fail() {
      const m = G.m; clearT();
      const left = m.cells.filter(c => !c.o).length;
      G.ph = 'hexres'; G.d = Object.assign({}, G.d, { ok: null, answer: m.cur.h.a, cells: m.cells });
      const nx = () => { if (!left) return lb(() => nextRound()); m.turn = m.two.find(s => s && s !== m.turn) || m.turn; this.board(); };
      G._next = nx; push(); setT(3500, nx);
    }
  };

  // ---------- حرب الفئات ----------
  M.catwar = {
    start() { const al = alive(); G.m = { i: 0, n: Math.max(2, Math.ceil(G.cfg.n / 2)) * al.length }; this.choose(); },
    chooser() { const al = alive(); return al[G.m.i % al.length].id; },
    target() { const al = alive(); return al.length > 1 ? al[(G.m.i + 1) % al.length].id : al[0].id; },
    choose() {
      clearT(); const m = G.m; if (m.i >= m.n) return lb(() => nextRound());
      let cats = G.cfg.cats.filter(c => QB.cats[c] && (QB.mcq.some(q => q.c === c) || c === 'math'));
      cats = QB.shuffle(cats).slice(0, 8);
      m.cats = cats;
      G.ph = 'cwpick'; G.d = { chooser: this.chooser(), target: this.target(), cats: cats.map(c => ({ id: c, name: QB.cats[c].name, icon: QB.cats[c].icon })), levels: G.cfg.levels.slice().sort(), title: `حرب الفئات ${m.i + 1}/${m.n}` };
      G._next = null; push();
    },
    pick(side, c, l) {
      const m = G.m; if (G.ph !== 'cwpick' || side !== G.d.chooser || !m.cats.includes(c)) return;
      l = +l; if (!(l >= 1 && l <= 4)) return;
      const ch = G.d.chooser, tg = G.d.target; m.i++;
      const q = QB.getMCQ([c], [l]);
      ask({
        kind: 'mcq', q, who: [tg], time: G.cfg.timer, title: `${QB.cats[c].icon} ${QB.cats[c].name} — ${LVL[l]}`, sub: `${nameOf(ch)} اختار هذا السؤال لـ ${nameOf(tg)}`, value: l * 100,
        score(res) { const d = {}; if (res[tg].ok) { d[tg] = l * 100; add(tg, l * 100); } else if (ch !== tg) { d[ch] = l * 50; add(ch, l * 50); d[tg] = 0; } return d; },
        after: () => M.catwar.choose(), auto: 4500
      });
    }
  };

  // ---------- صورة وتخمين ----------
  M.emoji = {
    start() { G.m = { i: 0, n: G.cfg.n }; this.next(); },
    next() {
      const m = G.m; const total = m.n * (G.local ? alive().length : 1); if (m.i >= total) return nextRound();
      const e = QB.getEmoji(G.cfg.cats, [levelFor(m.i, total)]); if (!e) return nextRound();
      let w = e.w.length >= 3 ? e.w.slice(0, 3) : QB.shuffle(QB.emoji.filter(x => x.t === e.t && x.a !== e.a).map(x => x.a)).slice(0, 3);
      const opts = QB.shuffle([e.a, ...w]);
      const q = { id: e.id, c: e.c, l: e.l, q: `النوع: ${e.t}`, opts, ans: opts.indexOf(e.a), a: e.a };
      const who = G.local ? rotateWho(m.i) : alive().map(s => s.id); m.i++;
      const T = Math.max(15, G.cfg.timer);
      ask({ kind: 'mcq', q, who, time: T, emo: e.e, title: `صورة وتخمين ${m.i}/${total}`, sub: G.local ? 'دور: ' + nameOf(who[0]) : '', score: speedScore(T, 300, 400), after: () => { if (m.i % 3 === 0) lb(() => M.emoji.next()); else M.emoji.next(); }, auto: 3500 });
    }
  };

  // ---------- السلسلة ----------
  function lastLetter(s) {
    let t = String(s).trim().replace(/[ً-ْ]/g, '');
    let ch = t.slice(-1);
    if ('ءئؤ'.includes(ch) && t.length > 1) ch = t.slice(-2, -1);
    if (ch === 'ى') ch = 'ي';
    if ('أإآ'.includes(ch)) ch = 'ا';
    return ch;
  }
  function firstLetter(s) {
    let t = String(s).trim().replace(/[ً-ْ]/g, '').replace(/^ال(?=..)/, '');
    let ch = t[0] || '';
    if ('أإآ'.includes(ch)) ch = 'ا';
    return ch;
  }
  function chainOk(req, s) { const f = firstLetter(s); if (req === 'ة') return f === 'ه' || f === 'ت'; if (req === 'ا') return f === 'ا'; return f === req; }
  M.chain = {
    start() {
      const ch = QB.getChain(G.cfg.cats, G.cfg.levels); if (!ch) return nextRound();
      const al = alive();
      G.m = { ch, order: al.map(s => s.id), out: [], turn: 0, used: [], req: null, count: 0, solo: al.length === 1 };
      const starters = ch.items.map(x => firstLetter(x[0])); G.m.req = QB.pick(starters);
      this.turn();
    },
    live() { return G.m.order.filter(s => !G.m.out.includes(s)); },
    turn() {
      clearT(); const m = G.m; const L = this.live();
      if ((!m.solo && L.length <= 1) || !L.length || m.count >= 60) { L.forEach(s => add(s, 500)); return this.finish(L[0] || null); }
      // لا يوجد عنصر متاح بالحرف المطلوب: اختر حرفاً جديداً
      const avail = m.ch.items.filter((x, i) => !m.used.includes(i) && chainOk(m.req, x[0]));
      if (!avail.length) { const rest = m.ch.items.filter((x, i) => !m.used.includes(i)); if (!rest.length) return this.finish(null); m.req = firstLetter(QB.pick(rest)[0]); m.msg = (m.msg ? m.msg + ' — ' : '') + 'لا إجابات متبقية بذلك الحرف، حرف جديد'; }
      const side = L[m.turn % L.length]; m.cur = side;
      const T = Math.max(10, Math.min(25, G.cfg.timer));
      G.ph = 'chain'; G.d = { topic: m.ch.t, req: m.req, side, used: m.used.map(i => m.ch.items[i][0]), out: m.out, c: m.ch.c, l: m.ch.l, title: `السلسلة — ${m.ch.t}`, msg: m.msg || '', flash: m.flash || '', fx: (m.fx = (m.fx || 0) + 1) };
      m.msg = ''; m.flash = '';
      setT(T * 1000, () => this.fail(side, 'انتهى الوقت'));
      push();
    },
    text(side, s, pid) {
      const m = G.m; if (G.ph !== 'chain' || side !== m.cur || G.paused) return;
      if (!chainOk(m.req, s)) { G.d.bad = `"${s}" لا يبدأ بحرف «${m.req}»`; G.d.fx = (G.d.fx || 0) + 1; push(); return; }
      let idx = m.ch.items.findIndex((al, i) => QB.match(s, al) && chainOk(m.req, al[0]));
      if (idx >= 0 && m.used.includes(idx)) { G.d.bad = 'ذُكرت من قبل!'; G.d.fx = (G.d.fx || 0) + 1; push(); return; }
      if (idx < 0) { G.d.bad = `"${s}" غير موجودة في القائمة`; G.d.fx = (G.d.fx || 0) + 1; push(); return; }
      m.used.push(idx); m.count++; add(side, 100); stat(side, pid, true, null, m.ch.c);
      const word = m.ch.items[idx][0];
      m.req = lastLetter(word); m.turn++; m.msg = `${nameOf(side)}: ${word} ✓`; m.flash = 'ok';
      this.turn();
    },
    judge(ok) { const m = G.m; if (G.ph !== 'chain') return; if (ok) { m.count++; add(m.cur, 100); m.turn++; m.msg = 'قبلها الحَكَم ✓'; m.flash = 'ok'; this.turn(); } else this.fail(m.cur, 'رفضها الحَكَم'); },
    fail(side, why) {
      const m = G.m; clearT(); stat(side, null, false, null, m.ch.c);
      if (m.solo) return this.finish(null);
      m.out.push(side); m.msg = `${nameOf(side)} خرج من السلسلة (${why})`; m.flash = 'bad';
      this.turn();
    },
    finish(winner) {
      clearT(); const m = G.m;
      const ex = m.ch.items.filter((x, i) => !m.used.includes(i)).map(x => x[0]).slice(0, 40);
      G.ph = 'chainend'; G.d = { topic: m.ch.t, winner, count: m.count, used: m.used.map(i => m.ch.items[i][0]), missed: ex, title: 'السلسلة', c: m.ch.c, l: m.ch.l };
      G._next = () => lb(() => nextRound()); push();
    }
  };

  // ---------- الأقرب يربح ----------
  M.near = {
    start() { G.m = { i: 0, n: Math.max(3, Math.ceil(G.cfg.n / 2)) }; this.next(); },
    next() {
      const m = G.m; if (m.i >= m.n) return lb(() => nextRound());
      const nq = QB.getNear(G.cfg.cats, G.cfg.levels); if (!nq) return nextRound(); m.i++;
      const q = { id: nq.id, c: nq.c, l: nq.l, q: nq.q, v: nq.v, a: nq.v + (nq.u ? ' ' + nq.u : ''), i: nq.i };
      const who = alive().map(s => s.id);
      ask({
        kind: 'near', q, who, time: Math.max(20, G.cfg.timer), unit: nq.u, title: `الأقرب يربح ${m.i}/${m.n}`,
        score(res) {
          const arr = who.filter(s => !res[s].timeout && res[s].n != null).map(s => ({ s, e: Math.abs(res[s].n - q.v) })).sort((a, b) => a.e - b.e);
          const d = {}; who.forEach(s => d[s] = 0);
          if (arr.length) {
            const best = arr[0].e; const firsts = arr.filter(x => x.e === best);
            firsts.forEach(x => { d[x.s] = 500 + (best === 0 ? 500 : 0); });
            const rest = arr.filter(x => x.e > best); if (rest.length && arr.length > 2) { const e2 = rest[0].e; rest.filter(x => x.e === e2).forEach(x => d[x.s] = 250); }
          }
          who.forEach(s => { add(s, d[s]); stat(s, res[s].pid, d[s] >= 500, null, q.c); });
          return d;
        },
        after: () => lb(() => M.near.next()), auto: 6000
      });
    }
  };

  // ---------- استقبال الأفعال ----------
  function act(pid, a) {
    if (!G) return;
    const p = G.players[pid]; let side = p ? p.side : null;
    if (G.local && a.as) side = a.as;
    const isHost = pid === G.hostPid || G.local;
    if (G.paused && !(isHost && (a.type === 'resume' || a.type === 'pause'))) return;
    switch (a.type) {
      case 'next': if (isHost && G._next) { const f = G._next; G._next = null; clearT(); f(); } break;
      case 'pause': if (isHost) pause(); break;
      case 'resume': if (isHost) resume(); break;
      case 'answer': answer(side, pid, a); break;
      case 'cell': if (G.mode === 'board' && G.ph === 'pick' && (side === G.d.turn || isHost && G.local)) { const c = G.m.cells.find(x => x.id === a.id && !x.used); if (c) M.board.open(c); } break;
      case 'helper': if (G.mode === 'board') M.board.helper(side, a.h); break;
      case 'judge': if (!isHost) break; if (G.mode === 'board') M.board.judge(a); else if (G.mode === 'hex') M.hex.judge(a.ok); else if (G.mode === 'chain') M.chain.judge(a.ok); break;
      case 'buzz': if (G.mode === 'buzzer') M.buzzer.buzz(side); else if (G.mode === 'who') M.who.buzz(side); else if (G.mode === 'hex') M.hex.buzz(side); break;
      case 'kgo': if (G.mode === 'know' && (side === G.d.side || isHost)) M.know.go(); break;
      case 'text':
        if (G.mode === 'know') M.know.text(side, a.s, pid); else if (G.mode === 'auction') M.auction.text(side, a.s); else if (G.mode === 'who') M.who.guess(side, a.s, pid);
        else if (G.mode === 'hex') M.hex.text(side, a.s, pid); else if (G.mode === 'chain') M.chain.text(side, a.s, pid);
        break;
      case 'manual': if (isHost) { if (G.mode === 'know') M.know.manual(); else if (G.mode === 'auction') M.auction.manual(); } break;
      case 'kend': if ((isHost || side === G.d.side) && G.ph === 'know') { if (G.mode === 'know') M.know.end(); else M.auction.end(); } break;
      case 'bid': if (G.mode === 'auction') M.auction.bid(side, a.n); break;
      case 'pass': if (G.mode === 'auction') M.auction.pass(side); break;
      case 'giveup': if (isHost && G.mode === 'who') M.who.giveup(); break;
      case 'hexcell': if (G.mode === 'hex') M.hex.pick(G.local ? G.m.turn : side, a.i); break;
      case 'cwpick': if (G.mode === 'catwar') M.catwar.pick(G.local ? G.d.chooser : side, a.c, a.l); break;
      case 'skipround': if (isHost) nextRound(); break;
    }
  }
  function addPlayer(pid, pl, side) { if (!G) return; G.players[pid] = pl; if (side && !S(side.id)) G.sides.push({ ...side, score: 0, streak: 0, last: 0 }); push(); }
  function setOnline(pid, on) { if (!G) return; G.online = G.online || {}; if (G.online[pid] === on) return; G.online[pid] = on; push(); }
  function stop() { clearT(); G = null; }
  return { init, act, addPlayer, setOnline, stop, push, get G() { return G; }, onState: null, M, _t: { hexWin, lastLetter, firstLetter, chainOk } };
})();
