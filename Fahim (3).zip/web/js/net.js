/* شبكة فهيم: اتصال مباشر (WebRTC عبر PeerJS + خوادم TURN) مع ترحيل احتياطي عبر MQTT فوق WSS
   - المعرّف المنطقي لكل لاعب (uid) ثابت على جهازه، فإعادة الاتصال تحفظ مقعده ونقاطه
   - المضيف يستمع على القناتين معاً، والعميل يجرب المباشر ثم الترحيل تلقائياً */
(function () {
  const NS = 'fahimq/v2/';
  const BROKERS = ['wss://broker.emqx.io:8084/mqtt', 'wss://broker.hivemq.com:8884/mqtt', 'wss://test.mosquitto.org:8081/mqtt'];
  const enc = new TextEncoder(), dec = new TextDecoder();

  // ---------- عميل MQTT 3.1.1 مصغّر (QoS 0) ----------
  function MQ(url, onMsg, onState) {
    this.url = url; this.onMsg = onMsg; this.onState = onState || (() => { }); this.subs = new Set(); this.ok = false; this.buf = new Uint8Array(0); this.closed = false;
    this.cid = 'fh' + Math.random().toString(36).slice(2, 12);
    this.open();
  }
  const str = s => { const b = enc.encode(s); const o = new Uint8Array(2 + b.length); o[0] = b.length >> 8; o[1] = b.length & 255; o.set(b, 2); return o; };
  const cat = (...a) => { const n = a.reduce((x, y) => x + y.length, 0); const o = new Uint8Array(n); let k = 0; a.forEach(x => { o.set(x, k); k += x.length; }); return o; };
  const remLen = n => { const o = []; do { let d = n % 128; n = Math.floor(n / 128); if (n > 0) d |= 128; o.push(d); } while (n > 0); return new Uint8Array(o); };
  const pkt = (h, body) => cat(new Uint8Array([h]), remLen(body.length), body);
  MQ.prototype.open = function () {
    let ws; try { ws = new WebSocket(this.url, ['mqtt']); } catch (e) { this.onState('fail'); return; }
    ws.binaryType = 'arraybuffer'; this.ws = ws;
    ws.onopen = () => { const vh = cat(str('MQTT'), new Uint8Array([4, 2, 0, 30])); ws.send(pkt(0x10, cat(vh, str(this.cid)))); };
    ws.onmessage = e => { this.buf = cat(this.buf, new Uint8Array(e.data)); this.parse(); };
    ws.onclose = () => { const was = this.ok; this.ok = false; clearInterval(this.pi); if (!this.closed) this.onState(was ? 'lost' : 'fail'); };
    ws.onerror = () => { };
  };
  MQ.prototype.parse = function () {
    for (; ;) {
      const b = this.buf; if (b.length < 2) return;
      let mul = 1, len = 0, i = 1, d;
      do { if (i >= b.length) return; d = b[i++]; len += (d & 127) * mul; mul *= 128; } while (d & 128);
      if (b.length < i + len) return;
      const type = b[0] >> 4, body = b.subarray(i, i + len); this.buf = b.slice(i + len);
      if (type === 2) { if (body[1] === 0) { this.ok = true; this.subs.forEach(t => this._sub(t)); this.pi = setInterval(() => { try { this.ws.send(new Uint8Array([0xC0, 0])); } catch (e) { } }, 20000); this.onState('ok'); } else this.onState('fail'); }
      else if (type === 3) { const tl = (body[0] << 8) | body[1]; const topic = dec.decode(body.subarray(2, 2 + tl)); const qos = (b[0] >> 1) & 3; const off = 2 + tl + (qos ? 2 : 0); try { this.onMsg(topic, JSON.parse(dec.decode(body.subarray(off)))); } catch (e) { } }
    }
  };
  MQ.prototype._sub = function (t) { const id = 1 + Math.floor(Math.random() * 60000); try { this.ws.send(pkt(0x82, cat(new Uint8Array([id >> 8, id & 255]), str(t), new Uint8Array([0])))); } catch (e) { } };
  MQ.prototype.sub = function (t) { this.subs.add(t); if (this.ok) this._sub(t); };
  MQ.prototype.pub = function (t, obj) { if (!this.ok) return false; try { this.ws.send(pkt(0x30, cat(str(t), enc.encode(JSON.stringify(obj))))); return true; } catch (e) { return false; } };
  MQ.prototype.close = function () { this.closed = true; clearInterval(this.pi); try { this.ws.send(new Uint8Array([0xE0, 0])); this.ws.close(); } catch (e) { } };
  // يجرّب الوسطاء بالترتيب حتى ينجح أحدها
  function relay(onMsg, onState, start) {
    const R = { m: null, i: start || 0, subs: [], closed: false, state: 'connecting' };
    const tryOne = () => {
      if (R.closed) return;
      const url = BROKERS[R.i % BROKERS.length];
      R.m = new MQ(url, onMsg, st => {
        if (R.closed) return;
        if (st === 'ok') { R.state = 'ok'; onState('ok'); }
        else { R.state = 'down'; onState(st); R.i++; setTimeout(tryOne, st === 'lost' ? 500 : 1200); }
      });
      R.subs.forEach(t => R.m.sub(t));
    };
    R.sub = t => { R.subs.push(t); if (R.m) R.m.sub(t); };
    R.pub = (t, o) => R.m && R.m.pub(t, o);
    R.close = () => { R.closed = true; R.m && R.m.close(); };
    tryOne();
    return R;
  }

  // ---------- إعدادات ICE ----------
  function iceServers() {
    let custom = [];
    try { const c = JSON.parse(localStorage.getItem('fahim_turn') || 'null'); if (c) { if (Array.isArray(c.json)) custom = c.json; else if (c.url) custom = [{ urls: c.url.split(/[\s,]+/).filter(Boolean), username: c.user || undefined, credential: c.pass || undefined }]; } } catch (e) { }
    return custom.concat([
      { urls: ['stun:stun.l.google.com:19302', 'stun:stun1.l.google.com:19302', 'stun:stun.cloudflare.com:3478'] },
      { urls: 'turn:openrelay.metered.ca:80', username: 'openrelayproject', credential: 'openrelayproject' },
      { urls: 'turn:openrelay.metered.ca:443', username: 'openrelayproject', credential: 'openrelayproject' },
      { urls: 'turn:openrelay.metered.ca:443?transport=tcp', username: 'openrelayproject', credential: 'openrelayproject' },
      { urls: 'turns:openrelay.metered.ca:443?transport=tcp', username: 'openrelayproject', credential: 'openrelayproject' }
    ]);
  }
  const forceRelay = () => { try { return (JSON.parse(localStorage.getItem('fahim_turn') || '{}') || {}).relayOnly; } catch (e) { return false; } };
  const peerOpts = () => ({ debug: 0, config: { iceServers: iceServers(), iceTransportPolicy: 'all' } });

  // ---------- المضيف ----------
  // cb.onOpen(code) cb.onMsg(uid, msg) cb.onPresence(uid, online, via) cb.onError(text)
  function Host(cb) {
    const H = { peers: {}, last: {}, via: {}, code: null, rl: null, peer: null, p2p: false, relayOk: false };
    const code = String(1000 + Math.floor(Math.random() * 9000));
    H.code = code;
    const deliver = (uid, msg, via, conn) => {
      if (!uid) return;
      H.last[uid] = Date.now();
      if (via === 'p2p' && conn) { H.peers[uid] = conn; H.via[uid] = 'p2p'; }
      else if (!(H.peers[uid] && H.peers[uid].open)) H.via[uid] = 'relay';
      if (msg.t !== 'hb') cb.onMsg(uid, msg);
      cb.onPresence(uid, true, H.via[uid]);
    };
    // القناة المباشرة
    const startPeer = (id) => {
      try { H.peer = new Peer(id, peerOpts()); } catch (e) { return; }
      H.peer.on('open', () => { H.p2p = true; cb.onStatus && cb.onStatus(H); });
      H.peer.on('error', e => {
        if (e.type === 'unavailable-id') { /* رمز مشغول: نبقى على الترحيل بنفس الرمز */ }
        else if (['network', 'server-error', 'socket-error', 'socket-closed'].includes(e.type)) { H.p2p = false; cb.onStatus && cb.onStatus(H); setTimeout(() => { if (H.peer && H.peer.disconnected && !H.peer.destroyed) try { H.peer.reconnect(); } catch (x) { } }, 3000); }
      });
      H.peer.on('disconnected', () => { H.p2p = false; cb.onStatus && cb.onStatus(H); setTimeout(() => { try { if (H.peer && !H.peer.destroyed) H.peer.reconnect(); } catch (x) { } }, 2000); });
      H.peer.on('connection', c => {
        let uid = null;
        c.on('data', m => { if (m && m.uid) uid = m.uid; deliver(uid, m, 'p2p', c); });
        c.on('close', () => { if (uid && H.peers[uid] === c) { delete H.peers[uid]; if (H.via[uid] === 'p2p') H.via[uid] = null; } });
      });
    };
    if (!forceRelay()) startPeer('fahim-' + code);
    // قناة الترحيل
    H.rl = relay((topic, m) => { if (m && m.uid) deliver(m.uid, m, 'relay'); }, st => { H.relayOk = st === 'ok'; cb.onStatus && cb.onStatus(H); });
    H.rl.sub(NS + code + '/h');
    setTimeout(() => cb.onOpen(code), 50);
    // مراقبة الحضور
    H.watch = setInterval(() => {
      const t = Date.now();
      for (const uid in H.last) { const on = t - H.last[uid] < 9000; if (on !== H['on_' + uid]) { H['on_' + uid] = on; cb.onPresence(uid, on, H.via[uid]); } }
      H.bcast({ t: 'ping' });
    }, 3000);
    H.send = (uid, m) => {
      const c = H.peers[uid];
      if (H.via[uid] === 'p2p' && c && c.open) { try { c.send(m); return; } catch (e) { } }
      H.rl.pub(NS + code + '/c/' + uid, m);
    };
    H.bcast = (m) => {
      let anyRelay = false;
      for (const uid in H.last) { if (H.via[uid] === 'p2p' && H.peers[uid] && H.peers[uid].open) { try { H.peers[uid].send(m); } catch (e) { anyRelay = true; } } else anyRelay = true; }
      if (anyRelay) H.rl.pub(NS + code + '/b', m);
    };
    H.drop = uid => { delete H.last[uid]; delete H.via[uid]; delete H.peers[uid]; delete H['on_' + uid]; };
    H.close = () => { clearInterval(H.watch); try { H.peer && H.peer.destroy(); } catch (e) { } H.rl && H.rl.close(); };
    return H;
  }

  // ---------- العميل ----------
  // cb.onMsg(msg) cb.onLink(state: 'p2p'|'relay'|'connecting'|'lost') cb.onFail(text)
  function Client(code, uid, hello, cb) {
    const C = { via: null, conn: null, rl: null, peer: null, lastHost: 0, closed: false, gotHello: false };
    const got = (m, via) => {
      C.lastHost = Date.now();
      if (!C.via || (via === 'p2p' && C.via !== 'p2p')) { C.via = via; cb.onLink(via); }
      if (m.t === 'hello') C.gotHello = true;
      if (m.t !== 'ping') cb.onMsg(m);
    };
    const sendJoin = () => {
      const m = Object.assign({ t: 'join', uid }, hello);
      if (C.conn && C.conn.open) try { C.conn.send(m); } catch (e) { }
      C.rl && C.rl.pub(NS + code + '/h', m);
    };
    // الترحيل يبدأ فوراً بالتوازي
    C.rl = relay((topic, m) => got(m, 'relay'), st => { if (st === 'ok') sendJoin(); });
    C.rl.sub(NS + code + '/b'); C.rl.sub(NS + code + '/c/' + uid);
    const startP2P = () => {
      if (C.closed || forceRelay()) return;
      try { C.peer && C.peer.destroy(); } catch (e) { }
      try { C.peer = new Peer(peerOpts()); } catch (e) { return; }
      C.peer.on('open', () => {
        const c = C.peer.connect('fahim-' + code, { reliable: true }); C.conn = c;
        c.on('open', () => { try { c.send(Object.assign({ t: 'join', uid }, hello)); } catch (e) { } });
        c.on('data', m => got(m, 'p2p'));
        c.on('close', () => { if (C.via === 'p2p') { C.via = C.rl && C.rl.state === 'ok' ? 'relay' : null; cb.onLink(C.via || 'connecting'); if (C.via === 'relay') sendJoin(); } C.conn = null; if (!C.closed) setTimeout(startP2P, 4000); });
      });
      C.peer.on('error', e => { if (e.type === 'peer-unavailable') { /* قد يكون المضيف على الترحيل فقط */ } });
    };
    startP2P();
    C.send = m => {
      m.uid = uid;
      if (C.via === 'p2p' && C.conn && C.conn.open) { try { C.conn.send(m); return; } catch (e) { } }
      C.rl.pub(NS + code + '/h', m);
    };
    // نبض + اكتشاف الانقطاع + إعادة الاتصال
    C.hb = setInterval(() => {
      if (C.closed) return;
      C.send({ t: 'hb' });
      const age = Date.now() - C.lastHost;
      if (C.lastHost && age > 10000 && C.via) { C.via = null; cb.onLink('lost'); }
      if (!C.lastHost || age > 10000) sendJoin();
    }, 3000);
    C.fail = setTimeout(() => { if (!C.gotHello && !C.closed) cb.onFail('تعذّر الوصول إلى الغرفة ' + code + '. تأكد من الرمز ومن اتصال الإنترنت لدى الطرفين.'); }, 15000);
    C.close = () => { C.closed = true; clearInterval(C.hb); clearTimeout(C.fail); try { C.peer && C.peer.destroy(); } catch (e) { } C.rl && C.rl.close(); };
    return C;
  }
  window.FNET = { Host, Client, iceServers, BROKERS };
})();
