/* واجهة فهيم + الشبكة */
(function () {
  const $app = document.getElementById('app');
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const EMO = window.GLYPHS;
  const COL = ['#b4373f', '#2f62b8', '#c69c2d', '#2f8a5e', '#7c4dbe', '#1f8fa3', '#b8467a', '#c06a2b'];
  const SHAPES = ['أ', 'ب', 'ج', 'د'];
  const store = { get(k, d) { try { const v = localStorage.getItem('fahim_' + k); return v ? JSON.parse(v) : d; } catch (e) { return d; } }, set(k, v) { try { localStorage.setItem('fahim_' + k, JSON.stringify(v)); } catch (e) { } } };
  const DEF_MODES = ['board', 'kahoot', 'buzzer', 'wager', 'cipher', 'who', 'near'];

  const A = {
    scr: 'home', role: null, myPid: null, V: null, prev: null, lobby: null, code: null, link: null, pres: {}, off: 0,
    cfg: Object.assign({ modes: DEF_MODES, cats: null, levels: [1, 2, 3, 4], timer: 20, n: 8, style: 'mcq', curve: true, knowTime: 60, knowTurns: 1, whoStep: 10, lives: 2, copies: 1, teams: false, hostPlays: true }, store.get('cfg', {})),
    sides: store.get('sides', [{ name: 'الفريق الأول', emoji: '♛', color: COL[0] }, { name: 'الفريق الثاني', emoji: '♞', color: COL[1] }]),
    me: store.get('me', { name: '', emoji: EMO[QB.rnd(EMO.length)] }),
    uid: store.get('uid', null),
    sel: {}, ord: [], typed: '', localEnd: 0
  };
  window.__fahim = A;
  if (!A.uid) { A.uid = 'u' + Math.random().toString(36).slice(2, 10); store.set('uid', A.uid); }
  A.cfg.modes = (A.cfg.modes || []).filter(m => MODES[m]); if (!A.cfg.modes.length) A.cfg.modes = DEF_MODES.slice();
  A.sides.forEach((s, i) => { if (!EMO.includes(s.emoji)) s.emoji = EMO[i % EMO.length]; if (!COL.includes(s.color)) s.color = COL[i % COL.length]; });
  if (!EMO.includes(A.me.emoji)) A.me.emoji = EMO[0];

  function modal(text, btns, cls) {
    return new Promise(res => {
      const m = document.createElement('div'); m.className = 'modal';
      m.innerHTML = `<div class="mbox ${cls || ''}"><p>${text}</p><div class="mbtns">${btns.map((b, i) => `<button class="btn ${i === 0 ? 'gold' : ''}" data-i="${i}">${b}</button>`).join('')}</div></div>`;
      m.addEventListener('click', e => { const b = e.target.closest('[data-i]'); if (b) { m.remove(); res(+b.dataset.i); } else if (e.target === m) { m.remove(); res(-1); } });
      document.body.appendChild(m);
    });
  }
  function toast(t, ms) { const d = document.createElement('div'); d.className = 'toast'; d.textContent = t; document.body.appendChild(d); setTimeout(() => d.remove(), ms || 2800); }
  window.toast = toast;
  function go(s) { A.scr = s; render(); window.scrollTo(0, 0); }

  // ---------- الشبكة ----------
  // ---------- إبقاء الاتصال حياً في الخلفية (خدمة أندرويد) + حفظ الجلسة ----------
  const NT = () => Math.max(2, Math.min(4, A.cfg.nTeams || 2));
  function keepAlive(on, text) { try { if (window.FahimAndroid && FahimAndroid.keep) FahimAndroid.keep(!!on, text || ''); } catch (e) { } }
  let hsT = 0;
  function saveHost(force) {
    if (A.role !== 'host' || !A.H || !A.code) return;
    const t = Date.now(); if (!force && t - hsT < 1500) return; hsT = t;
    store.set('hsess', { code: A.code, t, lobby: A.lobby || {}, hostTeam: A.hostTeam || 0, snap: E.G ? E.snap() : null, cfg: A.cfg });
  }
  let csT = 0;
  function saveClient(force) { if (A.role !== 'client' || !A.C || !A.code) return; const t = Date.now(); if (!force && t - csT < 5000) return; csT = t; store.set('csess', { pin: A.code, t }); }
  function clearSess() { try { localStorage.removeItem('fahim_hsess'); localStorage.removeItem('fahim_csess'); } catch (e) { } }

  function hostOpen(resumeCode, sn) {
    A.lobby = (sn && sn.lobby) || {}; A.pres = {}; A.myPid = 'host'; if (sn) A.hostTeam = sn.hostTeam || 0;
    A.H = FNET.Host({
      onOpen(code) { A.code = code; keepAlive(true, 'أنت تستضيف غرفة ' + code + ' — الاتصال محفوظ حتى لو خرجت من التطبيق'); saveHost(true); render(); },
      onStatus() { if (A.scr === 'lobby') render(); },
      onMsg(uid, m) { onHostMsg(uid, m); },
      onPresence(uid, on, via) {
        A.pres[uid] = { on, via };
        if (E.G) { E.setOnline(uid, on); if (!on && E.G.players[uid]) toast(`${E.G.players[uid].name} انقطع اتصاله — مقعده محفوظ`); }
        else if (A.scr === 'lobby') render();
      }
    }, resumeCode);
  }
  // أصغر فريق عدداً (لتوزيع المنضمين تلقائياً)
  function smallestTeam(list) { const n = NT(); const c = Array(n).fill(0); list.forEach(p => { if (p.team < n) c[p.team]++; }); return c.indexOf(Math.min(...c)); }
  function lobbyAll() { const all = Object.values(A.lobby || {}); if (A.cfg.hostPlays) all.push({ id: 'host', team: A.hostTeam || 0 }); return all; }
  function onHostMsg(uid, m) {
    if (m.t === 'join') {
      A.H.send(uid, { t: 'hello', pid: uid, code: A.code });
      if (E.G) {
        if (E.G.players[uid]) { E.setOnline(uid, true); E.push(); }
        else {
          const tsides = E.G.sides.filter(x => /^t\d$/.test(x.id));
          if (tsides.length) {
            // نظام الفرق: المنضم المتأخر يدخل الفريق الأقل عدداً
            const cnt = id => Object.values(E.G.players).filter(p => p.side === id).length;
            const want = A.lobby && A.lobby[uid] ? 't' + A.lobby[uid].team : null;
            const sid = want && tsides.some(x => x.id === want) ? want : tsides.slice().sort((a, b) => cnt(a.id) - cnt(b.id))[0].id;
            E.addPlayer(uid, { id: uid, name: m.name || 'لاعب', emoji: m.emoji, side: sid });
          } else { const sid = 's' + uid; E.addPlayer(uid, { id: uid, name: m.name || 'لاعب', emoji: m.emoji, side: sid }, { id: sid, name: m.name || 'لاعب', emoji: m.emoji, color: COL[E.G.sides.length % COL.length] }); }
        }
      } else {
        const old = A.lobby[uid];
        A.lobby[uid] = { id: uid, name: m.name || 'لاعب', emoji: m.emoji || '🙂', team: old ? old.team : smallestTeam(lobbyAll()) };
        saveHost(true);
        hostLobbyBroadcast(); render(); if (!old) SFX.coin();
      }
    } else if (m.t === 'act') { E.act(uid, m.a); }
    else if (m.t === 'report') { QB.report(m.q, m.reason); }
    else if (m.t === 'vpub') { setVpub(uid, m.team, !!m.on); }
    else if (m.t === 'cap') { if (!E.G && A.lobby[uid] && A.cfg.teams && A.cfg.captains) { const tm = A.lobby[uid].team; A.capPick = A.capPick || {}; const cur = A.capPick[tm]; if (m.off) { if (cur === uid) A.capPick[tm] = null; } else if (!cur || cur === uid || !lobbyAll().some(p => p.id === cur && p.team === tm) || (A.pres[cur] && A.pres[cur].on === false)) A.capPick[tm] = uid; hostLobbyBroadcast(); saveHost(true); render(); } }
    else if (m.t === 'team') { if (!E.G && A.lobby[uid] && A.cfg.teams) { const n = +m.team; if (n >= 0 && n < NT()) { A.lobby[uid].team = n; hostLobbyBroadcast(); saveHost(true); render(); } } }
    else if (m.t === 'leave') { if (!E.G && A.lobby[uid]) { delete A.lobby[uid]; A.H.drop(uid); hostLobbyBroadcast(); render(); } }
  }
  // ---------- الغرفة الصوتية ----------
  // من يحق له فتح صوت الفريق للعامة: القائد، أو أي عضو إن لم يكن هناك قائد
  function vCapOf(team) {
    if (E.G) { const c = (E.G.caps || {})[team]; return c && E.G.players[c] && E.G.players[c].side === team ? c : null; }
    if (!A.cfg.captains) return null; const c = (A.capPick || {})[+String(team).slice(1)]; return c || null;
  }
  function vTeamOf(pid) { if (E.G) { const p = E.G.players[pid]; return p && p.side ? p.side : null; } if (pid === 'host') return A.cfg.hostPlays ? 't' + (A.hostTeam || 0) : null; const p = (A.lobby || {})[pid]; return p ? 't' + p.team : null; }
  function setVpub(by, team, on) {
    if (A.role !== 'host' || !team || vTeamOf(by) !== team) return;
    const c = vCapOf(team); if (c && c !== by) return;
    A.vpub = A.vpub || {}; A.vpub[team] = on;
    if (A.H) A.H.bcast({ t: 'vpub', v: A.vpub }); saveHost(true); window.FVOICE && FVOICE.sync();
    toast((on ? '🌐 فتح ' : '🔒 أغلق ') + teamName(team) + ' صوته ' + (on ? 'للجميع' : 'على فريقه'));
  }
  function teamName(t) { const sd = E.G && E.G.sides.find(x => x.id === t); return sd ? sd.name : ['الفريق الأحمر', 'الفريق الأزرق', 'الفريق الذهبي', 'الفريق الأخضر'][+String(t).slice(1)] || ''; }
  window.fahimVoicePub = (team, on) => { if (A.role === 'host') setVpub(A.myPid || 'host', team, on); else if (A.C) A.C.send({ t: 'vpub', team, on }); };
  window.fahimToast = (t, ms) => toast(t, ms);
  window.fahimVoiceInfo = () => {
    if (A.role === 'local' || !A.code) return null;
    const on = A.role === 'host' ? A.cfg.voice !== false : !!A.voiceOn;
    if (!on) return { on: false };
    const V = A.V; let members = [], teams = false, me = A.role === 'host' ? 'host' : (A.myPid || A.uid), canPub = false;
    if (V && A.scr === 'game' && V.players) {
      teams = V.sides.some(sd => /^t\d$/.test(sd.id));
      members = Object.keys(V.players).map(id => ({ id, name: V.players[id].name, team: V.players[id].side || null }));
      if (!members.some(m => m.id === 'host') && A.role === 'host') members.push({ id: 'host', name: 'المضيف', team: null });
      const myT = (V.players[me] || {}).side; const c = myT && V.caps && V.caps[myT]; canPub = !!myT && (!c || c === me || !V.players[c] || V.players[c].side !== myT);
    } else {
      const lob = A.role === 'host' ? A.lobby : A.lobbyRaw || A.lobby; teams = A.role === 'host' ? !!A.cfg.teams : !!A.lobbyTeams;
      members = Object.values(lob || {}).map(p => ({ id: p.id, name: p.name, team: teams ? 't' + p.team : null }));
      const hp = A.role === 'host' ? (A.cfg.hostPlays ? { team: A.hostTeam || 0, name: A.me.name } : null) : A.lobbyHost;
      members.push({ id: 'host', name: hp ? hp.name || 'المضيف' : 'المضيف', team: teams && hp ? 't' + (hp.team || 0) : null });
      const myT = (members.find(m => m.id === me) || {}).team; const caps = A.role === 'host' ? (A.cfg.captains ? A.capPick || {} : {}) : (A.lobbyCaptains ? A.lobbyCaps || {} : {});
      const c = myT ? caps[+myT.slice(1)] : null; canPub = !!myT && (!c || c === me);
    }
    return { on: true, code: A.code, me, members, teams, pub: A.vpub || {}, canPub };
  };
  function hostLobbyBroadcast() { setTimeout(() => window.FVOICE && FVOICE.sync(), 0); if (A.H) A.H.bcast({ t: 'lobby', players: A.lobby, code: A.code, teams: A.cfg.teams, nt: NT(), captains: !!A.cfg.captains, caps: A.capPick || {}, voice: A.cfg.voice !== false, vpub: A.vpub || {}, host: A.cfg.hostPlays ? { id: 'host', name: A.me.name || 'المضيف', emoji: A.me.emoji, team: A.hostTeam || 0 } : null }); }
  function clientJoin(pin, rejoin) {
    A.code = pin; A.lobby = {}; A.link = 'connecting'; A.joinSlow = null; A.rejoin = !!rejoin; go('wait');
    store.set('csess', { pin, t: Date.now() });
    keepAlive(true, 'أنت في غرفة ' + pin + ' — الاتصال محفوظ حتى لو خرجت من التطبيق');
    A.C = FNET.Client(pin, A.uid, { name: A.me.name, emoji: A.me.emoji }, {
      onMsg: onClientMsg,
      onLink(st) { const prev = A.link; A.link = st; if (st === 'lost') { if (A.scr === 'game') render(); } else if (prev === 'lost' || prev === 'connecting') { if (prev === 'lost') { toast('عاد الاتصال ✓'); SFX.coin && SFX.coin(); } if (A.scr === 'game') render(); } updDot(); },
      onFail(t) { A.joinSlow = t; if (A.scr === 'wait') render(); }
    });
  }
  function onClientMsg(m) {
    saveClient();
    if (m.t === 'hello') { A.myPid = m.pid; A.code = m.code; A.joinSlow = null; if (A.scr === 'wait') render(); }
    else if (m.t === 'lobby') { A.lobby = m.players; A.lobbyTeams = m.teams; A.lobbyNT = m.nt || 2; A.lobbyHost = m.host; A.lobbyCaps = m.caps || {}; A.lobbyCaptains = !!m.captains; A.voiceOn = m.voice; A.vpub = m.vpub || {}; window.FVOICE && FVOICE.sync(); A.lobbyGot = true; A.joinSlow = null; if (A.scr !== 'wait') go('wait'); else render(); }
    else if (m.t === 'closed') { toast('أغلق المضيف الغرفة', 3500); leave(); go('home'); }
    else if (m.t === 'state') { A.lobbyGot = true; if (m.vp) A.vpub = m.vp; if (m.vo !== undefined) A.voiceOn = m.vo; onState(m.s); window.FVOICE && FVOICE.sync(); }
    else if (m.t === 'vpub') { A.vpub = m.v || {}; window.FVOICE && FVOICE.sync(); }
  }
  function send(a) {
    if (A.role === 'client') { A.C && A.C.send({ t: 'act', a }); }
    else E.act(A.myPid, a);
  }

  // ---------- استقبال الحالة ----------
  E.onState = function (v) {
    v.now = Date.now();
    if (A.role === 'host' && A.H) { A.H.bcast({ t: 'state', s: v, vp: A.vpub || {}, vo: A.cfg.voice !== false }); window.FVOICE && FVOICE.sync(); saveHost(v.ph === 'banner' || v.ph === 'podium'); }
    onState(v);
  };
  function onState(v) {
    const p = A.V; A.prev = p; A.V = v; if (!p || p.jk !== v.jk) A.jkAt = Date.now();
    if (v.now) A.off = v.now - Date.now();
    A.localEnd = v.t && !v.paused ? Date.now() + v.t : 0;
    if (A.scr !== 'game') A.scr = 'game';
    const phChanged = !p || p.ph !== v.ph || p.mode !== v.mode;
    if (phChanged) {
      A.sel = {}; A.ord = [];
      if (v.ph === 'banner') SFX.start();
      else if (['q', 'buzzq', 'who', 'pick', 'open', 'hexpick', 'hexq', 'cwpick', 'chain', 'word', 'wheel', 'bombarm'].includes(v.ph)) SFX.whoosh();
      else if (v.ph === 'buzzed') SFX.buzz();
      else if (v.ph === 'reveal') {
        const mine = (v.d.res || []).filter(r => isMine(r.s));
        if (mine.length) (mine.some(r => r.ok) ? SFX.ok : SFX.bad)(); else SFX.reveal();
      } else if (v.ph === 'podium') { SFX.win(); setTimeout(confetti, 300); }
      else if (v.ph === 'kres') { (v.d.auctionOk === false ? SFX.bad : SFX.reveal)(); }
      else if (v.ph === 'hexres') { (v.d.ok ? SFX.ok : SFX.bad)(); }
      else if (v.ph === 'bombboom') { SFX.bad(); }
      else if (v.ph === 'bombpass') { (v.d.wrong ? SFX.bad : SFX.ok)(); }
      else if (v.ph === 'wordres' || v.ph === 'cipherres') { (v.d.winner ? SFX.ok : SFX.reveal)(); }
      else if (v.ph === 'wheelres') { (v.d.delta > 0 ? SFX.coin : v.d.delta < 0 ? SFX.bad : SFX.reveal)(); }
      else if (v.ph === 'hexend' || v.ph === 'chainend') { SFX.win(); setTimeout(confetti, 200); }
    } else if (p && v.d && p.d) {
      if (v.d.fx !== p.d.fx) { if (v.d.flash === 'ok') SFX.coin(); else if (v.d.flash || v.d.bad || v.d.wrong) SFX.bad(); }
      if (v.d.buzzer && v.d.buzzer !== p.d.buzzer) SFX.buzz();
      if ((v.d.done || []).length > (p.d.done || []).length) SFX.click();
      if ((v.d.clues || []).length > (p.d.clues || []).length) SFX.reveal();
    }
    // إعادة رسم عند فتح الجرس
    const arm = v.d && v.d.armAt ? v.d.armAt - A.off - Date.now() : 0;
    if (arm > 0) setTimeout(() => { if (A.V === v) render(); }, arm + 30);
    render();
  }
  function isMine(sid) { const V = A.V; if (!V) return false; if (V.local) return true; const pl = V.players[A.myPid]; return pl && pl.side === sid; }
  function mySide() { const V = A.V; if (!V || V.local) return null; const pl = V.players[A.myPid]; return pl ? pl.side : null; }
  function isHost() { return A.role === 'host' || A.role === 'local'; }
  function capOf(sid) { const V = A.V; const c = V && V.caps && V.caps[sid]; if (!c || !V.players[c] || V.players[c].side !== sid) return null; if (V.online && V.online[c] === false) return null; return c; }
  function isCapBlocked(sid) { const c = capOf(sid); return !!c && c !== A.myPid; }
  function canAct(sid) { const V = A.V; if (V.local) return true; return mySide() === sid && !isCapBlocked(sid); }
  // شريط القائد: يظهر لأعضاء الفريق غير القادة
  function capNote() {
    const V = A.V; if (!V || V.local) return ''; const me = mySide(); if (!me) return ''; const c = capOf(me); if (!c) return '';
    if (c === A.myPid) return `<div class="capbar me" data-a="capmenu">${ICON.crown || '👑'} أنت قائد الفريق — أنت من يجاوب</div>`;
    return `<div class="capbar" data-a="capmenu">${ICON.crown || '👑'} القائد <b>${esc((V.players[c] || {}).name || '')}</b> هو من يجاوب — اضغط خياراً لتقترحه عليه</div>`;
  }
  const sideById = id => ((A.V && A.V.sides.find(s => s.id === id)) || { name: '?', emoji: '❔', color: '#555' });
  const armed = d => !d.armAt || Date.now() + A.off >= d.armAt;

  // مؤقت محلي
  setInterval(() => {
    if (A.V && A.V.ph === 'q' && A.V.d && A.V.d.bomb && !A.V.paused) { const hz = A.V.d.bomb.heat || 0; const el2 = Date.now() - (A.V.d.t0 || (A.V.d.t0 = Date.now())); const gap = Math.max(220, 900 - (hz + el2 / 20000) * 700); if (!A.bt || Date.now() - A.bt > gap) { A.bt = Date.now(); SFX.tick(); } }
    const el = document.getElementById('tnum'); const bar = document.getElementById('tbar');
    if (!el || !A.localEnd) return;
    const rem = Math.max(0, A.localEnd - Date.now()); const s = Math.ceil(rem / 1000);
    if (el.textContent !== String(s)) { el.textContent = s; if (s <= 5 && s > 0) { el.classList.add('hurry'); SFX.tick(); } }
    if (bar && A.V && A.V.tot) bar.style.transform = `scaleX(${rem / A.V.tot})`;
  }, 200);

  // ---------- مكونات ----------
  const owl = (w) => `<div class="emblem" style="width:${w}px;height:${w}px">${OWL}</div>`;
  const av = (g, c) => `<span class="av" ${c ? `style="border-color:${c}55"` : ''}>${esc(g)}</span>`;
  function top(t, back) { return `<div class="topbar">${back !== false ? `<button class="iconbtn" data-a="back">${ICON.back}</button>` : ''}<div class="t">${t}</div><div class="mini">${OWL}</div></div>`; }
  function scoreboard(active) {
    const V = A.V; const act = [].concat(active || []);
    const off = id => !V.local && V.online && Object.keys(V.players).some(pid => V.players[pid].side === id && V.online[pid] === false) && !Object.keys(V.players).some(pid => V.players[pid].side === id && V.online[pid] !== false && pid !== 'host');
    return `<div class="sb">${V.sides.map(s => `<div class="sbi ${act.includes(s.id) ? 'act' : ''} ${off(s.id) ? 'offl' : ''}" style="--c:${s.color}"><div class="g">${esc(s.emoji)}</div><div class="nm">${esc(s.name)}</div><div class="sc">${s.score}</div></div>`).join('')}</div>`;
  }
  function timerUI() {
    if (A.V && A.V.d && A.V.d.hideT) return '';
    if (A.V && A.V.paused) return `<div class="row" style="margin:8px 0"><div class="tnum">${Math.ceil((A.V.t || 0) / 1000)}</div><div class="timer grow"><i style="transform:scaleX(${A.V.tot ? A.V.t / A.V.tot : 1})"></i></div></div>`;
    if (!A.localEnd) return ''; const rem = Math.max(0, A.localEnd - Date.now()); return `<div class="row" style="margin:8px 0"><div class="tnum" id="tnum">${Math.ceil(rem / 1000)}</div><div class="timer grow"><i id="tbar" style="transform:scaleX(${A.V.tot ? rem / A.V.tot : 1})"></i></div></div>`;
  }
  function qhead(d) { const c = QB.cats[d.c] || (MODES[d.c] ? { name: MODES[d.c].name, icon: '' } : null); return `<div class="qhead"><span>${esc(d.title || '')}</span><span>${c ? '<span class="ce" style="filter:grayscale(1) brightness(1.4);opacity:.7">' + c.icon + '</span> ' + c.name : ''} ${d.l ? `<span class="lvl l${d.l}">${LVL[d.l]}</span>` : ''}</span></div>`; }
  function hostBar(label) { if (!isHost() || !A.V) return ''; return `<div class="foot"><div class="in"><button class="btn gold grow" data-a="next">${label || 'التالي'}</button><button class="btn" data-a="menu">${ICON.menu}</button></div></div>`; }
  function nextBtn() { return isHost() && A.V && A.V.ph !== 'podium' ? hostBar() : ''; }
  function menuOnly(extra) { return isHost() ? `<div class="foot"><div class="in">${extra || ''}<button class="btn ${extra ? '' : 'grow'}" data-a="menu">${ICON.menu}${extra ? '' : ' القائمة'}</button></div></div>` : ''; }
  function infoCard(d) { return d.info ? `<div class="didyou"><b>💡 هل تعلم؟</b><span>${esc(d.info)}</span></div>` : ''; }
  function qbox(text, d, extra) { return `<div class="qbox" data-lp="report" ${extra || ''}>${fmtQ(text)}</div>`; }

  // ---------- الشاشات ----------
  const SCR = {};
  SCR.home = () => {
    const item = (a, ic, t, sub, cls) => `<button class="mbtn ${cls || ''}" data-a="${a}"><span class="ic">${ICON[ic]}</span><span>${t}<small>${sub}</small></span><span class="chev">${ICON.back}</span></button>`;
    return `<div class="hero">${owl(132)}<h1 class="title">فهيم</h1><div class="tag">مسابقات ثقافية لمن يعرف أكثر</div><div class="orn">✦</div></div>
  <div class="menu">
    ${item('local', 'users', 'لعب على جهاز واحد', 'فرق تتنافس وتتناوب على الجهاز نفسه', 'main')}
    ${item('host', 'host', 'إنشاء غرفة', 'كل لاعب يجاوب من جواله برمز أو QR', '')}
    ${item('join', 'join', 'الانضمام إلى غرفة', 'أدخل الرمز أو امسح رمز QR', '')}
    ${item('practice', 'practice', 'تدريب فردي', 'اختبر معلوماتك بمفردك', '')}
    <div class="row">${item('bank', 'bank', 'بنك الأسئلة', 'الفئات والبلاغات وإضافة أسئلتك', 'grow')}</div>
  </div>
  <div class="foot-links"><button class="btn sm" data-a="help">${ICON.help} طريقة اللعب</button><button class="btn sm" data-a="settings">${ICON.gear} الإعدادات</button><button class="btn sm" data-a="sound">${SFX.on ? ICON.sound + ' الصوت' : ICON.mute + ' صامت'}</button></div>`;
  };

  const PRESETS = {
    family: { name: 'سهرة العائلة', modes: ['wheel', 'kahoot', 'emoji', 'word', 'bomb', 'cipher'], levels: [1, 2], curve: true, timer: 25, n: 6 },
    pro: { name: 'تحدي المثقفين', modes: ['board', 'buzzer', 'wager', 'auction', 'catwar', 'near'], levels: [3, 4], curve: false, timer: 20, n: 8 },
    quick: { name: 'جولة سريعة', modes: ['kahoot', 'bomb', 'tf', 'near'], levels: [1, 2, 3], curve: true, timer: 15, n: 5 },
    letters: { name: 'حروف وكلمات', modes: ['cipher', 'word', 'chain', 'who'], levels: [1, 2, 3, 4], curve: true, timer: 20, n: 6 }
  };
  function applyPreset(p) { const c = A.cfg; if (p.per) c.per = Object.assign({}, p.per);
    ['modes', 'levels', 'curve', 'timer', 'n', 'style', 'copies', 'lives', 'knowTime', 'whoStep'].forEach(k => { if (p[k] !== undefined) c[k] = Array.isArray(p[k]) ? p[k].slice() : p[k]; }); if (p.cats) c.cats = p.cats.filter(x => QB.cats[x]); c.modes = c.modes.filter(m => MODES[m]); }

  SCR.setup = () => {
    const c = A.cfg; const local = A.role === 'local';
    const mine = store.get('presets', []);
    let h = top(local ? 'إعداد اللعبة' : 'إعداد الغرفة');
    h += `<div class="card"><h3>${ICON.save} إعدادات جاهزة</h3><div class="chips">${Object.keys(PRESETS).map(k => `<button class="chip" data-a="preset" data-p="${k}">${PRESETS[k].name}</button>`).join('')}${mine.map((p, i) => `<span class="chip mine"><button data-a="mypreset" data-i="${i}">⭐ ${esc(p.name)}</button><button class="xx" data-a="delpreset" data-i="${i}">×</button></span>`).join('')}</div>
      <button class="btn sm" style="margin-top:10px" data-a="savepreset">${ICON.plus} احفظ الإعداد الحالي باسم</button></div>`;
    if (!local) h += `<div class="card"><h3>طريقة اللعب</h3><div class="seg2"><button class="${!c.teams ? 'on' : ''}" data-a="setteams" data-v="0">${ICON.user || '👤'}<b>كل لاعب لحاله</b><small>كل جوال يلعب لنفسه</small></button><button class="${c.teams ? 'on' : ''}" data-a="setteams" data-v="1">${ICON.users || '👥'}<b>فرق</b><small>عدة جوالات في كل فريق</small></button></div>
      ${c.teams ? `<label class="lab"><input type="checkbox" data-in="captains" ${c.captains ? 'checked' : ''} style="width:auto"> قائد لكل فريق: هو وحده من يجاوب</label>` : ''}
      <label class="lab"><input type="checkbox" data-in="voice" ${c.voice !== false ? 'checked' : ''} style="width:auto"> الغرفة الصوتية</label><div class="hint">يمكنك تعديل هذه الخيارات أيضاً داخل الغرفة قبل البدء.</div></div>`;
    if (local) {
      h += `<div class="card"><h3>${ICON.users.replace('<svg', '<svg width="20" height="20"')} الفرق واللاعبون</h3><div class="sides">${A.sides.map((s, i) => `
        <div class="side" style="border-top-color:${s.color}"><button class="x" data-a="delside" data-i="${i}">${ICON.close}</button>
        <button data-a="emo" data-i="${i}">${av(s.emoji, s.color)}</button><input data-in="sname" data-i="${i}" value="${esc(s.name)}" maxlength="20">
        ${A.emoPick === i ? `<div class="emojis">${EMO.map(e => `<span class="${s.emoji === e ? 'on' : ''}" data-a="setemo" data-i="${i}" data-e="${e}">${e}</span>`).join('')}</div>` : ''}</div>`).join('')}
        ${A.sides.length < 8 ? `<button class="side add" data-a="addside">${ICON.plus}</button>` : ''}</div>
        <div class="hint">في خلية الحروف يلعب أول فريقين فقط: الأول بالأحمر والثاني بالأزرق.</div></div>`;
    }
    h += `<div class="card"><h3>أنماط اللعب</h3><div class="hint">كل نمط تختاره يُلعب كجولة، والنقاط تتراكم حتى منصة التتويج. التفاصيل الكاملة في "طريقة اللعب".</div><div class="modes" style="margin-top:12px">${Object.keys(MODES).map(k => `<button class="mode ${c.modes.includes(k) ? 'on' : ''}" data-a="mode" data-k="${k}"><span class="mi">${ICON[k] || ''}</span><span><b>${MODES[k].name}</b><p>${MODES[k].d}</p></span></button>`).join('')}</div>
      <div class="row" style="margin-top:10px"><button class="btn sm" data-a="modeall">الكل</button><button class="btn sm" data-a="modenone">إلغاء الكل</button></div></div>`;
    const pm = c.modes.filter(k => PER[k]);
    if (pm.length) { c.per = c.per || {}; h += `<div class="card"><h3>عدد أسئلة كل فقرة</h3><div class="hint">لكل فقرة اخترتها عددها الخاص</div>${pm.map(k => { const P = PER[k]; const v = c.per[k] || P.d; return `<label class="lab"><span class="gold">${ICON[k] ? '' : ''}${MODES[k].name}</span> — ${P.l}</label><div class="range"><input type="range" min="${P.min}" max="${P.max}" value="${v}" data-in="per" data-k="${k}"><b>${v}</b></div>`; }).join('')}</div>`; }
    h += catPicker();
    h += `<div class="card"><h3>الصعوبة والوقت</h3>
      <label class="lab">مستويات الصعوبة</label><div class="chips">${[1, 2, 3, 4].map(l => `<button class="chip ${c.levels.includes(l) ? 'on' : ''}" data-a="lvl" data-l="${l}"><span class="lvl l${l}">${LVL[l]}</span></button>`).join('')}</div>
      <div class="row" style="margin-top:8px"><button class="btn sm" data-a="lvlp" data-p="mix">متدرّج</button><button class="btn sm" data-a="lvlp" data-p="easy">للمبتدئين</button><button class="btn sm" data-a="lvlp" data-p="pro">للفاهمين والمتمكنين</button></div>
      <label class="lab"><input type="checkbox" data-in="curve" ${c.curve ? 'checked' : ''} style="width:auto"> تصاعد الصعوبة داخل الجولة (من السهل إلى الصعب)</label>
      <label class="lab">وقت الإجابة على السؤال</label><div class="range"><input type="range" min="15" max="90" step="5" value="${c.timer}" data-in="timer"><b>${c.timer} ث</b></div>
      <label class="lab">وقت جولة "ماذا تعرف؟"</label><div class="range"><input type="range" min="30" max="180" step="10" value="${c.knowTime}" data-in="knowTime"><b>${c.knowTime} ث</b></div>
      <label class="lab">مدة كل تلميح في "من أنا؟"</label><div class="range"><input type="range" min="8" max="30" value="${c.whoStep}" data-in="whoStep"><b>${c.whoStep} ث</b></div>
      <label class="lab">طريقة الإجابة في لوح التحدي</label><div class="seg"><button class="${c.style === 'mcq' ? 'on' : ''}" data-a="style" data-v="mcq">اختيارات (تلقائي)</button><button class="${c.style === 'open' ? 'on' : ''}" data-a="style" data-v="open">مفتوحة والحَكَم يقرر</button></div>
      <label class="lab">حجم لوح التحدي</label><div class="seg"><button class="${c.copies === 1 ? 'on' : ''}" data-a="copies" data-v="1">24 سؤال</button><button class="${c.copies === 2 ? 'on' : ''}" data-a="copies" data-v="2">48 سؤال</button></div>
      <label class="lab">محاولات "الصمود"</label><div class="seg">${[1, 2, 3].map(v => `<button class="${c.lives === v ? 'on' : ''}" data-a="lives" data-v="${v}">${['محاولة واحدة', 'محاولتان', 'ثلاث محاولات'][v - 1]}</button>`).join('')}</div>
    </div>`;
    if (local) h += `<div class="foot"><div class="in"><button class="btn gold grow" data-a="start">ابدأ اللعب</button></div></div>`;
    else h += `<div class="foot"><div class="in"><button class="btn gold grow" data-a="openroom">افتح الغرفة</button></div></div>`;
    return h;
  };
  function catPicker() {
    const c = A.cfg; const groups = {};
    QB.order.forEach(id => { const k = QB.cats[id]; (groups[k.group] = groups[k.group] || []).push(k); });
    return `<div class="card"><h3>فئات الأسئلة <span class="mut" style="font-size:13px;font-family:Cairo">${c.cats.length} من ${QB.order.length}</span></h3>
      <div class="row"><button class="btn sm" data-a="catall">تحديد الكل</button><button class="btn sm" data-a="catnone">إلغاء الكل</button><button class="btn sm" data-a="catrnd">6 عشوائية</button></div>
      ${Object.keys(groups).map(g => `<div class="grp">${g}</div><div class="chips">${groups[g].map(k => `<button class="chip ${c.cats.includes(k.id) ? 'on' : ''}" data-a="cat" data-k="${k.id}"><span class="ce">${k.icon}</span>${k.name} <span class="n">${k.id === 'math' ? '∞' : k.n}</span></button>`).join('')}</div>`).join('')}</div>`;
  }
  function qrSvg(text, px) { try { const q = qrcode(0, 'M'); q.addData(text); q.make(); return q.createSvgTag({ cellSize: px || 6, margin: 2, scalable: true }); } catch (e) { return ''; } }
  function linkLabel(st) { return { p2p: 'مباشر', relay: 'عبر الترحيل', connecting: 'جارٍ الاتصال', lost: 'منقطع' }[st] || 'جارٍ الاتصال'; }
  SCR.lobby = () => {
    const pl = Object.values(A.lobby || {}); const t = A.cfg.teams; const H = A.H || {};
    const ok = H.p2p || H.relayOk;
    return top('غرفة اللعب') + `<div class="card center"><div class="mut">رمز الغرفة</div><div class="pin">${A.code || '....'}</div>
      ${A.code ? `<div class="qr">${qrSvg('fahim://join/' + A.code, 6)}</div><div class="mut" style="font-size:13px">امسحوا الرمز من شاشة "الانضمام" في فهيم، أو أدخلوا الرقم</div>` : ''}
      <div class="netrow"><span class="ndot ${H.p2p ? 'ok' : 'off'}"></span>الاتصال المباشر <span class="ndot ${H.relayOk ? 'ok' : 'off'}"></span>خادم الترحيل</div>
      ${!ok ? '<div class="minus" style="font-size:13px">لا يوجد اتصال بالإنترنت أو الخوادم غير متاحة حالياً… جارٍ إعادة المحاولة</div>' : ''}</div>
    <div class="card"><h3>طريقة اللعب</h3>
      <div class="seg2"><button class="${!t ? 'on' : ''}" data-a="setteams" data-v="0">${ICON.user || '👤'}<b>كل لاعب لحاله</b><small>كل جوال يلعب لنفسه</small></button><button class="${t ? 'on' : ''}" data-a="setteams" data-v="1">${ICON.users || '👥'}<b>فرق</b><small>عدة جوالات في كل فريق</small></button></div>
      ${t ? `<div class="row" style="margin-top:10px;gap:6px;flex-wrap:wrap"><span class="mut">عدد الفرق:</span>${[2, 3, 4].map(n => `<button class="btn sm ${NT() === n ? 'gold' : ''}" data-a="nteams" data-n="${n}">${n}</button>`).join('')}<button class="btn sm grow" data-a="balance">توزيع عشوائي متوازن</button></div>
        <label class="lab"><input type="checkbox" data-in="captains" ${A.cfg.captains ? 'checked' : ''} style="width:auto"> قائد لكل فريق: هو وحده من يجاوب، والباقون يقترحون عليه</label>` : ''}
      <label class="lab"><input type="checkbox" data-in="voice" ${A.cfg.voice !== false ? 'checked' : ''} style="width:auto"> الغرفة الصوتية ${t ? '(كل فريق يسمع نفسه، والقائد يفتحها للعامة)' : '(الجميع يسمع الجميع)'}</label>
    </div>
    <div class="card"><div class="row"><h3 class="grow">اللاعبون (${pl.length + (A.cfg.hostPlays ? 1 : 0)})</h3></div>
      <label class="lab"><input type="checkbox" data-in="hostPlays" ${A.cfg.hostPlays ? 'checked' : ''} style="width:auto"> المضيف يلعب أيضاً (وإلا يكون حكماً وشاشة عرض)</label>
      ${A.cfg.hostPlays ? `<div class="row card" style="margin:6px 0;padding:10px">${av(A.me.emoji)}<input data-in="myname" value="${esc(A.me.name)}" placeholder="اسمك" class="grow" style="width:auto">${t && A.cfg.captains ? capBtn('host', A.hostTeam || 0) : ''}${t ? teamBtn('host', A.hostTeam || 0) : ''}</div>` : ''}
      ${pl.length ? pl.map(p => { const pr = A.pres[p.id] || {}; return `<div class="lbi"><span class="ndot ${pr.on === false ? 'off' : 'ok'}" title="${pr.via || ''}"></span>${av(p.emoji)}<span class="grow">${esc(p.name)} <small class="mut">${pr.on === false ? 'منقطع' : pr.via === 'relay' ? 'ترحيل' : 'مباشر'}</small></span>${t && A.cfg.captains ? capBtn(p.id, p.team) : ''}${t ? teamBtn(p.id, p.team) : ''}</div>`; }).join('') : '<div class="waiting mut">بانتظار انضمام اللاعبين<span class="dots"></span></div>'}
      ${t ? `<div class="mut" style="font-size:13px;margin-top:6px">كل لاعب يختار فريقه من جواله، ويمكنك تغييره بالضغط على لونه${A.cfg.captains ? '، واضغط التاج لتعيين القائد' : ''}. ${Array.from({ length: NT() }, (_, k) => `<b style="color:${COL[k]}">${['الأحمر', 'الأزرق', 'الذهبي', 'الأخضر'][k]} ${lobbyAll().filter(p => p.team === k).length}</b>`).join(' · ')}</div>` : ''}
    </div>
    <div class="foot"><div class="in"><button class="btn gold grow" data-a="hoststart" ${(pl.length + (A.cfg.hostPlays ? 1 : 0)) < 1 ? 'disabled' : ''}>ابدأ اللعبة</button></div></div>`;
  };
  function capBtn(pid, team) { const on = (A.capPick || {})[team] === pid; return `<button class="btn sm capb ${on ? 'on' : ''}" data-a="capset" data-p="${pid}" data-t="${team}" title="قائد الفريق">👑</button>`; }
  function teamBtn(pid, team) { return `<button class="btn sm" data-a="team" data-p="${pid}" style="background:${COL[team]};min-width:90px">${['الأحمر', 'الأزرق', 'الذهبي', 'الأخضر'][team]}</button>`; }
  SCR.join = () => top('انضمام لغرفة') + `<div class="card"><label class="lab">اسمك</label><input data-in="myname" value="${esc(A.me.name)}" maxlength="18" placeholder="مثلاً: أبو كريم">
    <label class="lab">اختر رمزك</label><div class="emojis">${EMO.map(e => `<span class="${A.me.emoji === e ? 'on' : ''}" data-a="myemo" data-e="${e}">${e}</span>`).join('')}</div>
    <label class="lab">رمز الغرفة</label><input id="pin" inputmode="numeric" maxlength="4" placeholder="0000" value="${esc(A.pendingPin || '')}" style="font-size:36px;text-align:center;letter-spacing:12px;direction:ltr">
    <div class="row" style="margin-top:16px"><button class="btn gold grow" data-a="dojoin">دخول</button><button class="btn" data-a="scan">${ICON.qr} مسح QR</button></div></div>`;
  SCR.wait = () => {
    const pl = Object.values(A.lobby || {}); const me = A.lobby && A.lobby[A.myPid || A.uid]; const nt = A.lobbyNT || 2;
    const TN = ['الأحمر', 'الأزرق', 'الذهبي', 'الأخضر'];
    let h = top('غرفة ' + (A.code || '')) + `<div class="waiting">${owl(110)}<h2>${A.lobbyGot ? 'أنت في الغرفة!' : A.rejoin ? 'جارٍ إعادتك إلى الغرفة' : 'جارٍ الاتصال بالغرفة'}</h2><div class="mut">${A.lobbyGot ? 'بانتظار المضيف ليبدأ اللعبة' : A.rejoin ? 'مكانك ونقاطك محفوظة — نعيد الاتصال تلقائياً' : 'نجرب الاتصال المباشر وخادم الترحيل معاً'}<span class="dots"></span></div>
      ${A.joinSlow && !A.lobbyGot ? `<div class="card" style="margin-top:12px;font-size:14px">${esc(A.joinSlow)}</div>` : ''}</div>`;
    if (A.lobbyGot && A.lobbyTeams) {
      h += `<div class="card"><h3>اختر فريقك</h3><div class="teampick">${Array.from({ length: nt }, (_, t) => { const n = pl.filter(p => p.team === t).length + (A.lobbyHost && A.lobbyHost.team === t ? 1 : 0); return `<button class="btn ${me && me.team === t ? 'on' : ''}" data-a="myteam" data-t="${t}" style="--c:${COL[t]}">${TN[t]}<small>${n} لاعب</small></button>`; }).join('')}</div>
        <div class="teamcols">${Array.from({ length: nt }, (_, t) => `<div class="tcol" style="--c:${COL[t]}"><b>${TN[t]}</b>${(A.lobbyHost && A.lobbyHost.team === t ? [A.lobbyHost] : []).concat(pl.filter(p => p.team === t)).map(p => `<div class="lbi">${av(p.emoji)}<span>${esc(p.name)}${A.lobbyCaptains && (A.lobbyCaps || {})[t] === (p.id || 'host') ? ' 👑' : ''}</span></div>`).join('') || '<div class="mut">—</div>'}</div>`).join('')}</div>
        ${A.lobbyCaptains && me ? (() => { const cp = (A.lobbyCaps || {})[me.team]; if (cp === me.id) return `<button class="btn grow" style="margin-top:10px;width:100%" data-a="mycap" data-off="1">👑 أنت القائد — تنازل عن القيادة</button>`; if (cp) { const who = cp === 'host' ? A.lobbyHost : (A.lobby || {})[cp]; return `<div class="capbar">👑 قائد فريقك: <b>${esc(who ? who.name : '')}</b></div>`; } return `<button class="btn gold" style="margin-top:10px;width:100%" data-a="mycap">👑 أكون قائد فريقي</button>`; })() : ''}
        ${A.lobbyCaptains ? '<div class="mut" style="font-size:13px;margin-top:6px">القائد وحده يجاوب، والباقون يتناقشون ويقترحون عليه.</div>' : ''}</div>`;
    } else if (pl.length) h += `<div class="card">${pl.map(p => `<div class="lbi">${av(p.emoji)}<span>${esc(p.name)}</span></div>`).join('')}</div>`;
    h += `<div class="foot"><div class="in"><button class="btn grow" data-a="home">${A.lobbyGot ? 'مغادرة الغرفة' : 'إلغاء'}</button></div></div>`;
    return h;
  };
  SCR.help = () => top('طريقة اللعب') + `<div class="card"><h3>كيف تُلعب فهيم؟</h3><p>اختر الأنماط والفئات والصعوبة. كل نمط تختاره يُلعب كجولة مستقلة، والنقاط تتراكم من جولة لأخرى حتى منصة التتويج التي تعرض أيضاً إحصائيات المباراة.</p>
    <p><b>على جهاز واحد:</b> أضف الفرق وتناوبوا على الجهاز. في الأنماط الجماعية يأخذ كل فريق دوره.</p>
    <p><b>عدة أجهزة:</b> المضيف ينشئ غرفة فيظهر رمز من 4 أرقام ورمز QR، وكل لاعب ينضم من جواله ويجاوب منه، حتى لو كان كل واحد في مدينة أو دولة مختلفة. يتطلب إنترنت.</p>
    <p><b>الفرق بعدة جوالات:</b> فعّل "نظام الفرق" في الغرفة واختر عدد الفرق (2–4). كل لاعب يختار فريقه من جواله، أو اضغط "توزيع عشوائي متوازن". أي لاعب في الفريق يستطيع الإجابة باسم فريقه، وأول إجابة تُحتسب.</p>
    <p><b>قائد الفريق:</b> فعّل "قائد لكل فريق" فيجاوب القائد وحده، ويرى أعضاء فريقه الأسئلة ويضغطون خياراً ليظهر اقتراحهم على شاشة القائد بأسمائهم. يختار الفريق قائده من الجوالات أو يعيّنه المضيف بالتاج 👑، ويستطيع القائد تسليم القيادة لزميل بالضغط على شريط القائد. إن انقطع اتصال القائد يحق لأي عضو الإجابة.</p>
    <p><b>الغرفة الصوتية:</b> يظهر أسفل الشاشة شريط الصوت. اضغط المايك لتتكلم واضغطه ثانية لكتمه. في نظام الفرق يسمع كل فريق نفسه فقط، وزر "خاص/عام" عند القائد يفتح صوت الفريق للجميع بضغطة. بدون فرق يسمع الجميع الجميع. يُفضّل استخدام سماعات إذا كان لاعبان من الفريق في المكان نفسه.</p>
    <p><b>إعادة الاتصال التلقائي:</b> إن انقطع الإنترنت أو خرجت لتطبيق آخر أو أُغلق التطبيق، تعود للغرفة تلقائياً بمقعدك ونقاطك فور رجوع الاتصال أو فتح التطبيق. وإن أُغلق تطبيق المضيف، يعرض عند فتحه استئناف الغرفة بنفس الرمز والنقاط.</p>
    <p><b>الإيقاف المؤقت:</b> من زر القائمة يستطيع المضيف إيقاف اللعبة مؤقتاً وإكمالها.</p>
    <p><b>الإبلاغ عن سؤال:</b> اضغط مطولاً على مربع السؤال لتظهر قائمة الإبلاغ (السؤال غلط، الجواب غلط، مكرر، الصعوبة غير مناسبة). البلاغات تظهر في بنك الأسئلة، والسؤال المُبلّغ عنه لا يظهر مجدداً.</p>
    <p><b>الإجابات المكتوبة:</b> التطبيق يتسامح مع الهمزات والتاء المربوطة والألف المقصورة و"ال" والمسافات والتشكيل، ومع نقص حرف أو حرفين حسب طول الكلمة، والحروف المتقاربة صوتياً (س/ص/ث، ت/ط، ذ/ز/ظ/ض، ق/ك، ح/ه)، ويقبل الجزء المميز من الأسماء الطويلة.</p></div>
    ${Object.keys(MODES).map(k => `<div class="card"><h3><span class="gold" style="width:22px;display:inline-block">${ICON[k] || ''}</span> ${MODES[k].name}</h3><p class="mut" style="margin:4px 0 8px">${MODES[k].d}</p><ol class="rules">${(MODES[k].rules || []).map(r => `<li>${r}</li>`).join('')}</ol></div>`).join('')}
    <div class="card"><h3>مستويات الصعوبة</h3><p><span class="lvl l1">سهل</span> يعرفه الجميع تقريباً<br><span class="lvl l2">متوسط</span> يعرفه المثقف العادي<br><span class="lvl l3">صعب</span> يعرفه المهتم بالمجال<br><span class="lvl l4">خبير</span> للمتخصص، أو يحتاج استنتاجاً</p><p class="mut">اللعبة تتعلم: تسجّل نسبة الإجابات الصحيحة لكل سؤال وتعدّل تصنيفه مع الوقت، ولا تكرر الأسئلة حتى تنتهي.</p></div>`;
  SCR.settings = () => {
    const t = store.get('turn', {}) || {};
    return top('الإعدادات') + `<div class="card"><h3>${ICON.wifi} الاتصال بين الأجوال</h3>
      <p class="mut" style="line-height:1.8">يحاول فهيم الاتصال المباشر أولاً (مع خوادم STUN/TURN مجانية)، وإن تعذّر يستخدم خادم ترحيل آمن (WSS) تلقائياً. يمكنك إضافة خادم TURN خاص بك لاتصال أقوى (مثلاً من حساب Metered المجاني).</p>
      <label class="lab">رابط خادم TURN (يمكن أكثر من رابط مفصولة بفاصلة)</label><input id="turl" dir="ltr" placeholder="turns:example.com:443?transport=tcp" value="${esc(t.url || '')}">
      <label class="lab">اسم المستخدم</label><input id="tuser" dir="ltr" value="${esc(t.user || '')}">
      <label class="lab">كلمة المرور</label><input id="tpass" dir="ltr" value="${esc(t.pass || '')}">
      <label class="lab">أو الصق مصفوفة iceServers بصيغة JSON</label><textarea id="tjson" dir="ltr" rows="3" placeholder='[{"urls":"turn:...","username":"...","credential":"..."}]'>${esc(t.json ? JSON.stringify(t.json) : '')}</textarea>
      <label class="lab"><input type="checkbox" id="trelay" ${t.relayOnly ? 'checked' : ''} style="width:auto"> استخدم خادم الترحيل فقط (للشبكات التي تحجب الاتصال المباشر)</label>
      <div class="row" style="margin-top:12px"><button class="btn gold grow" data-a="saveturn">حفظ</button><button class="btn" data-a="clearturn">استرجاع الافتراضي</button></div></div>`;
  };
  SCR.bank = () => {
    const st = QB.stats(); const tot = st.mcq + st.who + st.lists + st.orders + st.hex + st.emoji + st.near;
    const reps = QB.reports().slice().reverse();
    const RN = { q: 'السؤال غلط', a: 'الجواب غلط', dup: 'مكرر', level: 'الصعوبة غير مناسبة' };
    return top('بنك الأسئلة') + `<div class="stat"><div><b>${tot.toLocaleString('en')}</b>سؤال وتحدٍّ</div><div><b>${QB.order.length}</b>فئة</div><div><b>${st.hex}</b>سؤال حروف</div><div><b>${st.lists}</b>قائمة</div></div>
    <div class="card"><h3>${ICON.flag} البلاغات <span class="mut" style="font-size:13px;font-family:Cairo">${reps.length}</span></h3>
      ${reps.length ? `<div class="reps">${reps.slice(0, 200).map(r => `<div class="rep"><div class="rq">${esc(r.q)}</div><div class="mut" style="font-size:13px">الجواب: ${esc(r.a)} · ${esc((QB.cats[r.c] || {}).name || r.c || '')} · ${LVL[r.l] || ''}</div><div class="row" style="margin-top:6px"><span class="chip on" style="font-size:12px">${RN[r.reason] || r.reason}</span><button class="btn sm" data-a="unrep" data-t="${r.t}" style="margin-right:auto">حذف</button></div></div>`).join('')}</div>
      <div class="row" style="margin-top:10px"><button class="btn sm grow" data-a="copyreps">نسخ البلاغات كنص</button><button class="btn sm" data-a="clearreps">مسح الكل</button></div>` : '<div class="mut">لا توجد بلاغات. اضغط مطولاً على أي سؤال أثناء اللعب للإبلاغ عنه.</div>'}</div>
    <div class="card"><h3>أضف سؤالك الخاص</h3><label class="lab">الفئة</label><select id="cq_c">${QB.order.map(id => `<option value="${id}">${QB.cats[id].icon} ${QB.cats[id].name}</option>`).join('')}</select>
    <label class="lab">المستوى</label><select id="cq_l">${[1, 2, 3, 4].map(l => `<option value="${l}">${LVL[l]}</option>`).join('')}</select>
    <label class="lab">السؤال</label><textarea id="cq_q" rows="2"></textarea>
    <label class="lab">الإجابة الصحيحة (كلمة الجواب فقط بلا شرح)</label><input id="cq_a"><label class="lab">إجابات خاطئة مشابهة (3)</label><input id="cq_w1"><input id="cq_w2" style="margin-top:6px"><input id="cq_w3" style="margin-top:6px">
    <label class="lab">هل تعلم؟ (اختياري — الشرح يُكتب هنا لا في الخيارات)</label><input id="cq_i">
    <button class="btn gold wide" style="margin-top:12px" data-a="addq">حفظ السؤال</button></div>
    <div class="card"><h3>الفئات</h3>${QB.order.map(id => `<div class="resi"><span>${QB.cats[id].icon} ${QB.cats[id].name}</span><b>${id === 'math' ? '∞' : QB.cats[id].n}</b></div>`).join('')}</div>
    <button class="btn wide" data-a="resetseen">إعادة ضبط الأسئلة التي ظهرت سابقاً</button>`;
  };

  // ---------- شاشة اللعب ----------
  SCR.game = () => {
    const V = A.V; if (!V) return '<div class="waiting">جارٍ التحميل<span class="dots"></span></div>';
    const d = V.d || {};
    let h;
    if (V.ph === 'banner') { const m = MODES[d.mode]; h = `<div class="roundbanner"><div class="kick">الجولة ${V.ri + 1} من ${V.rounds.length}</div><div class="ri">${ICON[d.mode] || ''}</div><h2>${m.name}</h2><div class="orn">✦</div><p>${m.d}</p><ol class="rules small">${(m.rules || []).slice(0, 4).map(r => `<li>${r}</li>`).join('')}</ol></div>${scoreboard()}${hostBar('ابدأ الجولة')}`; }
    else if (V.ph === 'podium') h = podium();
    else if (V.ph === 'lb') h = leaderboard();
    else {
      const R = { q: gQ, reveal: gReveal, pick: gBoard, open: gOpen, buzzq: gBuzz, buzzed: gBuzzed, kready: gKready, know: gKnow, kres: gKres, bid: gBid, who: gWho, hexpick: gHex, hexq: gHex, hexres: gHex, hexend: gHex, cwpick: gCw, chain: gChain, wbet: gWager, cipher: gCipher, cipherres: gCipher, chainend: gChainEnd, wheel: gWheel, wheelres: gWheel, bombarm: gBomb, bombpass: gBomb, bombboom: gBomb, word: gWord, wordres: gWord };
      h = (R[V.ph] || (() => '<div class="waiting">...</div>'))(V, d);
    }
    if (A.role === 'client' && A.link === 'lost') h = `<div class="lostbar">${ICON.wifi || ''}<div><b>انقطع الاتصال</b><small>نعيد الاتصال تلقائياً — مكانك ونقاطك محفوظة</small></div><button class="btn sm" data-a="rejoinnow">حاول الآن</button></div>` + h;
    if (A.role === 'host' && A.H && !A.H.p2p && !A.H.relayOk) h = `<div class="lostbar">${ICON.wifi || ''}<div><b>لا يوجد إنترنت عند المضيف</b><small>اللعبة محفوظة، وستعود تلقائياً عند رجوع الاتصال</small></div></div>` + h;
    if (V.paused) h += `<div class="pausebox"><div class="in">${ICON.pause}<h2>متوقف مؤقتاً</h2>${isHost() ? `<button class="btn gold" data-a="resume">${ICON.play} استئناف</button>` : '<div class="mut">بانتظار المضيف</div>'}</div></div>`;
    return h;
  };
  function ansBtns(d, can, actAs) {
    const picked = A.sel.i, picked2 = A.sel.j; const me = mySide(); const sug = {};
    if (d.sug && me && !A.V.local) for (const pid in d.sug) { const g = d.sug[pid]; if (g.s === me) (sug[g.i] = sug[g.i] || []).push(((A.V.players[pid] || {}).name || '').split(' ')[0]); }
    const blocked = !A.V.local && me && isCapBlocked(me) && A.V.ph === 'q';
    return `<div class="answers ${d.opts.some(o => String(o).length > 40) ? 'one' : ''}">${d.opts.map((o, i) => `<button class="ans c${i} ${d.hide.includes(i) ? 'gone' : ''} ${picked === i || picked2 === i || (blocked && A.sel.sug === i) ? 'picked' : ''} ${!can && !blocked ? 'dim' : ''}" data-a="ans" data-i="${i}" data-as="${actAs || ''}"><span class="sh">${SHAPES[i]}</span>${esc(o)}${sug[i] ? `<span class="sugs">${sug[i].map(n => `<i>${esc(n)}</i>`).join('')}</span>` : ''}</button>`).join('')}</div>`;
  }
  function gQ(V, d) {
    const can = d.who.some(s => canAct(s)) && !d.who.filter(s => canAct(s)).every(s => d.done.includes(s));
    const actAs = V.local ? d.who.find(s => !d.done.includes(s)) : mySide();
    let h = scoreboard(d.who) + qhead(d) + timerUI() + capNote();
    if (d.sub) h += `<div class="subline">${esc(d.sub)}</div>`;
    if (d.msg) h += `<div class="center mut">${esc(d.msg)}</div>`;
    if (d.bomb) h += `<div class="bombq" style="--h:${(d.bomb.heat || 0).toFixed(2)}"><span>💣</span><small>تخلّص منها بإجابة صحيحة!</small></div>`;
    if (d.emo) h += `<div class="qbox emo" data-lp="report"><div class="emobig">${esc(d.emo)}</div><div class="emot">${esc(d.text)}</div></div>`;
    else h += qbox(d.text, d);
    if (d.value) h += `<div class="subline">قيمة السؤال ${d.value}</div>`;
    if (d.helpers && canAct(d.helpers.side)) { const hs = d.helpers.h; h += `<div class="helpers"><button class="helper ${hs.call ? '' : 'used'}" data-a="helper" data-h="call">${ICON.phone} اتصال بصديق</button><button class="helper ${hs.two ? '' : 'used'}" data-a="helper" data-h="two">${ICON.two} جاوب جوابين</button><button class="helper ${hs.hole ? '' : 'used'}" data-a="helper" data-h="hole">${ICON.hole} الحفرة</button></div>`; }
    if (d.kind === 'mcq') h += ansBtns(d, can, actAs);
    else if (d.kind === 'tf') {
      h += `<div class="shown">الإجابة المقترحة: ${esc(d.shown)}</div><div class="tf"><button class="ans c3 ${!can ? 'dim' : ''}" data-a="tf" data-v="1" data-as="${actAs || ''}">${ICON.check} صح</button><button class="ans c0 ${!can ? 'dim' : ''}" data-a="tf" data-v="0" data-as="${actAs || ''}">${ICON.x} خطأ</button></div>`;
    } else if (d.kind === 'order') {
      h += `<div class="mut center">اضغط العناصر بالترتيب الصحيح (${A.ord.length}/${d.items.length})</div><div class="ordlist">${d.items.map(k => { const ix = A.ord.indexOf(k); return `<button class="orditem ${ix >= 0 ? 'picked' : ''}" data-a="ord" data-k="${esc(k)}" ${!can ? 'disabled' : ''}><span class="k">${ix >= 0 ? ix + 1 : '•'}</span>${esc(k)}</button>`; }).join('')}</div>
      <div class="row" style="margin-top:10px"><button class="btn grow" data-a="ordreset">إعادة</button><button class="btn gold grow" data-a="ordsend" data-as="${actAs || ''}" ${A.ord.length < d.items.length || !can ? 'disabled' : ''}>تأكيد الترتيب</button></div>`;
    } else if (d.kind === 'near') {
      if (can) h += `${V.local ? `<div class="subline">دور ${esc(sideById(actAs).name)} — اكتب رقمك دون أن يراه الآخرون</div>` : ''}<form class="typebox" data-f="near" data-as="${actAs || ''}"><input id="nin" type="text" inputmode="decimal" autocomplete="off" placeholder="تخمينك${d.unit ? ' (' + esc(d.unit) + ')' : ''}" style="direction:ltr;text-align:center;font-size:26px"><button class="btn gold">↵</button></form>`;
    }
    if (d.who.length > 1) h += `<div class="center mut" style="margin-top:10px">أجاب ${d.done.length} من ${d.who.length}</div>`;
    if (!can && !V.local && d.who.length && !d.who.some(s => canAct(s))) h += `<div class="center mut" style="margin-top:8px">بانتظار ${d.who.map(s => esc(sideById(s).name)).join('، ')}<span class="dots"></span></div>`;
    else if (!can && !V.local) h += `<div class="subline" style="margin-top:10px">${Object.values(V.players).filter(p => p.side === mySide()).length > 1 ? 'تم إرسال إجابة فريقك' : 'تم إرسال إجابتك'}</div>`;
    if (isHost()) h += `<div class="foot"><div class="in"><button class="btn grow" data-a="next" disabled>بانتظار الإجابات…</button><button class="btn" data-a="menu">${ICON.menu}</button></div></div>`;
    return h;
  }
  function fmtQ(t) { const e = esc(t); return e.replace(/([\u{1F1E6}-\u{1F1FF}]{2})/gu, '<span style="font-size:90px;line-height:1">$1</span>'); }
  function gReveal(V, d) {
    let h = scoreboard() + qhead(d);
    if (d.kind === 'who') {
      h += `<div class="verdict ${d.res.length ? 'ok' : 'neu'}">${d.res.length ? `${esc(sideById(d.res[0].s).name)} عرفها  +${d.res[0].d}` : 'لم يعرفها أحد'}</div><div class="qbox">${esc(d.answer)}</div><div class="clues">${d.clues.map((c, i) => `<div class="clue"><b>${i + 1}</b>${esc(c)}</div>`).join('')}</div>`;
      return h + nextBtn();
    }
    const mine = d.res.filter(r => isMine(r.s));
    if (d.kind === 'near') {
      h += qbox(d.text, d) + `<div class="verdict neu">الجواب: <b class="gold">${esc(d.qa || d.real)}</b></div>`;
      h += `<div class="reslist">${d.res.slice().sort((a, b) => (a.n == null) - (b.n == null) || Math.abs(a.n - d.real) - Math.abs(b.n - d.real)).map(r => `<div class="resi ${r.d > 0 ? 'ok' : ''}"><span><span class="gold">${esc(sideById(r.s).emoji)}</span> ${esc(sideById(r.s).name)}: <b>${r.n == null ? '—' : esc(r.n)}</b></span><span class="${r.d > 0 ? 'plus' : 'mut'}">${r.d > 0 ? '+' + r.d : ''}</span></div>`).join('')}</div>`;
      return h + infoCard(d) + nextBtn();
    }
    if (!V.local && mine.length) h += `<div class="verdict ${mine[0].ok ? 'ok' : 'bad'}">${mine[0].ok ? 'إجابة صحيحة' : (mine[0].timeout ? 'انتهى الوقت' : 'إجابة خاطئة')} ${mine[0].d ? '  ' + (mine[0].d > 0 ? '+' : '') + mine[0].d : ''}</div>`;
    else if (V.local && d.res.length === 1) { const r = d.res[0]; h += `<div class="verdict ${r.ok ? 'ok' : 'bad'}">${esc(sideById(r.s).name)} — ${r.ok ? 'إجابة صحيحة' : (r.timeout ? 'انتهى الوقت' : 'إجابة خاطئة')} ${r.d ? '  ' + (r.d > 0 ? '+' : '') + r.d : ''}</div>`; }
    else if (!d.res.length && d.title) h += `<div class="verdict neu">${esc(d.title)}</div>`;
    if (d.emo) h += `<div class="qbox emo" data-lp="report"><div class="emobig">${esc(d.emo)}</div><div class="emot">${esc(d.text)}</div></div>`;
    else h += qbox(d.text, d);
    if (d.kind === 'mcq') h += `<div class="answers ${d.opts.some(o => String(o).length > 40) ? 'one' : ''}">${d.opts.map((o, i) => `<div class="ans c${i} ${i === d.ans ? 'right' : 'dim'}"><span class="sh">${i === d.ans ? '✓' : SHAPES[i]}</span>${esc(o)} ${countPick(d, i)}</div>`).join('')}</div>`;
    if (d.kind === 'tf') h += `<div class="shown">المقترح: ${esc(d.shown)} — ${d.truth ? 'صحيحة' : 'خاطئة'}${!d.truth ? `<br><span style="color:#9fe6c1">الصحيح: ${esc(d.real)}</span>` : ''}</div>`;
    if (d.kind === 'order') h += `<div class="ordlist">${d.correct.map((k, i) => `<div class="orditem"><span class="k">${i + 1}</span>${esc(k)}</div>`).join('')}</div>`;
    h += infoCard(d);
    if (d.rate != null) h += `<div class="rate"><span>${d.rate}% أجابوا صحيحاً</span><span class="bar"><i style="width:${d.rate}%"></i></span></div>`;
    if (d.res.length > 1) h += `<div class="reslist" style="margin-top:10px">${d.res.map(r => `<div class="resi ${r.ok ? 'ok' : 'bad'}"><span><span class="gold">${esc(sideById(r.s).emoji)}</span> ${esc(sideById(r.s).name)}</span><span class="${r.d >= 0 ? 'plus' : 'minus'}">${r.d > 0 ? '+' : ''}${r.d}</span></div>`).join('')}</div>`;
    return h + nextBtn();
  }
  function countPick(d, i) { if (!d.res || d.res.length < 2) return ''; const n = d.res.filter(r => r.ch === i || r.ch2 === i).length; return n ? `<span style="float:left;opacity:.85;font-size:13px">×${n}</span>` : ''; }
  function gBoard(V, d) {
    const ts = sideById(d.turn); const can = canAct(d.turn);
    let h = scoreboard(d.turn) + `<div class="turnline">دور ${esc(ts.name)}${can ? ' — اختر سؤالاً' : ''}</div>`;
    h += `<div class="board" style="grid-template-columns:repeat(${d.cats.length},1fr)">${d.cats.map(c => `<div class="bcol-h"><span><span class="ce">${c.icon}</span><br>${esc(c.name)}</span></div>`).join('')}`;
    const rows = []; [1, 2, 3, 4].forEach(lv => { for (let k = 0; k < d.copies; k++) rows.push({ lv, k }); });
    rows.forEach(r => { d.cats.forEach((c, ci) => { const cell = d.cells.filter(x => x.ci === ci && x.lv === r.lv)[r.k]; h += `<button class="cell ${cell.used ? 'used' : ''}" data-a="cell" data-id="${cell.id}" ${!can ? 'style="pointer-events:none"' : ''}>${cell.v}</button>`; }); });
    h += `</div>`;
    if (d.helpers[d.turn]) { const hs = d.helpers[d.turn]; h += `<div class="helpers mut" style="font-size:13px">وسائل ${esc(ts.name)} المتبقية: ${[hs.call ? 'اتصال بصديق' : '', hs.two ? 'جاوب جوابين' : '', hs.hole ? 'الحفرة' : ''].filter(Boolean).join(' · ') || 'لا شيء'}</div>`; }
    if (isHost()) h += `<div class="foot"><div class="in"><button class="btn grow" data-a="skipround">إنهاء اللوحة</button><button class="btn" data-a="menu">${ICON.menu}</button></div></div>`;
    return h;
  }
  function gOpen(V, d) {
    const cur = d.step === 'steal' ? d.stealer : d.who[0]; const s = sideById(cur);
    let h = scoreboard(cur) + qhead(d) + timerUI() + `<div class="subline">${d.step === 'steal' ? 'فرصة سرقة لـ ' : 'يجيب: '}${esc(s.name)} — ${d.value}</div>` + qbox(d.text, d);
    if (d.answer) h += `<div class="shown">الإجابة: ${esc(d.answer)}</div>`;
    if (isHost()) h += `<div class="foot"><div class="in">${d.step === 'ask' ? `<button class="btn gold grow" data-a="judge" data-step="show">أظهر الإجابة</button>` : ''}<button class="btn ok grow" data-a="judge" data-ok="1">${ICON.check} صح</button><button class="btn bad grow" data-a="judge" data-ok="0">${ICON.x} خطأ</button></div></div>`;
    else h += `<div class="center mut">جاوب بصوت عالٍ… والحَكَم يقرر!</div>`;
    return h;
  }
  function buzzBtnLocal(V, d, lockedArr, label) {
    const ready = armed(d);
    return `<div class="buzzgrid">${V.sides.map(s => `<button class="buzz ${lockedArr.includes(s.id) || !ready ? 'locked' : ''}" style="background:radial-gradient(circle at 35% 30%,${s.color}ee,${s.color}88 70%,#0b0f1a)" data-a="buzz" data-as="${s.id}"><span class="g">${esc(s.emoji)}</span>${!ready ? 'استعد…' : esc(label || s.name)}</button>`).join('')}</div>`;
  }
  function gBuzz(V, d) {
    const ready = armed(d);
    let h = scoreboard() + qhead(d) + timerUI() + qbox(d.text, d) + `<div class="subline">${d.value} نقطة — والخطأ يخصم ${d.value / 2}</div>`;
    if (d.wrong) h += `<div class="center minus">${esc(sideById(d.wrong).name)} أخطأ — الجرس مقفل عليه</div>`;
    if (!ready) h += `<div class="armbar"><i></i><span>استعدوا… الجرس يُفتح بعد ثانية</span></div>`;
    if (V.local) h += buzzBtnLocal(V, d, d.locked);
    else { const me = mySide(); const capB = me && isCapBlocked(me); h += capB ? capNote() : me ? `<div style="margin-top:20px"><button class="buzz big ${d.locked.includes(me) || !ready ? 'locked' : ''}" data-a="buzz">${ready ? ICON.buzzer : '<b style="font-size:22px">استعد</b>'}</button></div>` : ''; }
    return h + (isHost() ? `<div class="foot"><div class="in"><button class="btn grow" data-a="skipround">إنهاء الجولة</button><button class="btn" data-a="menu">${ICON.menu}</button></div></div>` : '');
  }
  function gBuzzed(V, d) {
    const s = sideById(d.buzzer);
    return scoreboard(d.buzzer) + qhead(d) + qbox(d.text, d) + `<div class="buzzed" style="--c:${s.color}"><div class="g">${esc(s.emoji)}</div><h2>${esc(s.name)}</h2><div>ضغط الجرس أولاً!</div><div class="lockring"></div><small class="mut">الإجابة مقفلة لثانية…</small></div>`;
  }
  function gKready(V, d) {
    const s = sideById(d.side);
    let h = scoreboard(d.side) + qhead(d) + `<div class="roundbanner"><div class="ri" style="font-size:34px">${esc(s.emoji)}</div><h2>دور ${esc(s.name)}</h2><div class="mut">الموضوع:</div><div class="qbox">${esc(d.topic)}</div><div class="mut">لديك ${d.time} ثانية — اكتب كل إجابة واضغط إدخال</div></div>`;
    if (canAct(d.side) || isHost()) h += `<div class="foot"><div class="in"><button class="btn gold grow" data-a="kgo">ابدأ</button></div></div>`;
    return h;
  }
  function gKnow(V, d) {
    const s = sideById(d.side); const can = canAct(d.side);
    let h = `<div class="knowtop"><div class="kt1"><span class="ktopic">${esc(d.topic)}</span><span class="kcount">${d.found.length}${d.target ? ' / ' + d.target : ''}</span></div>${timerUI()}`;
    if (can) h += `<form class="typebox" data-f="text" data-as="${d.side}"><input id="tin" autocomplete="off" placeholder="اكتب إجابة..." enterkeyhint="send"><button class="btn gold">↵</button></form>`;
    else h += `<div class="subline">يجيب: ${esc(s.name)}</div>`;
    if (d.flash === 'bad' && can) h += `<div class="center minus kmsg">"${esc(d.lastBad)}" غير موجودة في القائمة</div>`;
    else if (d.flash === 'dup' && can) h += `<div class="center mut kmsg">ذكرتها من قبل!</div>`;
    else if (d.flash === 'ok' && d.found.length) h += `<div class="center plus kmsg">✓ ${esc(d.found[d.found.length - 1])}</div>`;
    h += `</div>`;
    h += `<div class="found">${d.found.slice().reverse().map((f, i) => `<span class="${i === 0 ? 'newest' : ''}">${esc(f)}</span>`).join('')}</div>` + scoreboard(d.side);
    if (isHost()) h += `<div class="foot"><div class="in"><button class="btn ok grow" data-a="manual">${ICON.plus} إجابة صحيحة (حَكَم)</button><button class="btn grow" data-a="kend">إنهاء</button><button class="btn" data-a="menu">${ICON.menu}</button></div></div>`;
    else if (can) h += `<div class="foot"><div class="in"><button class="btn grow" data-a="kend">إنهاء دوري</button></div></div>`;
    return h;
  }
  function gKres(V, d) {
    const s = sideById(d.side);
    let h = scoreboard() + qhead(d);
    if (d.auction) h += `<div class="verdict ${d.auctionOk ? 'ok' : 'bad'}">${d.auctionOk ? `${esc(s.name)} نجح بذكر ${d.target}  +${d.target * 100}` : `${esc(s.name)} لم ينجح (${d.found.length} من ${d.target}) — للخصوم +${d.target * 50}`}</div>`;
    else h += `<div class="verdict ok">${esc(s.name)} ذكر ${d.found.length} إجابة  +${d.score}</div>`;
    h += `<div class="qbox" style="min-height:60px;font-size:18px">${esc(d.topic)}</div><div class="found">${d.found.map(f => `<span>${esc(f)}</span>`).join('')}</div>`;
    if (d.missed && d.missed.length) h += `<div class="mut" style="margin-top:12px">إجابات أخرى كانت ممكنة:</div><div class="found">${d.missed.map(f => `<span class="miss">${esc(f)}</span>`).join('')}</div>`;
    return h + nextBtn();
  }
  function gBid(V, d) {
    const t = sideById(d.turn); const can = canAct(d.turn);
    let h = scoreboard(d.turn) + qhead(d) + `<div class="qbox">${esc(d.topic)}</div><div class="center mut">عدد الإجابات الممكنة في قاعدة البيانات: ${d.total}</div>`;
    h += `<div class="bigcount" style="margin:14px 0">${d.bid || '—'}</div><div class="center mut">${d.bidder ? `أعلى مزايدة: ${esc(sideById(d.bidder).name)}` : 'لا مزايدات بعد'}</div>`;
    h += `<div class="turnline">الدور على ${esc(t.name)}</div>`;
    if (d.passed.length) h += `<div class="center mut">انسحب: ${d.passed.map(p => esc(sideById(p).name)).join('، ')}</div>`;
    if (can) { const opts = []; for (let k = d.bid + 1; k <= Math.min(d.total, d.bid + 12); k++) opts.push(k); h += `<div class="chips" style="justify-content:center;margin-top:10px">${opts.map(k => `<button class="chip" style="font-size:20px;padding:10px 16px" data-a="bid" data-n="${k}" data-as="${d.turn}">${k}</button>`).join('')}</div><div class="foot"><div class="in"><button class="btn bad grow" data-a="pass" data-as="${d.turn}">انسحاب</button></div></div>`; }
    return h;
  }
  function gWho(V, d) {
    let h = scoreboard() + qhead(d) + timerUI() + `<div class="subline">من أنا؟ — قيمة الإجابة الآن ${d.pts}</div><div class="clues">`;
    for (let i = 0; i < d.total; i++) h += i < d.clues.length ? `<div class="clue"><b>${i + 1}</b>${esc(d.clues[i])}</div>` : `<div class="clue hid"><b>${i + 1}</b>تلميح مخفي…</div>`;
    h += `</div>`;
    if (d.wrong) h += `<div class="center minus">${esc(sideById(d.wrong.s).name)}: "${esc(d.wrong.txt)}" إجابة خاطئة</div>`;
    if (V.local) {
      if (d.buzzer) { const s = sideById(d.buzzer); h += `<div class="subline">${esc(s.name)} يخمّن:</div><form class="typebox" data-f="text" data-as="${d.buzzer}"><input id="tin" autocomplete="off" placeholder="اكتب الإجابة"><button class="btn gold">↵</button></form>`; }
      else h += buzzBtnLocal(V, d, d.locked, 'عرفتها');
    } else { const me = mySide(); const capB = me && isCapBlocked(me); if (capB) h += capNote(); else if (me && !d.locked.includes(me)) h += `<form class="typebox" data-f="text"><input id="tin" autocomplete="off" placeholder="اكتب تخمينك…"><button class="btn gold">↵</button></form>`; else if (me) h += `<div class="center mut">انتظر التلميح التالي…</div>`; }
    if (isHost()) h += `<div class="foot"><div class="in"><button class="btn grow" data-a="giveup">كشف الإجابة</button><button class="btn" data-a="menu">${ICON.menu}</button></div></div>`;
    return h;
  }

  // ---- خلية الحروف ----
  function hexGrid(d, clickable) {
    const two = d.two; const red = sideById(two[0]), blue = two[1] ? sideById(two[1]) : null;
    const col = o => o === two[0] ? 'r' : (o && o === two[1]) ? 'b' : o === 'x' ? 'x' : '';
    let rows = '';
    for (let r = 0; r < HEX_N; r++) {
      let cells = '';
      for (let c = 0; c < HEX_N; c++) { const cell = d.cells[r * HEX_N + c]; const cur = d.cell === cell.i && (A.V.ph === 'hexq' || A.V.ph === 'hexres'); cells += `<button class="hx ${col(cell.o)} ${cur ? 'cur' : ''}" ${clickable && !cell.o ? `data-a="hexcell" data-i="${cell.i}"` : 'disabled'}><span>${esc(cell.ch)}</span></button>`; }
      rows += `<div class="hxrow ${r % 2 ? 'odd' : ''}">${cells}</div>`;
    }
    return `<div class="hexwrap"><div class="hxedge top" style="background:${blue ? blue.color : '#2f62b8'}"></div><div class="hxmid"><div class="hxedge side" style="background:${red.color}"></div><div class="hexgrid">${rows}</div><div class="hxedge side" style="background:${red.color}"></div></div><div class="hxedge top" style="background:${blue ? blue.color : '#2f62b8'}"></div></div>
      <div class="hxlegend"><span><i style="background:${red.color}"></i>${esc(red.name)}: يمين ↔ يسار</span>${blue ? `<span><i style="background:${blue.color}"></i>${esc(blue.name)}: أعلى ↕ أسفل</span>` : ''}</div>`;
  }
  function gHex(V, d) {
    let h = scoreboard(V.ph === 'hexpick' ? d.turn : d.buzzer);
    if (V.ph === 'hexpick') {
      const can = canAct(d.turn);
      h += `<div class="turnline">دور ${esc(sideById(d.turn).name)}${can ? ' — اختر خلية' : ''}</div>${d.msg ? `<div class="center mut">${esc(d.msg)}</div>` : ''}` + hexGrid(d, can);
      return h + menuOnly(isHost() ? `<button class="btn grow" data-a="skipround">إنهاء الجولة</button>` : '');
    }
    if (V.ph === 'hexend') { const w = sideById(d.winner); return h + `<div class="verdict ok">${esc(w.name)} أكمل المسار! +1000</div>` + hexGrid(d, false) + nextBtn(); }
    h += qhead(d) + (V.ph === 'hexq' ? timerUI() : '');
    h += `<div class="hxq"><div class="hxbig">${esc(d.ch)}</div>` + qbox(d.text, d) + `</div>`;
    if (V.ph === 'hexres') {
      h += d.ok ? `<div class="verdict ok">${esc(sideById(d.ok).name)} أخذ الخلية +100</div>` : `<div class="verdict bad">لم يعرفها أحد</div>`;
      h += `<div class="shown">الجواب: ${esc(d.answer)}</div>` + hexGrid(d, false) + nextBtn();
      return h;
    }
    if (d.wrong) h += `<div class="center minus">${esc(sideById(d.wrong.s).name)}: "${esc(d.wrong.txt)}" خطأ — الفرصة للفريق الآخر</div>`;
    const ready = armed(d);
    const elig = d.two.filter(s => s && !d.tried.includes(s));
    if (d.buzzer) {
      const s = sideById(d.buzzer);
      h += `<div class="subline">يجيب: ${esc(s.name)}</div>`;
      if (canAct(d.buzzer)) h += `<form class="typebox" data-f="text" data-as="${d.buzzer}"><input id="tin" autocomplete="off" placeholder="اكتب جواباً يبدأ بـ «${esc(d.ch)}»"><button class="btn gold">↵</button></form>`;
      if (isHost() && (V.local || !canAct(d.buzzer))) h += `<div class="row" style="margin-top:22px"><button class="btn ok grow sm" data-a="judge" data-ok="1">${ICON.check} قبول (حَكَم)</button><button class="btn bad grow sm" data-a="judge" data-ok="0">${ICON.x} رفض</button></div>`;
    } else {
      if (!ready) h += `<div class="armbar"><i></i><span>استعدوا…</span></div>`;
      if (V.local) h += `<div class="buzzgrid">${elig.map(sid => { const s = sideById(sid); return `<button class="buzz ${!ready ? 'locked' : ''}" style="background:radial-gradient(circle at 35% 30%,${s.color}ee,${s.color}88 70%,#0b0f1a);max-height:140px" data-a="buzz" data-as="${sid}"><span class="g">${esc(s.emoji)}</span>${ready ? 'عرفتها' : 'استعد…'}</button>`; }).join('')}</div>`;
      else { const me = mySide(); const capB = me && isCapBlocked(me); if (capB) h += capNote(); else if (me && elig.includes(me)) h += `<div style="margin-top:14px"><button class="buzz big ${!ready ? 'locked' : ''}" data-a="buzz">${ready ? ICON.buzzer : '<b style="font-size:22px">استعد</b>'}</button></div>`; else h += `<div class="center mut">يتنافس ${d.two.filter(Boolean).map(x => esc(sideById(x).name)).join(' و')}</div>`; }
    }
    return h + menuOnly();
  }

  // ---- حرب الفئات ----
  function gCw(V, d) {
    const can = canAct(d.chooser);
    let h = scoreboard([d.chooser]) + qhead(d) + `<div class="turnline">${esc(sideById(d.chooser).name)} يختار سؤالاً لـ ${esc(sideById(d.target).name)}</div>`;
    if (can) {
      h += `<div class="card"><label class="lab">١. اختر الفئة</label><div class="chips">${d.cats.map(c => `<button class="chip ${A.sel.cw === c.id ? 'on' : ''}" data-a="cwcat" data-c="${c.id}"><span class="ce">${c.icon}</span>${esc(c.name)}</button>`).join('')}</div>
        <label class="lab">٢. اختر الصعوبة</label><div class="chips">${d.levels.map(l => `<button class="chip" data-a="cwlvl" data-l="${l}" ${A.sel.cw ? '' : 'disabled'}><span class="lvl l${l}">${LVL[l]}</span> ${l * 100}</button>`).join('')}</div>
        <div class="hint">إن أجاب الخصم كسب ${'100×المستوى'}، وإن أخطأ كسبت أنت نصفها.</div></div>`;
    } else h += `<div class="waiting mut">بانتظار اختيار ${esc(sideById(d.chooser).name)}<span class="dots"></span></div>`;
    return h + menuOnly();
  }

  // ---- السلسلة ----
  function gChain(V, d) {
    const s = sideById(d.side); const can = canAct(d.side);
    let h = scoreboard([d.side]) + qhead(d) + timerUI();
    h += `<div class="chainhead"><div class="mut">الموضوع</div><b>${esc(d.topic)}</b><div class="req">الحرف المطلوب: <span>${esc(d.req === 'ة' ? 'ة (هـ أو ت)' : d.req)}</span></div><div class="mut" style="font-size:13px;margin-top:6px">"ال" لا تُحسب (القاهرة تبدأ بـ ق) — إجابات متاحة بهذا الحرف: ${d.opts}</div></div>`;
    if (d.miss && d.miss.words.length) h += `<div class="center mut" style="font-size:14px">كان يمكن لـ${esc(sideById(d.miss.side).name)} أن يجيب بحرف «${esc(d.miss.req)}»: ${d.miss.words.map(esc).join('، ')}</div>`;
    if (d.msg) h += `<div class="center ${d.flash === 'bad' ? 'minus' : 'plus'}">${esc(d.msg)}</div>`;
    h += `<div class="turnline">دور ${esc(s.name)}</div>`;
    if (can) h += `<form class="typebox" data-f="text" data-as="${d.side}"><input id="tin" autocomplete="off" placeholder="كلمة تبدأ بـ «${esc(d.req)}»"><button class="btn gold">↵</button></form>`;
    if (d.bad && can) h += `<div class="center minus">${esc(d.bad)}</div>`;
    if (d.out && d.out.length) h += `<div class="center mut">خرج: ${d.out.map(x => esc(sideById(x).name)).join('، ')}</div>`;
    h += `<div class="found chainlist">${d.used.slice(-30).map(f => `<span>${esc(f)}</span>`).join('<i>←</i>')}</div>`;
    if (isHost() && (V.local || !canAct(d.side))) h += `<div class="foot"><div class="in"><button class="btn ok grow" data-a="judge" data-ok="1">${ICON.check} قبول (حَكَم)</button><button class="btn bad grow" data-a="judge" data-ok="0">${ICON.x} إخراج</button><button class="btn" data-a="menu">${ICON.menu}</button></div></div>`;
    else if (isHost()) h += menuOnly();
    return h;
  }
  function gChainEnd(V, d) {
    let h = scoreboard() + qhead(d) + `<div class="verdict ${d.winner ? 'ok' : 'neu'}">${d.winner ? `${esc(sideById(d.winner).name)} آخر الصامدين! +500` : `انتهت السلسلة — ${d.count} إجابة`}</div>`;
    if (d.miss && d.miss.words.length) h += `<div class="shown">خرج ${esc(sideById(d.miss.side).name)} عند حرف «${esc(d.miss.req)}» — وكان يمكنه أن يقول: <b>${d.miss.words.map(esc).join('، ')}</b></div>`;
    if (d.used.length) h += `<div class="mut" style="margin-top:10px">السلسلة:</div><div class="found chainlist">${d.used.map(f => `<span>${esc(f)}</span>`).join('<i>←</i>')}</div>`;
    if (d.missed.length) h += `<div class="mut" style="margin-top:10px">أمثلة من كلمات لم تُذكر:</div><div class="found">${d.missed.map(f => `<span class="miss">${esc(f)}</span>`).join('')}</div>`;
    return h + nextBtn();
  }

  // ---- عجلة الحظ ----
  function wheelSvg(segs) {
    const n = segs.length, R = 100, a = 2 * Math.PI / n; let g = '';
    segs.forEach((sg, i) => {
      const a0 = -Math.PI / 2 + i * a, a1 = a0 + a;
      const x0 = 110 + R * Math.cos(a0), y0 = 110 + R * Math.sin(a0), x1 = 110 + R * Math.cos(a1), y1 = 110 + R * Math.sin(a1);
      const mid = (i + .5) * 360 / n;
      g += `<path d="M110 110L${x0.toFixed(1)} ${y0.toFixed(1)}A${R} ${R} 0 0 1 ${x1.toFixed(1)} ${y1.toFixed(1)}Z" fill="${sg.c}" stroke="#0b0f1a" stroke-width="1.5"/>`;
      const flip = mid > 180; g += `<text transform="rotate(${flip ? mid + 90 : mid - 90} 110 110)" x="${flip ? 110 - R * .56 : 110 + R * .56}" y="110" text-anchor="middle" dominant-baseline="middle" font-size="9.5" font-weight="700" fill="#fff" font-family="Cairo">${esc(sg.t)}</text>`;
    });
    return `<svg viewBox="0 0 220 220">${g}<circle cx="110" cy="110" r="16" fill="#d4af37" stroke="#0b0f1a" stroke-width="3"/></svg>`;
  }
  function gWheel(V, d) {
    const s = sideById(d.side); const can = canAct(d.side);
    let h = scoreboard(d.side) + qhead(d) + `<div class="turnline">دور ${esc(s.name)}</div>`;
    const n = d.segs.length; const rot = d.seg === null ? 0 : d.spin * 360 + (360 - (d.seg + .5) * 360 / n);
    h += `<div class="wheelbox"><div class="wpin"></div><div class="wheel" data-rot="${rot}" data-key="${V.ri}-${d.title}">${wheelSvg(d.segs)}</div></div>`;
    if (V.ph === 'wheel' && d.seg === null) h += can ? `<button class="btn gold wide" style="margin-top:14px;font-size:20px" data-a="spin">🎡 لفّ العجلة</button>` : `<div class="center mut">بانتظار ${esc(s.name)} ليلفّ العجلة<span class="dots"></span></div>`;
    if (V.ph === 'wheelres') h += `<div class="verdict ${d.delta > 0 ? 'ok' : d.delta < 0 ? 'bad' : 'neu'}">${esc(d.msg)}</div>` + nextBtn();
    return h + (V.ph === 'wheel' ? menuOnly() : '');
  }
  function animWheel() {
    const w = document.querySelector('.wheel[data-rot]'); if (!w) return;
    const rot = +w.dataset.rot, key = w.dataset.key + '|' + rot;
    if (!rot) { w.style.transform = 'rotate(0deg)'; return; }
    if (A.wheelKey === key) { w.style.transition = 'none'; w.style.transform = `rotate(${rot}deg)`; return; }
    A.wheelKey = key; w.style.transition = 'none'; w.style.transform = 'rotate(0deg)';
    requestAnimationFrame(() => requestAnimationFrame(() => { w.style.transition = 'transform 4s cubic-bezier(.12,.7,.15,1)'; w.style.transform = `rotate(${rot}deg)`; }));
    let k = 0; const t = setInterval(() => { SFX.tick(); if (++k > 14) clearInterval(t); }, 260);
  }
  // ---- القنبلة الموقوتة ----
  function gBomb(V, d) {
    let h = scoreboard(V.ph === 'bombboom' ? [] : [d.holder || d.to]) + qhead(d);
    if (V.ph === 'bombarm') h += `<div class="bombbig"><span>💣</span><h2>قنبلة جديدة!</h2><div>تبدأ مع <b>${esc(sideById(d.holder).name)}</b></div><small class="mut">وقت الانفجار مخفي… أجيبوا بسرعة وصحيح</small></div>` + nextBtn();
    else if (V.ph === 'bombpass') h += `<div class="bombbig small"><span>${d.wrong ? '😬' : '🏃'}</span>${d.wrong ? `<h2 class="minus">خطأ!</h2><div>القنبلة باقية مع <b>${esc(sideById(d.from).name)}</b></div>` : `<h2 class="plus">صح! +100</h2><div>القنبلة انتقلت إلى <b>${esc(sideById(d.to).name)}</b></div>`}<small class="mut">الجواب: ${esc(d.ans)}</small></div>`;
    else h += `<div class="bombbig boom"><span>💥</span><h2>انفجرت مع ${esc(sideById(d.side).name)}!</h2><small class="mut">الجواب كان: ${esc(d.ans)}</small></div><div class="reslist">${Object.keys(d.deltas).map(sid => `<div class="resi ${d.deltas[sid] > 0 ? 'ok' : 'bad'}"><span>${esc(sideById(sid).emoji)} ${esc(sideById(sid).name)}</span><span class="${d.deltas[sid] > 0 ? 'plus' : 'minus'}">${d.deltas[sid] > 0 ? '+' : ''}${d.deltas[sid]}</span></div>`).join('')}</div>` + nextBtn();
    return h;
  }
  // ---- الرهان ----
  function gWager(V, d) {
    const cat = QB.cats[d.c] || { name: d.c, icon: '' };
    let h = scoreboard(d.who.filter(s => !d.bets[s])) + qhead(d) + timerUI() + capNote();
    h += `<div class="wagerbox"><div class="wk">تصنيف السؤال</div><div class="wc">${cat.icon || ''} ${esc(cat.name)}</div><div class="wl"><span class="lvl l${d.l}">${LVL[d.l]}</span></div><div class="mut">كم تراهن؟ الصح يضيف رهانك والخطأ يخصمه</div></div>`;
    const row = sid => { const sd = sideById(sid); const b = d.bets[sid]; const mine = canAct(sid);
      return `<div class="wrow" style="--c:${sd.color}"><div class="wn">${av(sd.emoji, sd.color)}<b>${esc(sd.name)}</b>${b ? `<span class="wb">${b === sd.score && b > 500 ? 'كل الرصيد ' : ''}${b}</span>` : '<span class="mut">يفكر…</span>'}</div>
        ${mine && !b ? `<div class="wopts">${d.opts[sid].map(n => `<button class="btn sm ${n > 500 ? 'gold' : ''}" data-a="bet" data-n="${n}" data-as="${sid}">${n > 500 ? 'كل الرصيد ' + n : n}</button>`).join('')}</div>` : ''}</div>`; };
    h += `<div class="wrows">${d.who.map(row).join('')}</div>`;
    if (isHost()) h += `<div class="foot"><div class="in"><button class="btn grow" data-a="next">اعرض السؤال الآن</button><button class="btn" data-a="menu">${ICON.menu}</button></div></div>`;
    return h;
  }
  // ---- فك الشيفرة ----
  function gCipher(V, d) {
    const res = V.ph === 'cipherres';
    let h = scoreboard(d.buzzer ? [d.buzzer] : []) + qhead(d) + (res ? '' : timerUI()) + capNote();
    h += `<div class="ciphead"><span class="ct">${d.type === 'sym' ? 'شيفرة الرموز' : 'شيفرة الإزاحة'}</span><span>التصنيف: <b>${esc(d.topic || '')}</b></span></div>`;
    h += `<div class="ciph">${d.enc.map((e, i) => e === ' ' ? '<i class="gap"></i>' : `<div class="cc ${d.dec[i] ? 'on' : ''}"><b>${esc(e)}</b><span>${esc(d.dec[i] || '؟')}</span></div>`).join('')}</div>`;
    if (d.type === 'sym') h += `<div class="ckey"><small class="mut">المفاتيح المكشوفة</small><div>${(d.key || []).map(k => `<span><b>${esc(k.s)}</b> = ${esc(k.c)}</span>`).join('') || '<span class="mut">لا شيء بعد</span>'}</div></div>`;
    else h += `<div class="ckey"><small class="mut">${d.k ? `المفتاح: كل حرف أُزيح <b class="gold">${d.k}</b> ${d.k === 1 ? 'خطوة' : 'خطوات'} للأمام — ارجع ${d.k} للخلف` : 'مقدار الإزاحة مخفي… سيُكشف قريباً'}</small><div class="abj">${[...(d.abj || 'ابتثجحخدذرزسشصضطظعغفقكلمنهوي')].map(c => `<i>${c}</i>`).join('')}</div></div>`;
    if (res) {
      h += d.winner ? `<div class="verdict ok">${esc(sideById(d.winner).name)} فكّ الشيفرة! +${d.pts}</div>` : `<div class="verdict neu">لم يفكّها أحد — الكلمة: ${esc(d.answer)}</div>`;
      return h + nextBtn();
    }
    h += `<div class="subline">قيمة الحل الآن ${d.pts} — مفاتيح مخفية: ${d.left}</div>`;
    if (d.wrong) h += `<div class="center minus">${esc(sideById(d.wrong.s).name)}: "${esc(d.wrong.txt)}" خطأ</div>`;
    if (V.local) {
      if (d.buzzer) h += `<div class="subline">${esc(sideById(d.buzzer).name)} يحلّ:</div><form class="typebox" data-f="text" data-as="${d.buzzer}"><input id="tin" autocomplete="off" placeholder="اكتب الكلمة"><button class="btn gold">↵</button></form>`;
      else h += buzzBtnLocal(V, d, d.locked, 'فككتها');
    } else { const me = mySide(); if (me && canAct(me) && !d.locked.includes(me)) h += `<form class="typebox" data-f="text"><input id="tin" autocomplete="off" placeholder="اكتب الكلمة بعد فكّها…"><button class="btn gold">↵</button></form>`; else if (me && d.locked.includes(me)) h += `<div class="center mut">انتظر المفتاح التالي…</div>`; }
    if (isHost()) h += `<div class="foot"><div class="in"><button class="btn grow" data-a="giveup">كشف الحل</button><button class="btn" data-a="menu">${ICON.menu}</button></div></div>`;
    return h;
  }
  // ---- الكلمة الضائعة ----
  function gWord(V, d) {
    let h = scoreboard(d.buzzer ? [d.buzzer] : []) + qhead(d) + (V.ph === 'word' ? timerUI() : '');
    h += `<div class="qbox" data-lp="report" style="min-height:80px">${esc(d.clue)}</div>`;
    h += `<div class="tiles">${d.mask.map(ch => ch === ' ' ? '<i class="gap"></i>' : `<b class="${ch ? 'on' : ''}">${esc(ch)}</b>`).join('')}</div>`;
    if (V.ph === 'wordres') {
      h += d.winner ? `<div class="verdict ok">${esc(sideById(d.winner).name)} عرفها! +${d.pts}</div>` : `<div class="verdict neu">لم يعرفها أحد — الكلمة: ${esc(d.answer)}</div>`;
      return h + nextBtn();
    }
    h += `<div class="subline">قيمة التخمين الآن ${d.pts} — حروف مخفية: ${d.left}</div>`;
    if (d.wrong) h += `<div class="center minus">${esc(sideById(d.wrong.s).name)}: "${esc(d.wrong.txt)}" خطأ</div>`;
    if (V.local) {
      if (d.buzzer) h += `<div class="subline">${esc(sideById(d.buzzer).name)} يخمّن:</div><form class="typebox" data-f="text" data-as="${d.buzzer}"><input id="tin" autocomplete="off" placeholder="اكتب الكلمة"><button class="btn gold">↵</button></form>`;
      else h += buzzBtnLocal(V, d, d.locked, 'عرفتها');
    } else { const me = mySide(); const capB = me && isCapBlocked(me); if (capB) h += capNote(); else if (me && !d.locked.includes(me)) h += `<form class="typebox" data-f="text"><input id="tin" autocomplete="off" placeholder="اكتب الكلمة…"><button class="btn gold">↵</button></form>`; else if (me) h += `<div class="center mut">انتظر الحرف التالي…</div>`; }
    if (isHost()) h += `<div class="foot"><div class="in"><button class="btn grow" data-a="giveup">كشف الكلمة</button><button class="btn" data-a="menu">${ICON.menu}</button></div></div>`;
    return h;
  }

  function leaderboard() {
    const V = A.V; const rk = V.d.ranking.map(sideById);
    return `<div class="roundbanner" style="padding:18px 0 4px"><div class="ri">${ICON.trophy}</div><h2 style="font-size:30px">الترتيب</h2></div><div class="lb">${rk.map((s, i) => `<div class="lbi" style="animation-delay:${i * .08}s;border-right:3px solid ${s.color}"><span class="rk">${i + 1}</span>${av(s.emoji, s.color)}<span>${esc(s.name)}</span>${s.streak > 1 ? `<span class="st">${ICON.fire}${s.streak}</span>` : ''}<span class="sc">${s.score}</span>${s.last ? `<span class="${s.last > 0 ? 'plus' : 'minus'}" style="font-size:13px">${s.last > 0 ? '+' : ''}${s.last}</span>` : ''}</div>`).join('')}</div>` + nextBtn();
  }
  function podium() {
    const V = A.V; const rk = V.d.ranking.map(sideById); const sum = V.d.sum || { sides: {} };
    const slot = (s, cls, n) => s ? `<div class="pod ${cls}">${av(s.emoji, s.color)}<div class="nm">${esc(s.name)}</div><div class="sc">${s.score}</div><div class="bar" style="margin-top:6px">${n}</div></div>` : '<div class="pod"></div>';
    let st = '';
    const hi = [];
    if (sum.mvp && !V.local && Object.keys(V.players).length > 1) hi.push(`<div class="hl">${ICON.trophy}<b>نجم المباراة</b><span>${esc(sum.mvp.name)} — ${sum.mvp.ok} إجابة صحيحة</span></div>`);
    if (sum.fast) hi.push(`<div class="hl">⚡<b>أسرع إجابة صحيحة</b><span>${esc(sum.fast.name)} — ${sum.fast.sec} ث</span></div>`);
    let longest = null; for (const id in sum.sides) { const x = sum.sides[id]; if (x.best > 1 && (!longest || x.best > longest.best)) longest = { id, best: x.best }; }
    if (longest) hi.push(`<div class="hl">${ICON.fire}<b>أطول سلسلة صحيحة</b><span>${esc(sideById(longest.id).name)} — ${longest.best} متتالية</span></div>`);
    if (hi.length) st += `<div class="hls">${hi.join('')}</div>`;
    const rows = rk.filter(s => sum.sides[s.id]).map(s => { const x = sum.sides[s.id]; return `<div class="srow" style="border-right:3px solid ${s.color}"><b>${esc(s.name)}</b><span>${x.ok}/${x.n} صحيحة${x.n ? ` (${Math.round(100 * x.ok / x.n)}%)` : ''}</span><span>أفضل فئة: ${x.cat ? esc(x.cat.name) + ` ${x.cat.k}/${x.cat.n}` : '—'}</span><span>أطول سلسلة: ${x.best}</span></div>`; }).join('');
    if (rows) st += `<div class="card"><h3>${ICON.stats} إحصائيات المباراة</h3>${rows}</div>`;
    return `<div class="roundbanner" style="padding:20px 0 0"><div class="ri">${ICON.trophy}</div><h2>النتائج النهائية</h2><div class="orn">✦</div></div><div class="podium">${slot(rk[1], 'p2', 2)}${slot(rk[0], 'p1', 1)}${rk[2] ? slot(rk[2], 'p3', 3) : ''}</div>
    <div class="lb">${rk.slice(3).map((s, i) => `<div class="lbi"><span class="rk">${i + 4}</span>${av(s.emoji, s.color)}<span>${esc(s.name)}</span><span class="sc">${s.score}</span></div>`).join('')}</div>${st}
    <div class="row" style="margin-top:20px">${isHost() ? `<button class="btn gold grow" data-a="again">العب مجدداً</button>` : ''}<button class="btn grow" data-a="home">الرئيسية</button></div>`;
  }

  // ---------- مؤشر الاتصال ----------
  function dotHtml() {
    if (A.role === 'client') { const st = A.link || 'connecting'; return `<div id="netdot" class="netdot ${st}"><span class="ndot"></span>${linkLabel(st)}</div>`; }
    if (A.role === 'host' && A.H && E.G) { const n = Object.keys(A.pres).filter(k => A.pres[k].on !== false).length, tot = Object.keys(A.pres).length; return `<div id="netdot" class="netdot ${tot && n < tot ? 'lost' : 'p2p'}"><span class="ndot"></span>${n}/${tot} متصل</div>`; }
    return '';
  }
  function updDot() { const el = document.getElementById('netdot'); const h = dotHtml(); if (el) el.outerHTML = h || ''; else if (h) $app.insertAdjacentHTML('afterbegin', h); }

  // ---------- الرسم ----------
  function render() {
    const ae = document.activeElement; const keepId = ae && (ae.id === 'tin' || ae.id === 'nin') ? ae.id : null; const keepVal = keepId ? ae.value : '';
    $app.innerHTML = dotHtml() + (SCR[A.scr] || SCR.home)();
    liftTypebox();
    const tin = document.getElementById('tin') || document.getElementById('nin');
    if (tin) { if (keepId === tin.id && A.V && A.V.ph === A.prevPh) tin.value = keepVal; if (A.V && ['know', 'who', 'hexq', 'chain', 'q', 'word', 'cipher'].includes(A.V.ph)) setTimeout(() => tin.focus(), 30); }
    if (tin && A.V && (A.V.ph !== A.prevPh || qKey() !== A.prevQn)) { const tt = tin.closest('.knowtop'); if (tt) setTimeout(() => { const y = tt.getBoundingClientRect().top + window.scrollY - 4; if (y > 0) window.scrollTo({ top: y, behavior: 'smooth' }); }, 60); }
    A.prevPh = A.V && A.V.ph; A.prevQn = qKey();
    animWheel();
  }
  function qKey() { const d = A.V && A.V.d || {}; return [d.text, d.req, d.ch, d.buzzer, d.side, d.topic].join('|'); }
  // رفع مربع الكتابة لأعلى الشاشة (مع المؤقت) في كل الفقرات الكتابية حتى لا ينزل مع الكيبورد
  function liftTypebox() {
    if (A.scr !== 'game') return;
    const f = $app.querySelector('form.typebox'); if (!f || f.closest('.knowtop')) return;
    const box = document.createElement('div'); box.className = 'knowtop typetop';
    const tr = $app.querySelector('.timer'); const trow = tr && tr.closest('.row');
    const pv = f.previousElementSibling, nx = f.nextElementSibling;
    const lab = pv && (pv.classList.contains('subline') || pv.classList.contains('turnline')) ? pv : null;
    const fb = nx && nx.classList.contains('minus') ? nx : null;
    if (trow) { trow.parentNode.insertBefore(box, trow); box.appendChild(trow); }
    else { const sb = $app.querySelector('.sb'); if (sb && sb.nextSibling) sb.parentNode.insertBefore(box, sb.nextSibling); else f.parentNode.insertBefore(box, f); }
    if (lab) box.appendChild(lab);
    box.appendChild(f); if (fb) box.appendChild(fb);
  }

  // ---------- الضغط المطوّل للإبلاغ ----------
  let lpT = null, lpFired = false;
  const RS = [['q', 'السؤال غلط'], ['a', 'الجواب غلط'], ['dup', 'مكرر'], ['level', 'الصعوبة غير مناسبة']];
  function doReport() {
    const d = A.V && A.V.d; if (!d || !d.qid) return;
    const q = { id: d.qid, c: d.c, l: d.l, q: d.text || '', a: d.qa || (d.opts && d.ans != null ? d.opts[d.ans] : '') || d.answer || '' };
    modal('الإبلاغ عن هذا السؤال', RS.map(r => r[1]).concat(['إلغاء']), 'rep').then(i => {
      if (i < 0 || i >= RS.length) return;
      QB.report(q, RS[i][0]); if (A.role === 'client' && A.C) A.C.send({ t: 'report', q, reason: RS[i][0] });
      toast('شكراً! سُجّل البلاغ ولن يظهر هذا السؤال مجدداً' + (RS[i][0] === 'level' ? ' بنفس التصنيف' : ''));
    });
  }
  $app.addEventListener('touchstart', e => { const el = e.target.closest('[data-lp="report"]'); if (!el) return; lpFired = false; clearTimeout(lpT); lpT = setTimeout(() => { lpFired = true; if (navigator.vibrate) try { navigator.vibrate(30); } catch (x) { } doReport(); }, 650); }, { passive: true });
  ['touchend', 'touchmove', 'touchcancel'].forEach(ev => $app.addEventListener(ev, () => clearTimeout(lpT), { passive: true }));
  $app.addEventListener('contextmenu', e => { if (e.target.closest('[data-lp="report"]')) { e.preventDefault(); if (!lpFired) doReport(); lpFired = false; } });

  // ---------- ماسح QR ----------
  function loadScript(src) { return new Promise((res, rej) => { if (window.jsQR) return res(); const s = document.createElement('script'); s.src = src; s.onload = res; s.onerror = rej; document.head.appendChild(s); }); }
  async function scanQR() {
    try { await loadScript('js/jsqr.js'); } catch (e) { toast('تعذّر تحميل الماسح'); return; }
    let stream;
    try { stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } }); } catch (e) { toast('لم يُسمح باستخدام الكاميرا — أدخل الرمز يدوياً'); return; }
    const ov = document.createElement('div'); ov.className = 'scanov'; ov.innerHTML = `<video playsinline muted></video><div class="frame"></div><div class="hint">وجّه الكاميرا نحو رمز QR على شاشة المضيف</div><button class="btn">إغلاق</button>`;
    document.body.appendChild(ov);
    const v = ov.querySelector('video'); v.srcObject = stream; await v.play().catch(() => { });
    const cv = document.createElement('canvas'); const cx = cv.getContext('2d', { willReadFrequently: true });
    let done = false;
    const stop = () => { done = true; stream.getTracks().forEach(t => t.stop()); ov.remove(); };
    ov.querySelector('button').onclick = stop;
    const tick = () => {
      if (done) return;
      if (v.readyState >= 2) {
        const w = Math.min(640, v.videoWidth), hh = Math.round(v.videoHeight * w / v.videoWidth); cv.width = w; cv.height = hh; cx.drawImage(v, 0, 0, w, hh);
        const img = cx.getImageData(0, 0, w, hh); const r = jsQR(img.data, w, hh, { inversionAttempts: 'dontInvert' });
        if (r && r.data) { const m = r.data.match(/(\d{4})\s*$/); if (m) { stop(); SFX.coin(); A.pendingPin = m[1]; const p = document.getElementById('pin'); if (p) p.value = m[1]; if (A.me.name) H_dojoin(m[1]); else toast('اكتب اسمك ثم اضغط دخول'); return; } }
      }
      requestAnimationFrame(tick);
    };
    tick();
  }
  function H_dojoin(pin) { if (!A.me.name) { toast('اكتب اسمك أولاً'); return; } if (!/^\d{4}$/.test(pin)) { toast('الرمز 4 أرقام'); return; } store.set('me', A.me); A.role = 'client'; clientJoin(pin); }
  window.fahimDeepJoin = function (pin) { if (!/^\d{4}$/.test(pin)) return; leave(); A.role = 'client'; A.pendingPin = pin; go('join'); if (A.me.name) H_dojoin(pin); };

  // ---------- الأحداث ----------
  $app.addEventListener('click', e => {
    const el = e.target.closest('[data-a]'); if (!el) return;
    if (lpFired && el.closest('[data-lp]')) { lpFired = false; return; }
    SFX.unlock();
    const a = el.dataset.a, ds = el.dataset; const c = A.cfg;
    const asSide = ds.as || undefined;
    const H = {
      back() { if (A.scr === 'game' || A.scr === 'lobby' || A.scr === 'wait') { modal('الخروج من اللعبة الحالية؟', ['نعم، اخرج', 'إلغاء']).then(i => { if (i === 0) { leave(); go('home'); } }); return; } go('home'); },
      home() { leave(); go('home'); },
      local() { A.role = 'local'; go('setup'); },
      host() { A.role = 'host'; go('setup'); },
      join() { A.role = 'client'; go('join'); },
      practice() { A.role = 'local'; startLocal([{ name: A.me.name || 'أنت', emoji: A.me.emoji, color: COL[2] }], Object.assign({}, c, { modes: ['kahoot', 'emoji', 'tf', 'near', 'who', 'order'] })); },
      help() { go('help'); }, bank() { go('bank'); }, settings() { go('settings'); },
      sound() { SFX.on = !SFX.on; render(); },
      addside() { A.sides.push({ name: 'فريق ' + (A.sides.length + 1), emoji: EMO[(A.sides.length * 3) % EMO.length], color: COL[A.sides.length % COL.length] }); render(); },
      delside() { if (A.sides.length > 1) A.sides.splice(+ds.i, 1); render(); },
      emo() { A.emoPick = A.emoPick === +ds.i ? null : +ds.i; render(); },
      setemo() { A.sides[+ds.i].emoji = ds.e; A.emoPick = null; render(); },
      myemo() { A.me.emoji = ds.e; store.set('me', A.me); render(); },
      mode() { const k = ds.k; c.modes = c.modes.includes(k) ? c.modes.filter(x => x !== k) : [...c.modes, k]; render(); },
      modeall() { c.modes = Object.keys(MODES); render(); }, modenone() { c.modes = []; render(); },
      preset() { applyPreset(PRESETS[ds.p]); toast('تم تطبيق: ' + PRESETS[ds.p].name); render(); },
      mypreset() { const p = store.get('presets', [])[+ds.i]; if (p) { applyPreset(p); toast('تم تطبيق: ' + p.name); render(); } },
      delpreset() { const arr = store.get('presets', []); const p = arr[+ds.i]; modal(`حذف الإعداد "${esc(p.name)}"؟`, ['حذف', 'إلغاء']).then(i => { if (i === 0) { arr.splice(+ds.i, 1); store.set('presets', arr); render(); } }); },
      savepreset() {
        const m = document.createElement('div'); m.className = 'modal';
        m.innerHTML = `<div class="mbox"><p>اسم الإعداد</p><input id="pname" maxlength="24" placeholder="مثلاً: سهرة الشباب"><div class="mbtns"><button class="btn gold" data-ok="1">حفظ</button><button class="btn" data-ok="0">إلغاء</button></div></div>`;
        document.body.appendChild(m); setTimeout(() => m.querySelector('input').focus(), 50);
        m.addEventListener('click', ev => { const b = ev.target.closest('[data-ok]'); if (!b && ev.target !== m) return; if (b && b.dataset.ok === '1') { const nm = m.querySelector('input').value.trim() || 'إعدادي'; const arr = store.get('presets', []); arr.push({ name: nm, modes: c.modes.slice(), cats: c.cats.slice(), levels: c.levels.slice(), curve: c.curve, timer: c.timer, n: c.n, style: c.style, copies: c.copies, lives: c.lives, knowTime: c.knowTime, whoStep: c.whoStep, per: Object.assign({}, c.per || {}) }); store.set('presets', arr.slice(-12)); toast('حُفظ الإعداد'); } m.remove(); render(); });
      },
      cat() { const k = ds.k; c.cats = c.cats.includes(k) ? c.cats.filter(x => x !== k) : [...c.cats, k]; render(); },
      catall() { c.cats = QB.order.slice(); render(); }, catnone() { c.cats = []; render(); },
      catrnd() { c.cats = QB.shuffle(QB.order).slice(0, 6); render(); },
      lvl() { const l = +ds.l; c.levels = c.levels.includes(l) ? c.levels.filter(x => x !== l) : [...c.levels, l].sort(); if (!c.levels.length) c.levels = [l]; render(); },
      lvlp() { c.levels = { mix: [1, 2, 3, 4], easy: [1, 2], pro: [3, 4] }[ds.p]; c.curve = ds.p === 'mix'; render(); },
      style() { c.style = ds.v; render(); }, copies() { c.copies = +ds.v; render(); }, lives() { c.lives = +ds.v; render(); },
      start() { if (!validate()) return; startLocal(A.sides, c); },
      openroom() { if (!validate()) return; saveCfg(); go('lobby'); hostOpen(); },
      team() { const pid = ds.p; if (pid === 'host') A.hostTeam = ((A.hostTeam || 0) + 1) % NT(); else { A.lobby[pid].team = (A.lobby[pid].team + 1) % NT(); } hostLobbyBroadcast(); saveHost(true); render(); },
      setteams() { A.cfg.teams = ds.v === '1'; saveCfg(); if (A.cfg.teams) { const all = lobbyAll(); all.forEach(p => { if (p.team >= NT()) { if (p.id === 'host') A.hostTeam = 0; else A.lobby[p.id].team = 0; } }); } hostLobbyBroadcast(); saveHost(true); render(); },
      capset() { A.capPick = A.capPick || {}; const t = +ds.t; A.capPick[t] = A.capPick[t] === ds.p ? null : ds.p; hostLobbyBroadcast(); saveHost(true); render(); },
      capmenu() {
        const V = A.V; const me = mySide(); if (!V || !me) return; const c = capOf(me);
        const mates = Object.keys(V.players).filter(k => V.players[k].side === me && k !== A.myPid);
        if (c === A.myPid) { if (!mates.length) return; modal('سلّم قيادة الفريق إلى:', mates.map(k => V.players[k].name).concat(['إلغاء'])).then(i => { if (i >= 0 && i < mates.length) send({ type: 'setcap', side: me, pid: mates[i] }); }); }
        else if (isHost()) modal('تعيين قائد للفريق؟', ['أنا', 'إلغاء']).then(i => { if (i === 0) send({ type: 'setcap', side: me, pid: A.myPid }); });
      },
      mycap() { if (A.C) A.C.send({ t: 'cap', off: ds.off === '1' }); },
      nteams() { A.cfg.nTeams = +ds.n; saveCfg(); const n = NT(); Object.values(A.lobby || {}).forEach(p => { if (p.team >= n) p.team = smallestTeam(lobbyAll().filter(x => x.team < n)); }); if ((A.hostTeam || 0) >= n) A.hostTeam = 0; hostLobbyBroadcast(); saveHost(true); render(); },
      balance() { const all = QB.shuffle(lobbyAll()); all.forEach((p, i) => { const t = i % NT(); if (p.id === 'host') A.hostTeam = t; else A.lobby[p.id].team = t; }); hostLobbyBroadcast(); saveHost(true); render(); SFX.coin && SFX.coin(); },
      myteam() { if (A.C) { A.C.send({ t: 'team', team: +ds.t }); const me = A.lobby && A.lobby[A.myPid || A.uid]; if (me) { me.team = +ds.t; render(); } } },
      rejoinnow() { if (A.C) A.C.kick(true); toast('نحاول الآن…'); },
      hoststart() { startHost(); },
      dojoin() { H_dojoin((document.getElementById('pin').value || '').trim()); },
      scan() { scanQR(); },
      next() { send({ type: 'next' }); },
      resume() { send({ type: 'resume' }); },
      skipround() { modal('إنهاء هذه الجولة والانتقال للتالية؟', ['نعم', 'إلغاء']).then(i => { if (i === 0) send({ type: 'skipround' }); }); },
      menu() {
        const paused = A.V && A.V.paused;
        modal('القائمة', [paused ? '▶️ استئناف' : '⏸️ إيقاف مؤقت', '⏭️ تخطي الجولة', '🏠 إنهاء اللعبة', SFX.on ? '🔇 إيقاف الصوت' : '🔊 تشغيل الصوت', 'إغلاق']).then(i => {
          if (i === 0) send({ type: paused ? 'resume' : 'pause' }); else if (i === 1) send({ type: 'skipround' }); else if (i === 2) { leave(); go('home'); } else if (i === 3) { SFX.on = !SFX.on; }
        });
      },
      ans() { const i = +ds.i; const d = A.V.d; if (!A.V.local && isCapBlocked(mySide()) && A.V.ph === 'q') { send({ type: 'sug', i }); A.sel.sug = i; SFX.click(); render(); toast('أرسلت اقتراحك للقائد'); return; } if (d.two && A.sel.i === undefined && canAct(asSide || mySide())) { A.sel.i = i; render(); toast('اختر الإجابة الثانية'); return; } if (d.two && A.sel.i !== undefined) { send({ type: 'answer', i: A.sel.i, j: i, as: asSide }); A.sel.j = i; } else { A.sel.i = i; send({ type: 'answer', i, as: asSide }); } SFX.click(); },
      tf() { send({ type: 'answer', v: ds.v === '1', as: asSide }); SFX.click(); },
      ord() { const k = ds.k; if (A.ord.includes(k)) return; A.ord.push(k); SFX.click(); render(); },
      ordreset() { A.ord = []; render(); },
      bet() { send({ type: 'bet', n: +ds.n, as: ds.as }); SFX.click(); },
      ordsend() { send({ type: 'answer', arr: A.ord.slice(), as: asSide }); },
      helper() { send({ type: 'helper', h: ds.h, as: A.V.d.helpers && A.V.d.helpers.side }); },
      cell() { send({ type: 'cell', id: +ds.id, as: A.V.d.turn }); SFX.click(); },
      spin() { send({ type: 'spin', as: A.V.d.side }); SFX.click(); },
      hexcell() { send({ type: 'hexcell', i: +ds.i, as: A.V.d.turn }); SFX.click(); },
      cwcat() { A.sel.cw = ds.c; render(); },
      cwlvl() { if (!A.sel.cw) return; send({ type: 'cwpick', c: A.sel.cw, l: +ds.l, as: A.V.d.chooser }); A.sel.cw = null; SFX.click(); },
      judge() { if (A.V && A.jkAt && Date.now() - A.jkAt < 1200 && ds.ok !== '1') return; send({ type: 'judge', step: ds.step, ok: ds.ok === '1', k: A.V ? A.V.jk : undefined }); },
      buzz() { if (A.V && A.V.d && !armed(A.V.d)) return; send({ type: 'buzz', as: asSide }); },
      kgo() { send({ type: 'kgo', as: A.V.d.side }); },
      kend() { send({ type: 'kend', as: A.V.d.side }); },
      manual() { send({ type: 'manual' }); },
      bid() { send({ type: 'bid', n: +ds.n, as: asSide }); SFX.click(); },
      pass() { send({ type: 'pass', as: asSide }); },
      giveup() { send({ type: 'giveup' }); },
      again() { if (A.role === 'local') startLocal(A.V.sides.map(s => ({ name: s.name, emoji: s.emoji, color: s.color })), c); else startHost(); },
      addq() { const g = id => (document.getElementById(id).value || '').trim(); const q = { c: g('cq_c'), l: +g('cq_l'), q: g('cq_q'), a: g('cq_a'), w: [g('cq_w1'), g('cq_w2'), g('cq_w3')].filter(Boolean), i: g('cq_i') }; if (!q.q || !q.a || q.w.length < 3) { toast('أكمل السؤال والإجابات الأربع'); return; } QB.saveCustom(q); toast('تم حفظ السؤال'); render(); },
      resetseen() { QB.resetSeen(); toast('تمت إعادة الضبط'); },
      unrep() { QB.unreport(+ds.t); render(); },
      clearreps() { modal('مسح كل البلاغات؟ ستعود الأسئلة المبلّغ عنها للظهور.', ['مسح', 'إلغاء']).then(i => { if (i === 0) { QB.clearReports(); render(); } }); },
      copyreps() {
        const RN = { q: 'السؤال غلط', a: 'الجواب غلط', dup: 'مكرر', level: 'الصعوبة غير مناسبة' };
        const txt = QB.reports().map((r, i) => `${i + 1}. [${RN[r.reason] || r.reason}] ${r.q} — الجواب: ${r.a} (${(QB.cats[r.c] || {}).name || r.c}، ${LVL[r.l] || ''})`).join('\n');
        const done = () => toast('نُسخت البلاغات — الصقها لي لأصلحها');
        if (navigator.clipboard) navigator.clipboard.writeText(txt).then(done, () => fallbackCopy(txt, done)); else fallbackCopy(txt, done);
      },
      saveturn() {
        const g = id => (document.getElementById(id).value || '').trim(); let json = null; const tj = g('tjson');
        if (tj) { try { json = JSON.parse(tj); if (!Array.isArray(json)) json = [json]; } catch (e) { toast('صيغة JSON غير صحيحة'); return; } }
        store.set('turn', { url: g('turl'), user: g('tuser'), pass: g('tpass'), json, relayOnly: document.getElementById('trelay').checked }); toast('حُفظت إعدادات الاتصال');
      },
      clearturn() { try { localStorage.removeItem('fahim_turn'); } catch (e) { } toast('تمت الاستعادة'); render(); }
    };
    if (H[a]) H[a]();
  });
  function fallbackCopy(t, cb) { const ta = document.createElement('textarea'); ta.value = t; document.body.appendChild(ta); ta.select(); try { document.execCommand('copy'); cb(); } catch (e) { toast('تعذّر النسخ'); } ta.remove(); }
  $app.addEventListener('input', e => {
    const el = e.target; const k = el.dataset.in; if (!k) return; const c = A.cfg;
    if (k === 'sname') A.sides[+el.dataset.i].name = el.value;
    else if (k === 'myname') { A.me.name = el.value; store.set('me', A.me); }
    else if (k === 'per') { c.per = c.per || {}; c.per[el.dataset.k] = +el.value; el.nextElementSibling.textContent = el.value; }
    else if (['timer', 'n', 'knowTime', 'whoStep'].includes(k)) { c[k] = +el.value; el.nextElementSibling.textContent = el.value + (k === 'n' ? '' : ' ث'); }
  });
  $app.addEventListener('change', e => {
    const el = e.target; const k = el.dataset.in; const c = A.cfg;
    if (k === 'curve') c.curve = el.checked;
    else if (k === 'teams') { c.teams = el.checked; hostLobbyBroadcast(); render(); }
    else if (k === 'hostPlays') { c.hostPlays = el.checked; hostLobbyBroadcast(); render(); }
    else if (k === 'captains') { c.captains = el.checked; saveCfg(); hostLobbyBroadcast(); saveHost(true); render(); }
    else if (k === 'voice') { c.voice = el.checked; saveCfg(); hostLobbyBroadcast(); saveHost(true); window.FVOICE && FVOICE.sync(); render(); }
  });
  $app.addEventListener('submit', e => {
    e.preventDefault(); const f = e.target; const inp = f.querySelector('input'); const s = inp.value.trim(); if (!s) return;
    const as = f.dataset.as || (A.V && A.V.d.side) || undefined;
    if (f.dataset.f === 'near') { send({ type: 'answer', n: s, as }); inp.value = ''; SFX.click(); return; }
    send({ type: 'text', s, as }); inp.value = ''; inp.focus();
  });

  function validate() { const c = A.cfg; if (!c.modes.length) { toast('اختر نمطاً واحداً على الأقل'); return false; } if (!c.cats.length) { toast('اختر فئة واحدة على الأقل'); return false; } return true; }
  function saveCfg() { store.set('cfg', A.cfg); store.set('sides', A.sides); }
  function startLocal(sides, cfg) {
    saveCfg(); A.role = 'local'; A.V = null;
    const S = sides.map((s, i) => ({ id: 's' + i, name: s.name || ('فريق ' + (i + 1)), emoji: s.emoji, color: s.color || COL[i % COL.length] }));
    const P = {}; S.forEach(s => P['L' + s.id] = { id: 'L' + s.id, name: s.name, side: s.id });
    A.myPid = 'L' + S[0].id; A.scr = 'game';
    E.init(cfg, S, P, true, A.myPid);
  }
  function startHost() {
    const c = A.cfg; const pl = Object.values(A.lobby || {});
    let S = [], P = {};
    const all = pl.slice(); if (c.hostPlays) all.unshift({ id: 'host', name: A.me.name || 'المضيف', emoji: A.me.emoji, team: A.hostTeam || 0 });
    if (c.teams) {
      all.forEach(p => { if (p.team >= NT()) p.team = 0; });
      const tn = ['الفريق الأحمر', 'الفريق الأزرق', 'الفريق الذهبي', 'الفريق الأخضر'], te = ['♛', '♞', '♜', '♝'];
      [...new Set(all.map(p => p.team))].sort().forEach(t => S.push({ id: 't' + t, name: tn[t], emoji: te[t], color: COL[t] }));
      all.forEach(p => P[p.id] = { id: p.id, name: p.name, emoji: p.emoji, side: 't' + p.team });
      c.capPick = {}; for (const k in (A.capPick || {})) if (A.capPick[k]) c.capPick['t' + k] = A.capPick[k];
    } else { c.captains = c.captains && false; all.forEach((p, i) => { S.push({ id: 's' + p.id, name: p.name, emoji: p.emoji, color: COL[i % COL.length] }); P[p.id] = { id: p.id, name: p.name, emoji: p.emoji, side: 's' + p.id }; }); }
    if (!S.length) { toast('لا يوجد لاعبون'); return; }
    if (!c.hostPlays) P.host = { id: 'host', name: 'المضيف', side: null };
    A.myPid = 'host'; A.scr = 'game'; A.V = null;
    E.init(c, S, P, false, 'host');
    for (const uid in A.pres) E.setOnline(uid, A.pres[uid].on !== false);
  }
  function leave() {
    if (A.role === 'client' && A.C) try { A.C.send({ t: 'leave' }); } catch (e) { }
    clearSess(); keepAlive(false); A.joinSlow = null; A.rejoin = false;
    window.FVOICE && FVOICE.stop(); A.vpub = {}; A.voiceOn = false;
    E.stop(); if (A.H) { const h = A.H; try { h.bcast({ t: 'closed' }); } catch (e) { } setTimeout(() => h.close(), 400); A.H = null; } if (A.C) { A.C.close(); A.C = null; }
    A.V = null; A.lobby = null; A.localEnd = 0; A.link = null; A.lobbyGot = false; A.pres = {};
  }

  // زر الرجوع في أندرويد
  window.fahimBack = function () { if (document.querySelector('.scanov')) { document.querySelector('.scanov button').click(); return true; } if (document.querySelector('.modal')) { document.querySelector('.modal').remove(); return true; } if (A.scr === 'home') return false; if (A.scr === 'game' || A.scr === 'lobby' || A.scr === 'wait') { modal('الخروج من اللعبة؟', ['نعم، اخرج', 'إلغاء']).then(i => { if (i === 0) { leave(); go('home'); } }); return true; } go('home'); return true; };

  // تهيئة البنك: توليد ثم تطبيق المراجعة وإزالة المكرر، ثم أسئلة المستخدم
  if (QB.lateGen) QB.lateGen();
  if (QB.finalize) QB.finalize();
  QB.loadCustom(); QB.stats();
  if (!A.cfg.cats) A.cfg.cats = QB.order.slice();
  A.cfg.cats = A.cfg.cats.filter(c => QB.cats[c]);
  if (!A.cfg.cats.length) A.cfg.cats = QB.order.slice();
  render();
  // ---------- إعادة الاتصال التلقائي ----------
  // تُستدعى عند العودة للتطبيق، ورجوع الإنترنت، وتغيّر الشبكة (واي فاي ↔ بيانات)
  function revive(force) { window.FVOICE && FVOICE.revive(); if (A.C) A.C.kick(force); if (A.H) { A.H.kick(); if (E.G) E.push(); else hostLobbyBroadcast(); } if (A.scr === 'game' && A.V) render(); }
  window.fahimResume = () => revive(false);
  window.fahimNet = () => setTimeout(() => revive(true), 400);
  window.fahimPause = () => { saveHost(true); saveClient(true); };
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') revive(false); else window.fahimPause(); });
  window.addEventListener('online', () => window.fahimNet());
  window.addEventListener('focus', () => revive(false));
  window.addEventListener('pagehide', () => window.fahimPause());

  // رابط انضمام مباشر (fahim://join/1234 أو #join=1234)
  const hm = (location.hash || '').match(/join[=/](\d{4})/);
  if (hm) setTimeout(() => window.fahimDeepJoin(hm[1]), 300);
  else {
    // استئناف تلقائي إذا أُغلق التطبيق أو أعاد النظام تشغيله أثناء اللعب
    const cs = store.get('csess', null), hs = store.get('hsess', null), fresh = x => x && Date.now() - x.t < 3 * 3600e3;
    if (fresh(cs) && A.me.name) { A.role = 'client'; setTimeout(() => clientJoin(cs.pin, true), 200); }
    else if (fresh(hs)) {
      setTimeout(() => modal(`عندك غرفة مفتوحة برمز <b>${esc(hs.code)}</b>${hs.snap ? ' واللعبة كانت جارية (النقاط محفوظة)' : ''}. هل تريد استئنافها؟ اللاعبون سيعودون تلقائياً.`, ['استئناف الغرفة', 'إغلاقها']).then(i => {
        if (i !== 0) { clearSess(); return; }
        A.role = 'host'; if (hs.cfg) A.cfg = Object.assign(A.cfg, hs.cfg);
        A.code = hs.code; go('lobby'); hostOpen(hs.code, hs);
        if (hs.snap) { A.myPid = 'host'; A.scr = 'game'; A.V = null; E.restore(hs.snap); toast('استؤنفت اللعبة من بداية الفقرة الحالية'); }
      }), 300);
    }
  }
})();
