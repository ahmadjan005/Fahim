/* الغرفة الصوتية في فهيم — تعمل عبر خوادم الترحيل نفسها التي تشغّل اللعبة
   فلا تحتاج اتصالاً مباشراً بين الجوالات (الذي تمنعه كثير من شبكات البيانات).
   - الصوت يُضغط بترميز Opus (أو μ-law احتياطياً) ويُرسل كدفعات صغيرة كل ~200ms فقط أثناء الكلام.
   - نظام الفرق: كل فريق يسمع نفسه، والقائد يحوّل صوت فريقه "عاماً" فيسمعه الجميع.
   - بدون فرق: الجميع يسمع الجميع. */
(function () {
  const V = { rl: null, code: null, pid: null, info: null, micOn: false, mic: null, ac: null, src: null, proc: null, enc: null, encKind: null, seq: 0, pk: [], last: {}, peers: {}, spk: {}, vadT: 0, lvl: 0, ok: false, denied: false };
  const $ = s => document.querySelector(s);
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const TOPICS = ['t0', 't1', 't2', 't3', 'pub'];
  const top = k => FNET.NS + V.code + '/v/' + k;

  function ctx() {
    if (!V.ac) { try { const AC = window.AudioContext || window.webkitAudioContext; try { V.ac = new AC({ latencyHint: 'interactive', sampleRate: 48000 }); } catch (e) { V.ac = new AC(); } } catch (e) { } }
    if (V.ac && V.ac.state === 'suspended') V.ac.resume().catch(() => { });
    return V.ac;
  }
  // أي لمسة على الشاشة تفتح الصوت (سياسة التشغيل التلقائي)
  ['pointerdown', 'touchstart', 'keydown'].forEach(ev => document.addEventListener(ev, () => { if (V.code) ctx(); }, { passive: true }));

  // ---------- من يسمع من ----------
  const I = () => V.info || {};
  const teamOf = id => { const m = (I().members || []).find(x => x.id === id); return m ? m.team : null; };
  const pubT = t => t == null || !!(I().pub || {})[t];
  function myTopic() { const i = I(); if (!i.teams) return 'pub'; const t = teamOf(V.pid); return t == null || pubT(t) ? 'pub' : t; }
  function hearTopic(k) { const i = I(); if (!i.teams) return k === 'pub'; const t = teamOf(V.pid); return k === 'pub' || (t != null && k === t); }

  // ---------- base64 ----------
  function b64(u8) { let s = ''; for (let i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000)); return btoa(s); }
  function unb64(s) { const b = atob(s); const u = new Uint8Array(b.length); for (let i = 0; i < b.length; i++) u[i] = b.charCodeAt(i); return u; }
  // μ-law (احتياطي عند غياب Opus)
  function mulawEnc(x) { const s = x < 0 ? 0x80 : 0; let v = Math.min(32635, Math.abs(x) * 32767) + 132; let e = 7; for (let m = 0x4000; (v & m) === 0 && e > 0; m >>= 1) e--; const mant = (v >> (e + 3)) & 0x0f; return ~(s | (e << 4) | mant) & 0xff; }
  function mulawDec(u) { u = ~u & 0xff; const s = u & 0x80, e = (u >> 4) & 7, m = u & 0x0f; let v = ((m << 3) + 132) << e; v -= 132; return (s ? -v : v) / 32768; }

  // ---------- الإرسال ----------
  async function setupEncoder(rate) {
    V.encKind = 'u';
    if (window.AudioEncoder) {
      try {
        const cfg = { codec: 'opus', sampleRate: 48000, numberOfChannels: 1, bitrate: 24000 };
        const sup = await AudioEncoder.isConfigSupported(cfg);
        if (sup && sup.supported && rate === 48000) {
          V.enc = new AudioEncoder({ output: ch => { const u = new Uint8Array(ch.byteLength); ch.copyTo(u); V.pk.push(b64(u)); }, error: () => { V.enc = null; V.encKind = 'u'; } });
          V.enc.configure(cfg); V.encKind = 'o'; V.ts = 0;
        }
      } catch (e) { V.enc = null; V.encKind = 'u'; }
    }
  }
  function onAudio(buf, rate) {
    // مستوى الصوت للمؤشر وكشف الكلام
    let mx = 0; for (let i = 0; i < buf.length; i += 8) mx = Math.max(mx, Math.abs(buf[i]));
    V.lvl = mx; const t = performance.now();
    if (mx > 0.035) V.vadT = t + 450;
    const talking = V.micOn && t < V.vadT;
    setSpk(V.pid, talking);
    if (!talking) return;
    if (V.encKind === 'o' && V.enc && V.enc.state === 'configured') {
      try { const ad = new AudioData({ format: 'f32-planar', sampleRate: rate, numberOfFrames: buf.length, numberOfChannels: 1, timestamp: V.ts, data: buf }); V.ts += Math.round(buf.length / rate * 1e6); V.enc.encode(ad); ad.close(); } catch (e) { }
    } else {
      // تقليل العينة إلى 8000Hz ثم μ-law
      const ratio = rate / 8000, n = Math.floor(buf.length / ratio), u = new Uint8Array(n);
      for (let i = 0; i < n; i++) u[i] = mulawEnc(buf[Math.floor(i * ratio)]);
      V.pk.push(b64(u));
    }
  }
  function flush() {
    if (!V.pk.length || !V.rl) return;
    const p = V.pk; V.pk = [];
    V.rl.pub(top(myTopic()), { u: V.pid, q: ++V.seq, k: V.encKind, p });
  }
  setInterval(flush, 200);

  async function startMic() {
    const ac = ctx(); if (!ac) return false;
    try {
      const st = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true, channelCount: 1 } });
      V.mic = st; V.denied = false;
      await setupEncoder(ac.sampleRate);
      V.src = ac.createMediaStreamSource(st);
      V.proc = ac.createScriptProcessor(2048, 1, 1);
      V.proc.onaudioprocess = e => { const d = e.inputBuffer.getChannelData(0); onAudio(new Float32Array(d), ac.sampleRate); e.outputBuffer.getChannelData(0).fill(0); };
      const mute = ac.createGain(); mute.gain.value = 0;
      V.src.connect(V.proc); V.proc.connect(mute); mute.connect(ac.destination);
      try { if (window.FahimAndroid && FahimAndroid.mic) FahimAndroid.mic(true); } catch (e) { }
      return true;
    } catch (e) {
      V.denied = true; bar();
      window.fahimToast && fahimToast('لم يُسمح باستخدام المايكروفون. فعّل الإذن من إعدادات الجوال ← التطبيقات ← فهيم ← الأذونات', 5000);
      return false;
    }
  }
  function stopMic() {
    try { V.proc && V.proc.disconnect(); V.src && V.src.disconnect(); } catch (e) { }
    try { V.mic && V.mic.getTracks().forEach(t => t.stop()); } catch (e) { }
    try { V.enc && V.enc.state !== 'closed' && V.enc.close(); } catch (e) { }
    V.mic = V.proc = V.src = V.enc = null; V.micOn = false; V.pk = [];
  }
  async function micToggle() {
    ctx();
    if (V.micOn) { V.micOn = false; flush(); bar(); return; }
    if (!V.mic) { if (!(await startMic())) return; }
    V.micOn = true; bar();
  }

  // ---------- الاستقبال والتشغيل ----------
  function peer(u) {
    let p = V.peers[u]; if (p) return p;
    p = V.peers[u] = { next: 0, dec: null };
    if (window.AudioDecoder) {
      try {
        p.dec = new AudioDecoder({ output: ad => { try { const n = ad.numberOfFrames, f = new Float32Array(n); ad.copyTo(f, { planeIndex: 0, format: 'f32-planar' }); play(p, f, ad.sampleRate); } catch (e) { } ad.close(); }, error: () => { p.dec = null; } });
        p.dec.configure({ codec: 'opus', sampleRate: 48000, numberOfChannels: 1 }); p.ts = 0;
      } catch (e) { p.dec = null; }
    }
    return p;
  }
  function play(p, f, rate) {
    const ac = ctx(); if (!ac || !f.length) return;
    const b = ac.createBuffer(1, f.length, rate); b.getChannelData(0).set(f);
    const s = ac.createBufferSource(); s.buffer = b; s.connect(ac.destination);
    const now = ac.currentTime;
    if (p.next < now + 0.05 || p.next > now + 1.2) p.next = now + 0.25; // مخزن صغير ضد التقطّع
    s.start(p.next); p.next += b.duration;
  }
  function onMsg(topic, m) {
    if (!m || !m.u || m.u === V.pid || !Array.isArray(m.p)) return;
    // نفس الدفعة قد تصل من أكثر من خادم
    const k = topic.slice(topic.lastIndexOf('/') + 1);
    if (!hearTopic(k)) return;
    const l = V.last[m.u] || 0; if (m.q <= l && l - m.q < 3000) return; V.last[m.u] = m.q;
    const p = peer(m.u);
    setSpk(m.u, true); clearTimeout(p.st); p.st = setTimeout(() => setSpk(m.u, false), 600);
    if (m.k === 'o') {
      if (!p.dec || p.dec.state !== 'configured') return;
      m.p.forEach(s => { try { const u = unb64(s); p.dec.decode(new EncodedAudioChunk({ type: 'key', timestamp: p.ts, data: u })); p.ts += 20000; } catch (e) { } });
    } else m.p.forEach(s => { const u = unb64(s), f = new Float32Array(u.length); for (let i = 0; i < u.length; i++) f[i] = mulawDec(u[i]); play(p, f, 8000); });
  }

  // ---------- مؤشر من يتكلم ----------
  function setSpk(id, on) { if (!!V.spk[id] !== on) { V.spk[id] = on; bar(); } }

  // ---------- الاتصال بخوادم الترحيل ----------
  function start(code, pid) {
    stop(true);
    V.code = code; V.pid = pid; V.seq = Math.floor(Date.now() / 1000) % 100000; V.last = {}; V.peers = {};
    V.rl = FNET.relay(onMsg, st => { V.ok = V.rl ? V.rl.state === 'ok' : st === 'ok'; bar(); });
    TOPICS.forEach(k => V.rl.sub(top(k)));
  }
  function stop(keepMic) {
    if (V.rl) { try { V.rl.close(); } catch (e) { } } V.rl = null; V.ok = false;
    for (const u in V.peers) { const p = V.peers[u]; try { p.dec && p.dec.state !== 'closed' && p.dec.close(); } catch (e) { } }
    V.peers = {}; V.spk = {}; V.code = null; V.pid = null;
    if (!keepMic) stopMic();
  }

  // ---------- الشريط العائم ----------
  function bar() {
    let b = $('#vbar'); const i = I();
    if (!i.on || !V.rl) { if (b) b.remove(); return; }
    if (!b) { b = document.createElement('div'); b.id = 'vbar'; document.body.appendChild(b); b.addEventListener('click', onClick); }
    const IC = window.ICON || {};
    const myT = teamOf(V.pid); const pub = pubT(myT); const canToggle = i.teams && myT != null && i.canPub;
    const talkers = Object.keys(V.spk).filter(k => V.spk[k]).map(k => k === V.pid ? 'أنت' : ((i.members || []).find(m => m.id === k) || {}).name).filter(Boolean);
    const others = (i.members || []).filter(m => m.id !== V.pid && (!i.teams || m.team === myT || pubT(m.team))).length;
    b.className = V.micOn ? 'live' : '';
    b.innerHTML = `<button class="vmic ${V.micOn ? 'on' : ''}" data-v="mic" aria-label="المايك">${V.micOn ? (IC.mic || '🎙') : (IC.micoff || '🔇')}</button>
      <div class="vinfo"><b>${i.teams ? (myT == null ? 'تسمع الفرق المفتوحة' : pub ? 'صوت فريقك: عام' : 'صوت فريقك: خاص') : 'الغرفة الصوتية'}</b><small>${talkers.length ? '🔊 ' + esc(talkers.join('، ')) : !V.ok ? 'جارٍ الاتصال…' : V.micOn ? 'المايك مفتوح — تكلّم' : 'متصل · تسمع ' + others + ' — اضغط المايك لتتكلم'}</small></div>
      ${canToggle ? `<button class="vpub ${pub ? 'on' : ''}" data-v="pub">${pub ? (IC.globe || '🌐') + ' عام' : (IC.lock || '🔒') + ' خاص'}</button>` : ''}`;
  }
  function onClick(e) {
    const t = e.target.closest('[data-v]'); if (!t) return;
    if (t.dataset.v === 'mic') micToggle();
    else if (t.dataset.v === 'pub') { const myT = teamOf(V.pid); window.fahimVoicePub && fahimVoicePub(myT, !pubT(myT)); }
  }

  // ---------- مزامنة مع حالة الغرفة ----------
  function sync() {
    const i = window.fahimVoiceInfo ? window.fahimVoiceInfo() : null; V.info = i;
    if (!i || !i.on || !i.code || !i.me) { if (V.rl) stop(); bar(); return; }
    if (!V.rl || V.code !== i.code || V.pid !== i.me) start(i.code, i.me);
    bar();
  }
  window.FVOICE = { sync, stop: () => { stop(); bar(); }, revive: () => { if (V.rl) V.rl.kick(); ctx(); }, state: V };
})();
