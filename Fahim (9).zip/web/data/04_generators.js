// مولّدات لا نهائية: تُنتج سؤالاً جديداً في كل مرة
(function () {
  const R = QB.rnd, P = QB.pick;
  function wrongNums(a, spread) {
    const s = new Set(); let t = 0;
    while (s.size < 3 && t++ < 60) { const d = (R(2) ? 1 : -1) * (1 + R(spread)); const v = a + d; if (v !== a && v >= 0) s.add(v); }
    while (s.size < 3) s.add(a + s.size + 7);
    return [...s].map(String);
  }
  const G = QB.generators = {};
  // كل مولّد: (level) => {q, a, w}
  G.logic = [
    l => { // متتاليات حسابية/هندسية
      if (l <= 2) { const a = 1 + R(20), d = 2 + R(9); const seq = [0, 1, 2, 3].map(i => a + i * d); return { q: `ما العدد التالي: ${seq.join('، ')}، ...؟`, a: String(a + 4 * d), w: wrongNums(a + 4 * d, d) }; }
      if (l === 3) { const a = 1 + R(5), r = 2 + R(2); const seq = [0, 1, 2, 3].map(i => a * Math.pow(r, i)); return { q: `ما العدد التالي: ${seq.join('، ')}، ...؟`, a: String(a * Math.pow(r, 4)), w: wrongNums(a * Math.pow(r, 4), a * r * 2) }; }
      const a = 1 + R(6), d1 = 1 + R(4), inc = 1 + R(3); const seq = [a]; let d = d1; for (let i = 0; i < 4; i++) { seq.push(seq[seq.length - 1] + d); d += inc; }
      return { q: `ما العدد التالي: ${seq.join('، ')}، ...؟`, a: String(seq[4] + d), w: wrongNums(seq[4] + d, 4) };
    },
    l => { // أيام الأسبوع
      const days = ['السبت', 'الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة'];
      const i = R(7), n = l <= 2 ? 2 + R(12) : (l === 3 ? 20 + R(80) : 100 + R(900));
      const back = l >= 3 && R(2);
      const ans = days[((i + (back ? -n : n)) % 7 + 7) % 7];
      const w = QB.shuffle(days.filter(d => d !== ans)).slice(0, 3);
      return { q: `إذا كان اليوم ${days[i]}، فما اليوم ${back ? 'قبل' : 'بعد'} ${n} يوماً؟`, a: ans, w };
    },
    l => { // أعمار
      const s = 5 + R(10), f = s + 20 + R(15), k = 2 + R(8);
      if (l <= 2) return { q: `عمر سامي ${s} سنة، وأبوه أكبر منه بـ ${f - s} سنة. كم عمر الأب بعد ${k} سنوات؟`, a: String(f + k), w: wrongNums(f + k, 5) };
      const m = f - 2 * s; // بعد x سنة يصبح ضعف: f+x = 2(s+x) => x = f-2s
      if (m > 0) return { q: `عمر الأب ${f} وعمر ابنه ${s}. بعد كم سنة يصبح عمر الأب ضعف عمر ابنه؟`, a: String(m), w: wrongNums(m, 4) };
      return { q: `عمر الأب ${f} وعمر ابنه ${s}. ما مجموع عمريهما بعد ${k} سنوات؟`, a: String(f + s + 2 * k), w: wrongNums(f + s + 2 * k, 5) };
    }
  ];
  G.math = [
    l => { // تحويل وحدات
      const U = [
        ['كيلومتر', 'متر', 1000], ['متر', 'سنتيمتر', 100], ['ساعة', 'دقيقة', 60], ['دقيقة', 'ثانية', 60], ['يوم', 'ساعة', 24], ['كيلوغرام', 'غرام', 1000], ['لتر', 'مليلتر', 1000], ['أسبوع', 'يوم', 7], ['طن', 'كيلوغرام', 1000], ['قرن', 'سنة', 100]
      ];
      const [a, b, f] = P(U); const n = l <= 2 ? 1 + R(9) : (l === 3 ? 2 + R(25) : 0);
      if (l === 4) { const k = 3 + R(40); return { q: `كم ${a} في ${k * f} ${b}؟`, a: String(k), w: wrongNums(k, 5) }; }
      return { q: `كم ${b} في ${n} ${a}؟`, a: String(n * f), w: wrongNums(n * f, Math.max(5, f / 2 | 0)).map(String) };
    },
    l => { // الأرقام الرومانية
      const toR = n => { const m = [[1000, 'M'], [900, 'CM'], [500, 'D'], [400, 'CD'], [100, 'C'], [90, 'XC'], [50, 'L'], [40, 'XL'], [10, 'X'], [9, 'IX'], [5, 'V'], [4, 'IV'], [1, 'I']]; let r = ''; for (const [v, s] of m) while (n >= v) { r += s; n -= v; } return r; };
      const n = l <= 2 ? 1 + R(20) : (l === 3 ? 20 + R(180) : 200 + R(2800));
      if (R(2)) return { q: `ما قيمة العدد الروماني ${toR(n)}؟`, a: String(n), w: wrongNums(n, Math.max(3, n / 10 | 0)) };
      const w = wrongNums(n, Math.max(2, n / 10 | 0)).map(x => toR(+x));
      return { q: `كيف يُكتب العدد ${n} بالأرقام الرومانية؟`, a: toR(n), w };
    },
    l => { // الأعداد الأولية
      const isP = n => { if (n < 2) return false; for (let i = 2; i * i <= n; i++) if (n % i === 0) return false; return true; };
      const max = l <= 2 ? 30 : (l === 3 ? 100 : 300);
      let p; do { p = 2 + R(max); } while (!isP(p));
      const w = new Set(); while (w.size < 3) { const c = 4 + R(max); if (!isP(c)) w.add(String(c)); }
      return { q: 'أي هذه الأعداد عدد أولي؟', a: String(p), w: [...w] };
    },
    l => { // كسور ونسب
      const d = P([2, 4, 5, 10, 3]), n = 1 + R(d - 1 || 1); const total = d * (2 + R(l * 5));
      return { q: `كم يساوي ${n}/${d} من ${total}؟`, a: String(total * n / d), w: wrongNums(total * n / d, Math.max(3, total / d | 0)) };
    },
    l => { // مسائل كلامية
      const price = 2 + R(15), qty = 2 + R(l * 4 + 3), paid = Math.ceil(price * qty / 10) * 10 + (l > 2 ? 10 : 0);
      return { q: `اشترت ليلى ${qty} دفاتر سعر الواحد ${price} شيكل، ودفعت ${paid}. كم الباقي؟`, a: String(paid - price * qty), w: wrongNums(paid - price * qty, 6) };
    }
  ];
  G.islam = [
    l => {
      const H = ['محرم', 'صفر', 'ربيع الأول', 'ربيع الآخر', 'جمادى الأولى', 'جمادى الآخرة', 'رجب', 'شعبان', 'رمضان', 'شوال', 'ذو القعدة', 'ذو الحجة'];
      const i = R(12); const k = l <= 2 ? 1 : (l === 3 ? 2 + R(3) : 5 + R(6)); const ans = H[(i + k) % 12];
      const j = (i + k) % 12; return { q: k === 1 ? `ما الشهر الهجري الذي يأتي بعد ${H[i]}؟` : `ما الشهر الهجري الذي يأتي بعد ${H[i]} بـ ${k} أشهر؟`, a: ans, w: [H[(j + 1) % 12], H[(j + 11) % 12], H[(j + 2) % 12]] };
    }
  ];
  G.general = [
    l => {
      const S = ['كانون الثاني', 'شباط', 'آذار', 'نيسان', 'أيار', 'حزيران', 'تموز', 'آب', 'أيلول', 'تشرين الأول', 'تشرين الثاني', 'كانون الأول'];
      const E = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];
      const i = R(12);
      if (l <= 2) return R(2) ? { q: `شهر ${S[i]} يقابله أي شهر بالتسمية الأخرى؟`, a: E[i], w: QB.shuffle(E.filter((_, j) => j !== i)).slice(0, 3) } : { q: `شهر ${E[i]} يقابله أي شهر بالتسمية السريانية (الشامية)؟`, a: S[i], w: QB.shuffle(S.filter((_, j) => j !== i)).slice(0, 3) };
      return { q: `ما رقم شهر ${S[i]} في السنة الميلادية؟`, a: String(i + 1), w: wrongNums(i + 1, 3).filter(x => +x >= 1 && +x <= 12).concat(['13', '14', '15']).slice(0, 3) };
    }
  ];
  G.english = [
    l => {
      const N = { 1: 'one', 2: 'two', 3: 'three', 4: 'four', 5: 'five', 6: 'six', 7: 'seven', 8: 'eight', 9: 'nine', 10: 'ten', 11: 'eleven', 12: 'twelve', 13: 'thirteen', 14: 'fourteen', 15: 'fifteen', 16: 'sixteen', 17: 'seventeen', 18: 'eighteen', 19: 'nineteen', 20: 'twenty', 30: 'thirty', 40: 'forty', 50: 'fifty', 60: 'sixty', 70: 'seventy', 80: 'eighty', 90: 'ninety' };
      const word = n => n <= 20 || n % 10 === 0 ? N[n] : N[n - n % 10] + '-' + N[n % 10];
      const n = l <= 1 ? 1 + R(12) : (l === 2 ? 13 + R(20) : 21 + R(78));
      const w = new Set(); while (w.size < 3) { const m = Math.max(1, n + (R(2) ? 1 : -1) * (1 + R(9))); if (m !== n && m < 100) w.add(word(m)); }
      return { q: `How do you write ${n} in words?`, a: word(n), w: [...w] };
    }
  ];
  // تسجيل المولدات في البنك: كل استدعاء ينتج سؤالاً فريداً
  QB.genQ = function (cat, l) {
    const arr = G[cat]; if (!arr) return null;
    const g = P(arr)(l);
    return { id: 'g' + cat + g.q, c: cat, l, q: g.q, a: String(g.a), w: g.w.map(String), gen: 1 };
  };
})();

// ===== مولّدات المقارنة و"الدخيل" (تعمل بعد تحميل كل البيانات) =====
QB.lateGen = function () {
  const G = QB.generators, R = QB.rnd, P = QB.pick, SH = QB.shuffle;
  const CMP = {
    'رتّب الأحداث زمنياً (الأقدم أولاً)': ['history', 'أي هذه الأحداث وقع أولاً (الأقدم)؟', 'أي هذه الأحداث هو الأحدث؟'],
    'رتّب السور حسب ترتيبها في المصحف (الأقدم أولاً)': ['quran', 'أي هذه السور تأتي أولاً في ترتيب المصحف؟', 'أي هذه السور تأتي أخيراً في ترتيب المصحف؟'],
    'رتّب السور حسب عدد آياتها (الأقل أولاً)': ['quran', 'أي هذه السور أقل آياتٍ؟', 'أي هذه السور أكثر آياتٍ؟'],
    'رتّب العناصر حسب العدد الذري (الأصغر أولاً)': ['chem', 'أي هذه العناصر عدده الذري أصغر؟', 'أي هذه العناصر عدده الذري أكبر؟'],
    'رتّب الأفلام حسب سنة الصدور (الأقدم أولاً)': ['cinema_world', 'أي هذه الأفلام صدر أولاً؟', 'أي هذه الأفلام هو الأحدث؟'],
    'رتّب حسب سنة التأسيس/الإطلاق (الأقدم أولاً)': ['tech', 'أي هذه الشركات/المنصات تأسست أولاً؟', 'أي هذه الشركات/المنصات هي الأحدث تأسيساً؟'],
    'رتّب الدول حسب المساحة (الأصغر أولاً)': ['geo', 'أي هذه الدول هي الأصغر مساحة؟', 'أي هذه الدول هي الأكبر مساحة؟'],
    'رتّب الأنهار حسب الطول (الأقصر أولاً)': ['geo', 'أي هذه الأنهار هو الأقصر؟', 'أي هذه الأنهار هو الأطول؟'],
    'رتّب الجبال حسب الارتفاع (الأقل أولاً)': ['geo', 'أي هذه الجبال هو الأقل ارتفاعاً؟', 'أي هذه الجبال هو الأعلى؟'],
    'رتّب الكواكب حسب بعدها عن الشمس (الأقرب أولاً)': ['space', 'أي هذه الكواكب هو الأقرب إلى الشمس؟', 'أي هذه الكواكب هو الأبعد عن الشمس؟'],
    'رتّب الكواكب حسب حجمها (الأصغر أولاً)': ['space', 'أي هذه الكواكب هو الأصغر حجماً؟', 'أي هذه الكواكب هو الأكبر حجماً؟'],
    'رتّب الدول/الخلافات زمنياً (الأقدم أولاً)': ['arabhistory', 'أي هذه الدول قامت أولاً؟', 'أي هذه الدول هي الأحدث قياماً؟'],
    'رتّب الأنبياء زمنياً (الأقدم أولاً)': ['seerah', 'أي هؤلاء الأنبياء هو الأقدم زمناً؟', 'أي هؤلاء الأنبياء هو الأحدث زمناً؟'],
    'رتّب الحيوانات حسب الحجم/الوزن (الأخف أولاً)': ['animals', 'أي هذه الحيوانات هو الأخف وزناً؟', 'أي هذه الحيوانات هو الأثقل وزناً؟']
  };
  QB.orderPools.forEach(p => {
    const m = CMP[p.q]; if (!m) return;
    (G[m[0]] = G[m[0]] || []).push(l => {
      // عناصر متقاربة القيمة لتكون محيرة: كلما زاد المستوى ضاقت النافذة
      const sorted = p.items.slice().sort((a, b) => a.v - b.v);
      const win = Math.max(5, Math.round(sorted.length * [0, 1, .45, .25, .14][Math.min(4, Math.max(1, l))]));
      const st = R(Math.max(1, sorted.length - win + 1)); const pool = sorted.slice(st, st + win);
      let items = []; let t = 0; while (items.length < 4 && t++ < 80) { const it = P(pool.length >= 4 ? pool : sorted); if (!items.some(x => x.k === it.k || x.v === it.v)) items.push(it); }
      const max = R(2) === 1; const best = items.slice().sort((a, b) => max ? b.v - a.v : a.v - b.v)[0];
      const names = QB.shuffle(items.map(x => x.k));
      const base = (max ? m[2] : m[1]).replace(/؟$/, '');
      return { q: `${base}: ${names.slice(0, 3).join('، ')} أم ${names[3]}؟`, a: best.k, w: items.filter(x => x !== best).map(x => x.k) };
    });
  });
};
