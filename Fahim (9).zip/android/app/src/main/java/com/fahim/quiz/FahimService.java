package com.fahim.quiz;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

/**
 * خدمة أمامية خفيفة تعمل فقط أثناء وجودك في غرفة لعب.
 * تمنع النظام من تجميد التطبيق أو قطع الإنترنت عنه عندما تخرج لتطبيق آخر أو تطفئ الشاشة،
 * فيبقى الاتصال بالغرفة حياً وتعود للعبة فوراً.
 */
public class FahimService extends Service {
    static final String CH = "fahim_room";
    static final int ID = 7101;
    private PowerManager.WakeLock wake;
    private WifiManager.WifiLock wifi;

    static void start(Context c, String text) {
        try {
            Intent i = new Intent(c, FahimService.class);
            i.putExtra("text", text);
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i); else c.startService(i);
        } catch (Throwable t) { /* إن رفض النظام نكمل بدونها */ }
    }

    static void stop(Context c) {
        try { c.stopService(new Intent(c, FahimService.class)); } catch (Throwable t) { }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String text = intent != null ? intent.getStringExtra("text") : null;
        if (text == null || text.length() == 0) text = "أنت في غرفة لعب — الاتصال محفوظ";
        try {
            Notification n = build(text);
            if (Build.VERSION.SDK_INT >= 29) {
                int type = ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC;
                // نضيف نوع الميكروفون فقط إذا كان الإذن ممنوحاً (وإلا يرفض النظام)
                if (Build.VERSION.SDK_INT >= 30 && checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED)
                    type |= ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE;
                try { startForeground(ID, n, type); }
                catch (Throwable e) { startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC); }
            } else startForeground(ID, n);
        } catch (Throwable t) { stopSelf(); return START_NOT_STICKY; }
        try {
            if (wake == null) {
                PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
                wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "fahim:room");
                wake.setReferenceCounted(false);
                wake.acquire(4 * 60 * 60 * 1000L);
            }
            if (wifi == null) {
                WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                if (wm != null) {
                    wifi = wm.createWifiLock(Build.VERSION.SDK_INT >= 29 ? WifiManager.WIFI_MODE_FULL_LOW_LATENCY : WifiManager.WIFI_MODE_FULL_HIGH_PERF, "fahim:wifi");
                    wifi.setReferenceCounted(false);
                    wifi.acquire();
                }
            }
        } catch (Throwable t) { }
        return START_NOT_STICKY;
    }

    private Notification build(String text) {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26 && nm != null && nm.getNotificationChannel(CH) == null) {
            NotificationChannel ch = new NotificationChannel(CH, "غرفة اللعب", NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("يبقي الاتصال بالغرفة حياً أثناء الخروج من التطبيق");
            ch.setShowBadge(false);
            nm.createNotificationChannel(ch);
        }
        Intent open = new Intent(this, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        int pf = Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT : PendingIntent.FLAG_UPDATE_CURRENT;
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, pf);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CH) : new Notification.Builder(this);
        b.setContentTitle("فهيم").setContentText(text).setSmallIcon(R.drawable.ic_stat_fahim)
                .setContentIntent(pi).setOngoing(true).setShowWhen(false);
        if (Build.VERSION.SDK_INT >= 31) b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE);
        return b.build();
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) { stopSelf(); }

    @Override
    public void onDestroy() {
        try { if (wake != null && wake.isHeld()) wake.release(); } catch (Throwable t) { }
        try { if (wifi != null && wifi.isHeld()) wifi.release(); } catch (Throwable t) { }
        wake = null; wifi = null;
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
