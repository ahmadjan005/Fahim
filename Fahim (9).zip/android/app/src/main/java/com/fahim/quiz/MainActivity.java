package com.fahim.quiz;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.Context;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.webkit.WebViewAssetLoader;

public class MainActivity extends Activity {
    private static final String HOME = "https://appassets.androidplatform.net/assets/www/index.html";
    private static final int REQ_CAM = 41;
    private WebView web;
    private PermissionRequest pendingPerm;
    private ConnectivityManager.NetworkCallback netCb;
    private boolean askedNotif = false;
    private boolean keeping = false;
    private String lastText = "";

    /** جسر صغير تستدعيه اللعبة: تشغيل/إيقاف خدمة إبقاء الاتصال أثناء وجودك في غرفة */
    public class Bridge {
        @JavascriptInterface
        public void keep(final boolean on, final String text) {
            runOnUiThread(() -> {
                keeping = on;
                if (on) {
                    if (Build.VERSION.SDK_INT >= 33 && !askedNotif && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
                        askedNotif = true;
                        try { requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 42); } catch (Throwable t) { }
                    }
                    FahimService.start(MainActivity.this, text);
                } else FahimService.stop(MainActivity.this);
                lastText = text;
            });
        }

        /** مشاركة نص (نتيجة، دعوة) عبر قائمة المشاركة في الجوال: واتساب وغيره */
        @JavascriptInterface
        public void share(final String text) {
            runOnUiThread(() -> {
                try {
                    Intent i = new Intent(Intent.ACTION_SEND);
                    i.setType("text/plain");
                    i.putExtra(Intent.EXTRA_TEXT, text);
                    startActivity(Intent.createChooser(i, "مشاركة"));
                } catch (Throwable t) { }
            });
        }

        /** بعد السماح بالمايك: نعيد تشغيل الخدمة لتشمل الميكروفون فيبقى الصوت شغالاً في الخلفية */
        @JavascriptInterface
        public void mic(final boolean on) {
            runOnUiThread(() -> { if (keeping) FahimService.start(MainActivity.this, lastText); });
        }
    }

    private void js(final String code) {
        if (web == null) return;
        web.post(() -> { try { web.evaluateJavascript(code, null); } catch (Throwable t) { } });
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        web = new WebView(this);
        web.setBackgroundColor(0xFF0B0F1A);
        setContentView(web);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setTextZoom(100);
        web.addJavascriptInterface(new Bridge(), "FahimAndroid");
        // لا نسمح للنظام بخفض أولوية محرك الصفحة عندما يكون التطبيق في الخلفية
        if (Build.VERSION.SDK_INT >= 26) { try { web.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false); } catch (Throwable t) { } }
        // عند رجوع الإنترنت أو التبديل بين الواي فاي والبيانات: إعادة اتصال فورية
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            netCb = new ConnectivityManager.NetworkCallback() {
                @Override public void onAvailable(Network network) { js("window.fahimNet && window.fahimNet()"); }
                @Override public void onLost(Network network) { js("window.fahimNet && window.fahimNet()"); }
            };
            if (cm != null) cm.registerDefaultNetworkCallback(netCb);
        } catch (Throwable t) { netCb = null; }

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                java.util.ArrayList<String> need = new java.util.ArrayList<>();
                for (String r : request.getResources()) {
                    if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r) && Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.CAMERA);
                    if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r) && Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.RECORD_AUDIO);
                }
                if (!need.isEmpty()) {
                    pendingPerm = request;
                    requestPermissions(need.toArray(new String[0]), REQ_CAM);
                } else request.grant(request.getResources());
            }
        });
        if (savedInstanceState != null) web.restoreState(savedInstanceState);
        else web.loadUrl(HOME + joinHash(getIntent()));
    }

    private String joinHash(Intent it) {
        if (it == null) return "";
        Uri u = it.getData();
        if (u == null || !"fahim".equals(u.getScheme())) return "";
        String pin = u.getLastPathSegment();
        if (pin == null || !pin.matches("\\d{4}")) return "";
        return "#join=" + pin;
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        String h = joinHash(intent);
        if (h.length() > 0) web.evaluateJavascript("window.fahimDeepJoin && window.fahimDeepJoin('" + h.substring(6) + "')", null);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == REQ_CAM && pendingPerm != null) {
            boolean all = grantResults.length > 0;
            for (int g : grantResults) if (g != PackageManager.PERMISSION_GRANTED) all = false;
            if (all) pendingPerm.grant(pendingPerm.getResources());
            else pendingPerm.deny();
            pendingPerm = null;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        js("window.fahimResume && window.fahimResume()");
    }

    @Override
    protected void onPause() {
        // لا نوقف محرك الصفحة: اللعبة والاتصال يستمران أثناء وجودك في تطبيق آخر
        super.onPause();
        js("window.fahimPause && window.fahimPause()");
    }

    @Override
    protected void onDestroy() {
        try {
            if (netCb != null) ((ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE)).unregisterNetworkCallback(netCb);
        } catch (Throwable t) { }
        FahimService.stop(this);
        if (web != null) { try { web.destroy(); } catch (Throwable t) { } }
        super.onDestroy();
    }

    @Override
    protected void onSaveInstanceState(Bundle out) { super.onSaveInstanceState(out); web.saveState(out); }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("(window.fahimBack ? window.fahimBack() : false)", value -> {
            if (!"true".equals(value)) MainActivity.super.onBackPressed();
        });
    }
}
