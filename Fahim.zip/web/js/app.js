/* واجهة فهيم + الشبكة */
(function () {
  const $app = document.getElementById('app');
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const EMO = window.GLYPHS;
  const COL = ['#b4373f', '#2f62b8', '#c69c2d', '#2f8a5e', '#7c4dbe', '#1f8fa3', '#b8467a', '#c06a2b'];
  const SHAPES = ['أ', 'ب', 'ج', 'د'];
  const store = { get(k, d) { try { const v = localStorage.getItem('fahim_' + k); return v ? JSON.parse(v) : d; } catch (e) { return d; } }, set(k, v) { try { localStorage.setItem('fahim_' + k, JSON.stringify(v)); } catch (e) { } } };

  const A = {
    scr: 'home', role: null, myPid: null, V: null, prev: null, lobby: null, code: null,
    cfg: Object.assign({ modes: ['board', 'kahoot', 'buzzer', 'know', 'auction', 'who', 'final'], cats: null, levels: [1, 2, 3, 4], timer: 20, n: 8, style: 'mcq', curve: true, knowTime: 30, knowTurns: 1, whoStep: 10, lives: 2, copies: 1, teams: false, hostPlays: true }, store.get('cfg', {})),
    sides: store.get('sides', [{ name: 'الفريق الأول', emoji: '♛', color: COL[0] }, { name: 'الفريق الثاني', emoji: '♞', color: COL[1] }]),
    me: store.get('me', { name: '', emoji: EMO[QB.rnd(EMO.length)] }),
    sel: {}, ord: [], typed: '', localEnd: 0
  };
  A.sides.forEach((s, i) => { if (!EMO.includes(s.emoji)) s.emoji = EMO[i % EMO.length]; if (!COL.includes(s.color)) s.color = COL[i % COL.length]; });
  if (!EMO.includes(A.me.emoji)) A.me.emoji = EMO[0];
  if (!A.cfg.cats) A.cfg.cats = QB.order.slice();
  A.cfg.cats = A.cfg.cats.filter(c => QB.cats[c]);
  if (!A.cfg.cats.length) A.cfg.cats = QB.order.slice();

  function modal(text, btns) {
    return new Promise(res => {
      const m = document.createElement('div'); m.className = 'modal';
      m.innerHTML = `<div class="mbox"><p>${text}</p><div class="mbtns">${btns.map((b, i) => `<button class="btn ${i === 0 ? 'gold' : ''}" data-i="${i}">${b}</button>`).join('')}</div></div>`;
      m.addEventListener('click', e => { const b = e.target.closest('[data-i]'); if (b) { m.remove(); res(+b.dataset.i); } else if (e.target === m) { m.remove(); res(-1); } });
      document.body.appendChild(m);
    });
  }
  function toast(t, ms) { const d = document.createElement('div'); d.className = 'toast'; d.textContent = t; document.body.appendChild(d); setTimeout(() => d.remove(), ms || 2500); }
  window.toast = toast;
  function go(s) { A.scr = s; render(); window.scrollTo(0, 0); }

  // ---------- الشبكة ----------
  const NET = {
    peer: null, conns: {}, conn: null,
    host(cb) {
      const code = String(1000 + QB.rnd(9000));
      try { NET.peer = new Peer('fahim-' + code, { debug: 0 }); } catch (e) { toast('تعذّر تشغيل الشبكة'); return; }
      NET.peer.on('open', () => cb(code));
      NET.peer.on('error', e => { if (e.type === 'unavailable-id') { NET.peer.destroy(); NET.host(cb); } else if (e.type === 'network' || e.type === 'server-error' || e.type === 'socket-error') toast('تحقق من اتصال الإنترنت'); else if (e.type !== 'peer-unavailable') toast('خطأ في الشبكة: ' + e.type); });
      NET.peer.on('connection', c => {
        c.on('data', m => onHostMsg(c, m));
        c.on('close', () => { delete NET.conns[c.peer]; if (A.lobby && A.lobby[c.peer] && !E.G) { delete A.lobby[c.peer]; hostLobbyBroadcast(); render(); } });
      });
    },
    join(code, cb) {
      try { NET.peer = new Peer({ debug: 0 }); } catch (e) { toast('تعذّر تشغيل الشبكة'); return; }
      NET.peer.on('open', () => {
        const c = NET.peer.connect('fahim-' + code, { reliable: true }); NET.conn = c;
        const to = setTimeout(() => { if (!c.open) { toast('لم يتم العثور على الغرفة، تأكد من الرمز'); go('join'); } }, 9000);
        c.on('open', () => { clearTimeout(to); c.send({ t: 'join', name: A.me.name, emoji: A.me.emoji }); cb && cb(); });
        c.on('data', onClientMsg);
        c.on('close', () => { toast('انقطع الاتصال بالمضيف'); });
      });
      NET.peer.on('error', e => { if (e.type === 'peer-unavailable') { toast('الغرفة غير موجودة. تأكد من الرمز'); go('join'); } else toast('خطأ في الاتصال: ' + e.type); });
    },
    bcast(m) { for (const k in NET.conns) { const c = NET.conns[k]; if (c.open) try { c.send(m); } catch (e) { } } },
    close() { try { NET.peer && NET.peer.destroy(); } catch (e) { } NET.peer = null; NET.conns = {}; NET.conn = null; }
  };
  function onHostMsg(c, m) {
    if (m.t === 'join') {
      NET.conns[c.peer] = c;
      const pid = c.peer;
      c.send({ t: 'hello', pid, code: A.code });
      if (E.G) { // انضمام أثناء اللعب
        const sid = 's' + pid;
        E.addPlayer(pid, { id: pid, name: m.name, emoji: m.emoji, side: sid }, { id: sid, name: m.name, emoji: m.emoji, color: COL[E.G.sides.length % COL.length] });
      } else { A.lobby[pid] = { id: pid, name: m.name || 'لاعب', emoji: m.emoji || '🙂', team: 0 }; hostLobbyBroadcast(); render(); SFX.coin(); }
    } else if (m.t === 'act') { E.act(c.peer, m.a); }
  }
  function hostLobbyBroadcast() { NET.bcast({ t: 'lobby', players: A.lobby, code: A.code, teams: A.cfg.teams }); }
  function onClientMsg(m) {
    if (m.t === 'hello') { A.myPid = m.pid; A.code = m.code; }
    else if (m.t === 'lobby') { A.lobby = m.players; A.lobbyTeams = m.teams; if (A.scr !== 'wait') go('wait'); else render(); }
    else if (m.t === 'state') { onState(m.s); }
  }
  function send(a) {
    if (A.role === 'client') { NET.conn && NET.conn.open && NET.conn.send({ t: 'act', a }); }
    else E.act(A.myPid, a);
  }

  // ---------- استقبال الحالة ----------
  E.onState = function (v) {
    if (A.role === 'host') NET.bcast({ t: 'state', s: v });
    onState(v);
  };
  function onState(v) {
    const p = A.V; A.prev = p; A.V = v;
    A.localEnd = v.t ? Date.now() + v.t : 0;
    if (A.scr !== 'game') A.scr = 'game';
    // أصوات حسب التغيير
    const phChanged = !p || p.ph !== v.ph || p.mode !== v.mode;
    if (phChanged) {
      A.sel = {}; A.ord = [];
      if (v.ph === 'banner') SFX.start();
      else if (v.ph === 'q' || v.ph === 'buzzq' || v.ph === 'who' || v.ph === 'pick' || v.ph === 'open') SFX.whoosh();
      else if (v.ph === 'reveal') {
        const mine = (v.d.res || []).filter(r => isMine(r.s));
        if (mine.length) (mine.some(r => r.ok) ? SFX.ok : SFX.bad)(); else SFX.reveal();
      } else if (v.ph === 'podium') { SFX.win(); setTimeout(confetti, 300); }
      else if (v.ph === 'kres') { (v.d.auctionOk === false ? SFX.bad : SFX.reveal)(); }
    } else if (p && v.d && p.d) {
      if (v.d.fx !== p.d.fx) { if (v.d.flash === 'ok') SFX.coin(); else if (v.d.flash) SFX.bad(); if (v.d.wrong && (!p.d.wrong || p.d.wrong !== v.d.wrong)) SFX.bad(); }
      if (v.d.buzzer && v.d.buzzer !== p.d.buzzer) SFX.buzz();
      if ((v.d.done || []).length > (p.d.done || []).length) SFX.click();
      if ((v.d.clues || []).length > (p.d.clues || []).length) SFX.reveal();
    }
    if (v.ph === 'q' && p && p.ph === 'buzzq' && v.mode === 'buzzer') SFX.buzz();
    render();
  }
  function isMine(sid) { const V = A.V; if (!V) return false; if (V.local) return true; const pl = V.players[A.myPid]; return pl && pl.side === sid; }
  function mySide() { const V = A.V; if (!V || V.local) return null; const pl = V.players[A.myPid]; return pl ? pl.side : null; }
  function isHost() { return A.role === 'host' || A.role === 'local'; }
  function canAct(sid) { const V = A.V; if (V.local) return true; return mySide() === sid; }
  const sideById = id => (A.V.sides.find(s => s.id === id) || { name: '?', emoji: '❔', color: '#555' });

  // مؤقت محلي
  setInterval(() => {
    const el = document.getElementById('tnum'); const bar = document.getElementById('tbar');
    if (!el || !A.localEnd) return;
    const rem = Math.max(0, A.localEnd - Date.now()); const s = Math.ceil(rem / 1000);
    if (el.textContent !== String(s)) { el.textContent = s; if (s <= 5 && s > 0) { el.classList.add('hurry'); SFX.tick(); } }
    if (bar && A.V && A.V.tot) bar.style.transform = `scaleX(${rem / A.V.tot})`;
  }, 200);

  // ---------- مكونات ----------
  const owl = (w) => `<div class="emblem" style="width:${w}px;height:${w}px">${OWL}</div>`;
  const av = (g, c) => `<span class="av" ${c ? `style="border-color:${c}55"` : ''}>${esc(g)}</span>`;
  function top(t, back) { return `<div class="topbar">${back !== false ? `<button class="iconbtn" data-a="back">${ICON.back}</button>` : ''}<div class="t">${t}</div><div class="mini">${OWL}</div></div>`; }
  function scoreboard(active) {
    const V = A.V; const act = [].concat(active || []);
    return `<div class="sb">${V.sides.map(s => `<div class="sbi ${act.includes(s.id) ? 'act' : ''}" style="--c:${s.color}"><div class="g">${esc(s.emoji)}</div><div class="nm">${esc(s.name)}</div><div class="sc">${s.score}</div></div>`).join('')}</div>`;
  }
  function timerUI() { if (!A.localEnd) return ''; const rem = Math.max(0, A.localEnd - Date.now()); return `<div class="row" style="margin:8px 0"><div class="tnum" id="tnum">${Math.ceil(rem / 1000)}</div><div class="timer grow"><i id="tbar" style="transform:scaleX(${A.V.tot ? rem / A.V.tot : 1})"></i></div></div>`; }
  function qhead(d) { const c = QB.cats[d.c]; return `<div class="qhead"><span>${esc(d.title || '')}</span><span>${c ? '<span class="ce" style="filter:grayscale(1) brightness(1.4);opacity:.7">' + c.icon + '</span> ' + c.name : ''} ${d.l ? `<span class="lvl l${d.l}">${LVL[d.l]}</span>` : ''}</span></div>`; }
  function hostBar(label) { if (!isHost() || !A.V) return ''; return `<div class="foot"><div class="in"><button class="btn gold grow" data-a="next">${label || 'التالي'}</button><button class="btn" data-a="menu">${ICON.menu}</button></div></div>`; }
  function nextBtn() { return isHost() && A.V && A.V.ph !== 'podium' ? hostBar() : ''; }

  // ---------- الشاشات ----------
  const SCR = {};
  SCR.home = () => {
    const item = (a, ic, t, sub, cls) => `<button class="mbtn ${cls || ''}" data-a="${a}"><span class="ic">${ICON[ic]}</span><span>${t}<small>${sub}</small></span><span class="chev">${ICON.back}</span></button>`;
    return `<div class="hero">${owl(132)}<h1 class="title">فهيم</h1><div class="tag">مسابقات ثقافية لمن يعرف أكثر</div><div class="orn">✦</div></div>
  <div class="menu">
    ${item('local', 'users', 'لعب على جهاز واحد', 'فرق تتنافس وتتناوب على الجهاز نفسه', 'main')}
    ${item('host', 'host', 'إنشاء غرفة', 'كل لاعب يجاوب من جواله برمز دخول', '')}
    ${item('join', 'join', 'الانضمام إلى غرفة', 'أدخل رمز الغرفة المكوّن من أربعة أرقام', '')}
    ${item('practice', 'practice', 'تدريب فردي', 'اختبر معلوماتك بمفردك', '')}
    <div class="row">${item('bank', 'bank', 'بنك الأسئلة', 'الفئات وإضافة أسئلتك', 'grow')}</div>
  </div>
  <div class="foot-links"><button class="btn sm" data-a="help">${ICON.help} طريقة اللعب</button><button class="btn sm" data-a="sound">${SFX.on ? ICON.sound + ' الصوت' : ICON.mute + ' صامت'}</button></div>`;
  };

  SCR.setup = () => {
    const c = A.cfg; const local = A.role === 'local';
    let h = top(local ? 'إعداد اللعبة' : 'إعداد الغرفة');
    if (local) {
      h += `<div class="card"><h3>${ICON.users.replace('<svg', '<svg width="20" height="20"')} الفرق واللاعبون</h3><div class="sides">${A.sides.map((s, i) => `
        <div class="side" style="border-top-color:${s.color}"><button class="x" data-a="delside" data-i="${i}">${ICON.close}</button>
        <button data-a="emo" data-i="${i}">${av(s.emoji, s.color)}</button><input data-in="sname" data-i="${i}" value="${esc(s.name)}" maxlength="20">
        ${A.emoPick === i ? `<div class="emojis">${EMO.map(e => `<span class="${s.emoji === e ? 'on' : ''}" data-a="setemo" data-i="${i}" data-e="${e}">${e}</span>`).join('')}</div>` : ''}</div>`).join('')}
        ${A.sides.length < 8 ? `<button class="side add" data-a="addside">${ICON.plus}</button>` : ''}</div></div>`;
    }
    h += `<div class="card"><h3>أنماط اللعب</h3><div class="hint">كل نمط تختاره يُلعب كجولة، والنقاط تتراكم حتى منصة التتويج</div><div class="modes" style="margin-top:12px">${Object.keys(MODES).map(k => `<button class="mode ${c.modes.includes(k) ? 'on' : ''}" data-a="mode" data-k="${k}"><span class="mi">${ICON[k]}</span><span><b>${MODES[k].name}</b><p>${MODES[k].d}</p></span></button>`).join('')}</div>
      <div class="row" style="margin-top:10px"><button class="btn sm" data-a="preset" data-p="seen">سهرة سين جيم</button><button class="btn sm" data-a="preset" data-p="t30">تحدي الثلاثين</button><button class="btn sm" data-a="preset" data-p="kahoot">كاهوت</button><button class="btn sm" data-a="preset" data-p="all">الكل</button></div></div>`;
    h += catPicker();
    h += `<div class="card"><h3>الصعوبة والوقت</h3>
      <label class="lab">مستويات الصعوبة</label><div class="chips">${[1, 2, 3, 4].map(l => `<button class="chip ${c.levels.includes(l) ? 'on' : ''}" data-a="lvl" data-l="${l}"><span class="lvl l${l}">${LVL[l]}</span></button>`).join('')}</div>
      <div class="row" style="margin-top:8px"><button class="btn sm" data-a="lvlp" data-p="mix">متدرّج 20/60/20</button><button class="btn sm" data-a="lvlp" data-p="easy">للمبتدئين</button><button class="btn sm" data-a="lvlp" data-p="pro">للفاهمين والمتمكنين</button></div>
      <label class="lab"><input type="checkbox" data-in="curve" ${c.curve ? 'checked' : ''} style="width:auto"> تصاعد الصعوبة داخل الجولة (من السهل إلى الصعب)</label>
      <label class="lab">وقت الإجابة على السؤال</label><div class="range"><input type="range" min="5" max="90" step="5" value="${c.timer}" data-in="timer"><b>${c.timer} ث</b></div>
      <label class="lab">عدد الأسئلة في الجولة</label><div class="range"><input type="range" min="3" max="30" value="${c.n}" data-in="n"><b>${c.n}</b></div>
      <label class="lab">وقت جولة "ماذا تعرف؟"</label><div class="range"><input type="range" min="15" max="120" step="5" value="${c.knowTime}" data-in="knowTime"><b>${c.knowTime} ث</b></div>
      <label class="lab">مدة كل تلميح في "من أنا؟"</label><div class="range"><input type="range" min="5" max="30" value="${c.whoStep}" data-in="whoStep"><b>${c.whoStep} ث</b></div>
      <label class="lab">طريقة الإجابة في سين جيم</label><div class="seg"><button class="${c.style === 'mcq' ? 'on' : ''}" data-a="style" data-v="mcq">اختيارات (تلقائي)</button><button class="${c.style === 'open' ? 'on' : ''}" data-a="style" data-v="open">مفتوحة والحَكَم يقرر</button></div>
      <label class="lab">حجم لوحة سين جيم</label><div class="seg"><button class="${c.copies === 1 ? 'on' : ''}" data-a="copies" data-v="1">24 سؤال</button><button class="${c.copies === 2 ? 'on' : ''}" data-a="copies" data-v="2">48 سؤال (كاملة)</button></div>
      <label class="lab">محاولات "الصمود"</label><div class="seg">${[1, 2, 3].map(v => `<button class="${c.lives === v ? 'on' : ''}" data-a="lives" data-v="${v}">${['محاولة واحدة', 'محاولتان', 'ثلاث محاولات'][v - 1]}</button>`).join('')}</div>
    </div>`;
    if (local) h += `<div class="foot"><div class="in"><button class="btn gold grow" data-a="start">ابدأ اللعب</button></div></div>`;
    else h += `<div class="foot"><div class="in"><button class="btn gold grow" data-a="openroom">افتح الغرفة</button></div></div>`;
    return h;
  };
  function catPicker() {
    const c = A.cfg; const groups = {};
    QB.order.forEach(id => { const k = QB.cats[id]; (groups[k.group] = groups[k.group] || []).push(k); });
    return `<div class="card"><h3>فئات الأسئلة <span class="mut" style="font-size:13px;font-family:Cairo">${c.cats.length} من ${QB.order.length}</span></h3>
      <div class="row"><button class="btn sm" data-a="catall">تحديد الكل</button><button class="btn sm" data-a="catnone">إلغاء الكل</button><button class="btn sm" data-a="catrnd">6 عشوائية</button></div>
      ${Object.keys(groups).map(g => `<div class="grp">${g}</div><div class="chips">${groups[g].map(k => `<button class="chip ${c.cats.includes(k.id) ? 'on' : ''}" data-a="cat" data-k="${k.id}"><span class="ce">${k.icon}</span>${k.name} <span class="n">${k.id === 'math' ? '∞' : k.n}</span></button>`).join('')}</div>`).join('')}</div>`;
  }
  SCR.lobby = () => {
    const pl = Object.values(A.lobby || {}); const t = A.cfg.teams;
    return top('غرفة اللعب') + `<div class="card center"><div class="mut">رمز الغرفة</div><div class="pin">${A.code || '....'}</div><div class="mut">افتحوا "فهيم" ← انضمام لغرفة ← أدخلوا الرمز (يلزم إنترنت)</div></div>
    <div class="card"><div class="row"><h3 class="grow">اللاعبون (${pl.length + (A.cfg.hostPlays ? 1 : 0)})</h3>
      <label class="row" style="gap:6px"><input type="checkbox" data-in="teams" ${t ? 'checked' : ''} style="width:auto">نظام الفرق</label></div>
      <label class="lab"><input type="checkbox" data-in="hostPlays" ${A.cfg.hostPlays ? 'checked' : ''} style="width:auto"> المضيف يلعب أيضاً (وإلا يكون حكماً وشاشة عرض)</label>
      ${A.cfg.hostPlays ? `<div class="row card" style="margin:6px 0;padding:10px">${av(A.me.emoji)}<input data-in="myname" value="${esc(A.me.name)}" placeholder="اسمك" class="grow" style="width:auto">${t ? teamBtn('host', A.hostTeam || 0) : ''}</div>` : ''}
      ${pl.length ? pl.map(p => `<div class="lbi">${av(p.emoji)}<span class="grow">${esc(p.name)}</span>${t ? teamBtn(p.id, p.team) : ''}</div>`).join('') : '<div class="waiting mut">بانتظار انضمام اللاعبين<span class="dots"></span></div>'}
      ${t ? '<div class="mut" style="font-size:13px;margin-top:6px">اضغط على لون الفريق لتغييره</div>' : ''}
    </div>
    <div class="foot"><div class="in"><button class="btn gold grow" data-a="hoststart" ${(pl.length + (A.cfg.hostPlays ? 1 : 0)) < 1 ? 'disabled' : ''}>ابدأ اللعبة</button></div></div>`;
  };
  function teamBtn(pid, team) { return `<button class="btn sm" data-a="team" data-p="${pid}" style="background:${COL[team]};min-width:90px">${['الأحمر', 'الأزرق', 'الذهبي', 'الأخضر'][team]}</button>`; }
  SCR.join = () => top('انضمام لغرفة') + `<div class="card"><label class="lab">اسمك</label><input data-in="myname" value="${esc(A.me.name)}" maxlength="18" placeholder="مثلاً: أبو كريم">
    <label class="lab">اختر رمزك</label><div class="emojis">${EMO.map(e => `<span class="${A.me.emoji === e ? 'on' : ''}" data-a="myemo" data-e="${e}">${e}</span>`).join('')}</div>
    <label class="lab">رمز الغرفة</label><input id="pin" inputmode="numeric" maxlength="4" placeholder="0000" style="font-size:36px;text-align:center;letter-spacing:12px;direction:ltr">
    <button class="btn gold wide" style="margin-top:16px" data-a="dojoin">دخول</button></div>`;
  SCR.wait = () => { const pl = Object.values(A.lobby || {}); return top('غرفة ' + (A.code || '')) + `<div class="waiting">${owl(110)}<h2>أنت في الغرفة!</h2><div class="mut">بانتظار المضيف ليبدأ اللعبة<span class="dots"></span></div></div><div class="card">${pl.map(p => `<div class="lbi">${av(p.emoji)}<span>${esc(p.name)}</span>${A.lobbyTeams ? `<span class="chip" style="margin-right:auto;background:${COL[p.team]}">فريق</span>` : ''}</div>`).join('')}</div>`; };
  SCR.help = () => top('طريقة اللعب') + `<div class="card"><p>فهيم لعبة مسابقات ثقافية جماعية: اختر الأنماط والفئات والصعوبة، وكل نمط يُلعب كجولة، والنقاط تتراكم حتى منصة التتويج.</p>
    <p><b>على جهاز واحد:</b> أضف الفرق وتناوبوا. في أنماط السرعة يأخذ كل فريق دوره.</p><p><b>عدة أجهزة:</b> المضيف ينشئ غرفة فيظهر رمز من 4 أرقام، وكل لاعب ينضم من جواله ويجاوب منه. يتطلب اتصالاً بالإنترنت.</p></div>
    ${Object.keys(MODES).map(k => `<div class="card"><h3><span class="gold" style="width:22px;display:inline-block">${ICON[k]}</span> ${MODES[k].name}</h3><p class="mut" style="line-height:1.8">${MODES[k].d}</p></div>`).join('')}
    <div class="card"><h3>مستويات الصعوبة</h3><p><span class="lvl l1">سهل</span> يعرفه معظم الناس (~90%)<br><span class="lvl l2">متوسط</span> للمثقف العادي<br><span class="lvl l3">صعب</span> للمهتم بالمجال<br><span class="lvl l4">خبير</span> أسئلة استنتاجية غير مباشرة للفاهم والمتمكن</p><p class="mut">اللعبة تتعلم: تسجّل نسبة الإجابات الصحيحة لكل سؤال وتعدّل تصنيفه تلقائياً مع الوقت، ولا تكرر الأسئلة حتى تنتهي.</p></div>`;
  SCR.bank = () => {
    const st = QB.stats(); const tot = st.mcq + st.who + st.lists + st.orders;
    return top('بنك الأسئلة') + `<div class="stat"><div><b>${tot.toLocaleString('en')}</b>سؤال وتحدٍّ</div><div><b>${QB.order.length}</b>فئة</div><div><b>∞</b>أسئلة مولّدة</div><div><b>${st.lists}</b>قائمة لـ"ماذا تعرف؟"</div></div>
    <div class="card"><h3>أضف سؤالك الخاص</h3><label class="lab">الفئة</label><select id="cq_c">${QB.order.map(id => `<option value="${id}">${QB.cats[id].icon} ${QB.cats[id].name}</option>`).join('')}</select>
    <label class="lab">المستوى</label><select id="cq_l">${[1, 2, 3, 4].map(l => `<option value="${l}">${LVL[l]}</option>`).join('')}</select>
    <label class="lab">السؤال</label><textarea id="cq_q" rows="2"></textarea>
    <label class="lab">الإجابة الصحيحة</label><input id="cq_a"><label class="lab">إجابات خاطئة (3)</label><input id="cq_w1"><input id="cq_w2" style="margin-top:6px"><input id="cq_w3" style="margin-top:6px">
    <button class="btn gold wide" style="margin-top:12px" data-a="addq">حفظ السؤال</button></div>
    <div class="card"><h3>الفئات</h3>${QB.order.map(id => `<div class="resi"><span>${QB.cats[id].icon} ${QB.cats[id].name}</span><b>${id === 'math' ? '∞' : QB.cats[id].n}</b></div>`).join('')}</div>
    <button class="btn wide" data-a="resetseen">إعادة ضبط الأسئلة التي ظهرت سابقاً</button>`;
  };

  // ---------- شاشة اللعب ----------
  SCR.game = () => {
    const V = A.V; if (!V) return '<div class="waiting">جارٍ التحميل<span class="dots"></span></div>';
    const d = V.d || {};
    if (V.ph === 'banner') { const m = MODES[d.mode]; return `<div class="roundbanner"><div class="kick">الجولة ${V.ri + 1} من ${V.rounds.length}</div><div class="ri">${ICON[d.mode]}</div><h2>${m.name}</h2><div class="orn">✦</div><p>${m.d}</p></div>${scoreboard()}${hostBar('ابدأ الجولة')}`; }
    if (V.ph === 'podium') return podium();
    if (V.ph === 'lb') return leaderboard();
    const R = { q: gQ, reveal: gReveal, pick: gBoard, open: gOpen, buzzq: gBuzz, kready: gKready, know: gKnow, kres: gKres, bid: gBid, who: gWho, wager: gWager };
    return (R[V.ph] || (() => '<div class="waiting">...</div>'))(V, d);
  };
  function gQ(V, d) {
    const can = d.who.some(s => canAct(s)) && !d.who.filter(s => canAct(s)).every(s => d.done.includes(s));
    const actAs = V.local ? d.who.find(s => !d.done.includes(s)) : mySide();
    let h = scoreboard(d.who) + qhead(d) + timerUI();
    if (d.sub) h += `<div class="subline">${esc(d.sub)}</div>`;
    if (d.msg) h += `<div class="center mut">${esc(d.msg)}</div>`;
    h += `<div class="qbox ${/^[\u{1F1E6}-\u{1F1FF}]/u.test(d.text.slice(-4)) || d.text.length < 25 ? '' : ''}">${fmtQ(d.text)}</div>`;
    if (d.value) h += `<div class="subline">قيمة السؤال ${d.value}</div>`;
    if (d.helpers && canAct(d.helpers.side)) { const hs = d.helpers.h; h += `<div class="helpers"><button class="helper ${hs.call ? '' : 'used'}" data-a="helper" data-h="call">${ICON.phone} اتصال بصديق</button><button class="helper ${hs.two ? '' : 'used'}" data-a="helper" data-h="two">${ICON.two} جاوب جوابين</button><button class="helper ${hs.hole ? '' : 'used'}" data-a="helper" data-h="hole">${ICON.hole} الحفرة</button></div>`; }
    if (d.kind === 'mcq') {
      const picked = A.sel.i, picked2 = A.sel.j;
      h += `<div class="answers ${d.opts.some(o => String(o).length > 40) ? 'one' : ''}">${d.opts.map((o, i) => `<button class="ans c${i} ${d.hide.includes(i) ? 'gone' : ''} ${picked === i || picked2 === i ? 'picked' : ''} ${!can ? 'dim' : ''}" data-a="ans" data-i="${i}" data-as="${actAs || ''}"><span class="sh">${SHAPES[i]}</span>${esc(o)}</button>`).join('')}</div>`;
    } else if (d.kind === 'tf') {
      h += `<div class="shown">الإجابة المقترحة: ${esc(d.shown)}</div><div class="tf"><button class="ans c3 ${!can ? 'dim' : ''}" data-a="tf" data-v="1" data-as="${actAs || ''}">${ICON.check} صح</button><button class="ans c0 ${!can ? 'dim' : ''}" data-a="tf" data-v="0" data-as="${actAs || ''}">${ICON.x} خطأ</button></div>`;
    } else if (d.kind === 'order') {
      h += `<div class="mut center">اضغط العناصر بالترتيب الصحيح (${A.ord.length}/${d.items.length})</div><div class="ordlist">${d.items.map(k => { const ix = A.ord.indexOf(k); return `<button class="orditem ${ix >= 0 ? 'picked' : ''}" data-a="ord" data-k="${esc(k)}" ${!can ? 'disabled' : ''}><span class="k">${ix >= 0 ? ix + 1 : '•'}</span>${esc(k)}</button>`; }).join('')}</div>
      <div class="row" style="margin-top:10px"><button class="btn grow" data-a="ordreset">إعادة</button><button class="btn gold grow" data-a="ordsend" data-as="${actAs || ''}" ${A.ord.length < d.items.length || !can ? 'disabled' : ''}>تأكيد الترتيب</button></div>`;
    }
    if (!V.local && d.who.length > 1) h += `<div class="center mut" style="margin-top:10px">أجاب ${d.done.length} من ${d.who.length}</div>`;
    if (!can && !V.local && d.who.length && !d.who.some(s => canAct(s))) h += `<div class="center mut" style="margin-top:8px">بانتظار ${d.who.map(s => esc(sideById(s).name)).join('، ')}<span class="dots"></span></div>`;
    else if (!can && !V.local) h += `<div class="subline" style="margin-top:10px">تم إرسال إجابتك</div>`;
    if (isHost()) h += `<div class="foot"><div class="in"><button class="btn grow" data-a="next" ${V.ph === 'q' ? 'disabled' : ''}>بانتظار الإجابات…</button><button class="btn" data-a="menu">${ICON.menu}</button></div></div>`;
    return h;
  }
  function fmtQ(t) { const e = esc(t); return e.replace(/([\u{1F1E6}-\u{1F1FF}]{2})/gu, '<span style="font-size:90px;line-height:1">$1</span>'); }
  function gReveal(V, d) {
    let h = scoreboard() + qhead(d);
    if (d.kind === 'who') {
      h += `<div class="verdict ${d.res.length ? 'ok' : 'neu'}">${d.res.length ? `${esc(sideById(d.res[0].s).name)} عرفها  +${d.res[0].d}` : 'لم يعرفها أحد'}</div><div class="qbox">${esc(d.answer)}</div><div class="clues">${d.clues.map((c, i) => `<div class="clue"><b>${i + 1}</b>${esc(c)}</div>`).join('')}</div>`;
      return h + nextBtn();
    }
    const mine = d.res.filter(r => isMine(r.s));
    if (!V.local && mine.length) h += `<div class="verdict ${mine[0].ok ? 'ok' : 'bad'}">${mine[0].ok ? 'إجابة صحيحة' : (mine[0].timeout ? 'انتهى الوقت' : 'إجابة خاطئة')} ${mine[0].d ? '  ' + (mine[0].d > 0 ? '+' : '') + mine[0].d : ''}</div>`;
    else if (V.local && d.res.length === 1) { const r = d.res[0]; h += `<div class="verdict ${r.ok ? 'ok' : 'bad'}">${esc(sideById(r.s).name)} — ${r.ok ? 'إجابة صحيحة' : (r.timeout ? 'انتهى الوقت' : 'إجابة خاطئة')} ${r.d ? '  ' + (r.d > 0 ? '+' : '') + r.d : ''}</div>`; }
    else if (!d.res.length && d.title) h += `<div class="verdict neu">${esc(d.title)}</div>`;
    h += `<div class="qbox">${fmtQ(d.text)}</div>`;
    if (d.kind === 'mcq') h += `<div class="answers ${d.opts.some(o => String(o).length > 40) ? 'one' : ''}">${d.opts.map((o, i) => `<div class="ans c${i} ${i === d.ans ? 'right' : 'dim'}"><span class="sh">${i === d.ans ? '✓' : SHAPES[i]}</span>${esc(o)} ${countPick(d, i)}</div>`).join('')}</div>`;
    if (d.kind === 'tf') h += `<div class="shown">المقترح: ${esc(d.shown)} — ${d.truth ? 'صحيحة' : 'خاطئة'}${!d.truth ? `<br><span style="color:#9fe6c1">الصحيح: ${esc(d.real)}</span>` : ''}</div>`;
    if (d.kind === 'order') h += `<div class="ordlist">${d.correct.map((k, i) => `<div class="orditem"><span class="k">${i + 1}</span>${esc(k)}</div>`).join('')}</div>`;
    if (d.rate != null) h += `<div class="rate"><span>${d.rate}% أجابوا صحيحاً</span><span class="bar"><i style="width:${d.rate}%"></i></span></div>`;
    if (d.res.length > 1 || (V.local && d.res.length > 1)) h += `<div class="reslist" style="margin-top:10px">${d.res.map(r => `<div class="resi ${r.ok ? 'ok' : 'bad'}"><span><span class="gold">${esc(sideById(r.s).emoji)}</span> ${esc(sideById(r.s).name)}</span><span class="${r.d >= 0 ? 'plus' : 'minus'}">${r.d > 0 ? '+' : ''}${r.d}</span></div>`).join('')}</div>`;
    return h + nextBtn();
  }
  function countPick(d, i) { if (!d.res || d.res.length < 2) return ''; const n = d.res.filter(r => r.ch === i || r.ch2 === i).length; return n ? `<span style="float:left;opacity:.85;font-size:13px">×${n}</span>` : ''; }
  function gBoard(V, d) {
    const ts = sideById(d.turn); const can = canAct(d.turn);
    let h = scoreboard(d.turn) + `<div class="turnline">دور ${esc(ts.name)}${can ? ' — اختر سؤالاً' : ''}</div>`;
    h += `<div class="board" style="grid-template-columns:repeat(${d.cats.length},1fr)">${d.cats.map(c => `<div class="bcol-h"><span><span class="ce">${c.icon}</span><br>${esc(c.name)}</span></div>`).join('')}`;
    const rows = []; [1, 2, 3, 4].forEach(lv => { for (let k = 0; k < d.copies; k++) rows.push({ lv, k }); });
    rows.forEach(r => { d.cats.forEach((c, ci) => { const cell = d.cells.filter(x => x.ci === ci && x.lv === r.lv)[r.k]; h += `<button class="cell ${cell.used ? 'used' : ''}" data-a="cell" data-id="${cell.id}" ${!can ? 'style="pointer-events:none"' : ''}>${cell.v}</button>`; }); });
    h += `</div>`;
    if (d.helpers[d.turn]) { const hs = d.helpers[d.turn]; h += `<div class="helpers mut" style="font-size:13px">وسائل ${esc(ts.name)} المتبقية: ${[hs.call ? 'اتصال بصديق' : '', hs.two ? 'جاوب جوابين' : '', hs.hole ? 'الحفرة' : ''].filter(Boolean).join(' · ') || 'لا شيء'}</div>`; }
    if (isHost()) h += `<div class="foot"><div class="in"><button class="btn grow" data-a="skipround">إنهاء اللوحة</button><button class="btn" data-a="menu">${ICON.menu}</button></div></div>`;
    return h;
  }
  function gOpen(V, d) {
    const cur = d.step === 'steal' ? d.stealer : d.who[0]; const s = sideById(cur);
    let h = scoreboard(cur) + qhead(d) + timerUI() + `<div class="subline">${d.step === 'steal' ? 'فرصة سرقة لـ ' : 'يجيب: '}${esc(s.name)} — ${d.value}</div><div class="qbox">${fmtQ(d.text)}</div>`;
    if (d.answer) h += `<div class="shown">الإجابة: ${esc(d.answer)}</div>`;
    if (isHost()) {
      h += `<div class="foot"><div class="in">${d.step === 'ask' ? `<button class="btn gold grow" data-a="judge" data-step="show">أظهر الإجابة</button>` : ''}<button class="btn ok grow" data-a="judge" data-ok="1">${ICON.check} صح</button><button class="btn bad grow" data-a="judge" data-ok="0">${ICON.x} خطأ</button></div></div>`;
    } else h += `<div class="center mut">جاوب بصوت عالٍ… والحَكَم يقرر!</div>`;
    return h;
  }
  function gBuzz(V, d) {
    let h = scoreboard() + qhead(d) + timerUI() + `<div class="qbox">${fmtQ(d.text)}</div><div class="subline">${d.value} نقطة — والخطأ يخصم ${d.value / 2}</div>`;
    if (V.local) h += `<div class="buzzgrid">${V.sides.map(s => `<button class="buzz ${d.locked.includes(s.id) ? 'locked' : ''}" style="background:radial-gradient(circle at 35% 30%,${s.color}ee,${s.color}88 70%,#0b0f1a)" data-a="buzz" data-as="${s.id}"><span class="g">${esc(s.emoji)}</span>${esc(s.name)}</button>`).join('')}</div>`;
    else { const me = mySide(); h += me ? `<div style="margin-top:20px"><button class="buzz big ${d.locked.includes(me) ? 'locked' : ''}" data-a="buzz">${ICON.buzzer}</button></div>` : ''; }
    return h + (isHost() ? `<div class="foot"><div class="in"><button class="btn grow" data-a="skipround">إنهاء الجولة</button></div></div>` : '');
  }
  function gKready(V, d) {
    const s = sideById(d.side);
    let h = scoreboard(d.side) + qhead(d) + `<div class="roundbanner"><div class="ri" style="font-size:34px">${esc(s.emoji)}</div><h2>دور ${esc(s.name)}</h2><div class="mut">الموضوع:</div><div class="qbox">${esc(d.topic)}</div><div class="mut">لديك ${d.time} ثانية — اكتب كل إجابة واضغط إدخال</div></div>`;
    if (canAct(d.side) || isHost()) h += `<div class="foot"><div class="in"><button class="btn gold grow" data-a="kgo">ابدأ</button></div></div>`;
    return h;
  }
  function gKnow(V, d) {
    const s = sideById(d.side); const can = canAct(d.side);
    let h = scoreboard(d.side) + qhead(d) + timerUI() + `<div class="subline">${esc(s.name)}</div><div class="qbox" style="min-height:70px;font-size:20px">${esc(d.topic)}</div>`;
    h += `<div class="bigcount">${d.found.length}${d.target ? ' / ' + d.target : ''}</div>`;
    if (can) h += `<form class="typebox" data-f="text"><input id="tin" autocomplete="off" placeholder="اكتب إجابة..." enterkeyhint="send"><button class="btn gold">↵</button></form>`;
    if (d.flash === 'bad' && can) h += `<div class="center minus">"${esc(d.lastBad)}" غير موجودة في القائمة</div>`;
    if (d.flash === 'dup' && can) h += `<div class="center mut">ذكرتها من قبل!</div>`;
    h += `<div class="found">${d.found.map(f => `<span>${esc(f)}</span>`).join('')}</div>`;
    if (isHost()) h += `<div class="foot"><div class="in"><button class="btn ok grow" data-a="manual">${ICON.plus} إجابة صحيحة (حَكَم)</button><button class="btn grow" data-a="kend">إنهاء</button></div></div>`;
    else if (can) h += `<div class="foot"><div class="in"><button class="btn grow" data-a="kend">إنهاء دوري</button></div></div>`;
    return h;
  }
  function gKres(V, d) {
    const s = sideById(d.side);
    let h = scoreboard() + qhead(d);
    if (d.auction) h += `<div class="verdict ${d.auctionOk ? 'ok' : 'bad'}">${d.auctionOk ? `${esc(s.name)} نجح بذكر ${d.target}  +${d.target * 100}` : `${esc(s.name)} لم ينجح (${d.found.length} من ${d.target}) — للخصوم +${d.target * 50}`}</div>`;
    else h += `<div class="verdict ok">${esc(s.name)} ذكر ${d.found.length} إجابة  +${d.score}</div>`;
    h += `<div class="qbox" style="min-height:60px;font-size:18px">${esc(d.topic)}</div><div class="found">${d.found.map(f => `<span>${esc(f)}</span>`).join('')}</div>`;
    if (d.missed && d.missed.length) h += `<div class="mut" style="margin-top:12px">إجابات أخرى كانت ممكنة:</div><div class="found">${d.missed.map(f => `<span class="miss">${esc(f)}</span>`).join('')}</div>`;
    return h + nextBtn();
  }
  function gBid(V, d) {
    const t = sideById(d.turn); const can = canAct(d.turn);
    let h = scoreboard(d.turn) + qhead(d) + `<div class="qbox">${esc(d.topic)}</div><div class="center mut">عدد الإجابات الممكنة في قاعدة البيانات: ${d.total}</div>`;
    h += `<div class="bigcount" style="margin:14px 0">${d.bid || '—'}</div><div class="center mut">${d.bidder ? `أعلى مزايدة: ${esc(sideById(d.bidder).name)}` : 'لا مزايدات بعد'}</div>`;
    h += `<div class="turnline">الدور على ${esc(t.name)}</div>`;
    if (d.passed.length) h += `<div class="center mut">انسحب: ${d.passed.map(p => esc(sideById(p).name)).join('، ')}</div>`;
    if (can) { const opts = []; for (let k = d.bid + 1; k <= Math.min(d.total, d.bid + 12); k++) opts.push(k); h += `<div class="chips" style="justify-content:center;margin-top:10px">${opts.map(k => `<button class="chip" style="font-size:20px;padding:10px 16px" data-a="bid" data-n="${k}" data-as="${d.turn}">${k}</button>`).join('')}</div><div class="foot"><div class="in"><button class="btn bad grow" data-a="pass" data-as="${d.turn}">انسحاب</button></div></div>`; }
    return h;
  }
  function gWho(V, d) {
    let h = scoreboard() + qhead(d) + timerUI() + `<div class="subline">من أنا؟ — قيمة الإجابة الآن ${d.pts}</div><div class="clues">`;
    for (let i = 0; i < d.total; i++) h += i < d.clues.length ? `<div class="clue"><b>${i + 1}</b>${esc(d.clues[i])}</div>` : `<div class="clue hid"><b>${i + 1}</b>تلميح مخفي…</div>`;
    h += `</div>`;
    if (d.wrong) h += `<div class="center minus">${esc(sideById(d.wrong.s).name)}: "${esc(d.wrong.txt)}" إجابة خاطئة</div>`;
    if (V.local) {
      if (d.buzzer) { const s = sideById(d.buzzer); h += `<div class="subline">${esc(s.name)} يخمّن:</div><form class="typebox" data-f="text" data-as="${d.buzzer}"><input id="tin" autocomplete="off" placeholder="اكتب الإجابة"><button class="btn gold">↵</button></form>`; }
      else h += `<div class="buzzgrid">${V.sides.map(s => `<button class="buzz ${d.locked.includes(s.id) ? 'locked' : ''}" style="background:radial-gradient(circle at 35% 30%,${s.color}ee,${s.color}88 70%,#0b0f1a);max-height:130px" data-a="buzz" data-as="${s.id}"><span class="g">${esc(s.emoji)}</span>عرفتها</button>`).join('')}</div>`;
    } else { const me = mySide(); if (me && !d.locked.includes(me)) h += `<form class="typebox" data-f="text"><input id="tin" autocomplete="off" placeholder="اكتب تخمينك…"><button class="btn gold">↵</button></form>`; else if (me) h += `<div class="center mut">انتظر التلميح التالي…</div>`; }
    if (isHost()) h += `<div class="foot"><div class="in"><button class="btn grow" data-a="giveup">كشف الإجابة</button></div></div>`;
    return h;
  }
  function gWager(V, d) {
    let h = scoreboard() + `<div class="roundbanner"><div class="ri">${ICON.final}</div><h2>راهن بنقاطك</h2><p>سؤال صعب واحد: إن أصبت كسبت رهانك، وإن أخطأت خسرته.${d.last.length ? '<br>الفريق المتأخر يحصل على ضعف رهانه إن أصاب.' : ''}</p></div>`;
    const todo = V.sides.filter(s => !d.set.includes(s.id) && canAct(s.id));
    const s = V.local ? todo[0] : todo.find(x => x.id === mySide());
    if (s) { const mx = d.max[s.id]; h += `<div class="card center">${av(s.emoji, s.color)}<h3 style="justify-content:center">${esc(s.name)} — الحد الأقصى ${mx}</h3><div class="range"><input type="range" min="0" max="${mx}" step="50" value="${Math.min(mx, A.sel.w || Math.round(mx / 2 / 50) * 50)}" id="wg" data-in="wg"><b id="wgv">${Math.min(mx, A.sel.w || Math.round(mx / 2 / 50) * 50)}</b></div><button class="btn gold wide" style="margin-top:12px" data-a="wager" data-as="${s.id}">تأكيد الرهان</button></div>`; }
    h += `<div class="center mut">راهن: ${d.set.map(x => esc(sideById(x).name)).join('، ') || '—'}</div>`;
    return h;
  }
  function leaderboard() {
    const V = A.V; const rk = V.d.ranking.map(sideById);
    return `<div class="roundbanner" style="padding:18px 0 4px"><div class="ri">${ICON.trophy}</div><h2 style="font-size:30px">الترتيب</h2></div><div class="lb">${rk.map((s, i) => `<div class="lbi" style="animation-delay:${i * .08}s;border-right:3px solid ${s.color}"><span class="rk">${i + 1}</span>${av(s.emoji, s.color)}<span>${esc(s.name)}</span>${s.streak > 1 ? `<span class="st">${ICON.fire}${s.streak}</span>` : ''}<span class="sc">${s.score}</span>${s.last ? `<span class="${s.last > 0 ? 'plus' : 'minus'}" style="font-size:13px">${s.last > 0 ? '+' : ''}${s.last}</span>` : ''}</div>`).join('')}</div>` + nextBtn();
  }
  function podium() {
    const V = A.V; const rk = V.d.ranking.map(sideById);
    const slot = (s, cls, n) => s ? `<div class="pod ${cls}">${av(s.emoji, s.color)}<div class="nm">${esc(s.name)}</div><div class="sc">${s.score}</div><div class="bar" style="margin-top:6px">${n}</div></div>` : '<div class="pod"></div>';
    return `<div class="roundbanner" style="padding:20px 0 0"><div class="ri">${ICON.trophy}</div><h2>النتائج النهائية</h2><div class="orn">✦</div></div><div class="podium">${slot(rk[1], 'p2', 2)}${slot(rk[0], 'p1', 1)}${rk[2] ? slot(rk[2], 'p3', 3) : ''}</div>
    <div class="lb">${rk.slice(3).map((s, i) => `<div class="lbi"><span class="rk">${i + 4}</span>${av(s.emoji, s.color)}<span>${esc(s.name)}</span><span class="sc">${s.score}</span></div>`).join('')}</div>
    <div class="row" style="margin-top:20px">${isHost() ? `<button class="btn gold grow" data-a="again">العب مجدداً</button>` : ''}<button class="btn grow" data-a="home">الرئيسية</button></div>`;
  }

  // ---------- الرسم ----------
  function render() {
    const ae = document.activeElement; const keep = ae && ae.id === 'tin' ? ae.value : null;
    $app.innerHTML = (SCR[A.scr] || SCR.home)();
    const tin = document.getElementById('tin');
    if (tin) { if (keep !== null) tin.value = ''; if (A.V && (A.V.ph === 'know' || A.V.ph === 'who')) setTimeout(() => tin.focus(), 30); }
  }

  // ---------- الأحداث ----------
  $app.addEventListener('click', e => {
    const el = e.target.closest('[data-a]'); if (!el) return;
    SFX.unlock();
    const a = el.dataset.a, ds = el.dataset; const c = A.cfg;
    const asSide = ds.as || undefined;
    const H = {
      back() { if (A.scr === 'game' || A.scr === 'lobby' || A.scr === 'wait') { modal('الخروج من اللعبة الحالية؟', ['نعم، اخرج', 'إلغاء']).then(i => { if (i === 0) { leave(); go('home'); } }); return; } go('home'); },
      home() { leave(); go('home'); },
      local() { A.role = 'local'; go('setup'); },
      host() { A.role = 'host'; go('setup'); },
      join() { A.role = 'client'; go('join'); },
      practice() { A.role = 'local'; startLocal([{ name: A.me.name || 'أنت', emoji: A.me.emoji, color: COL[2] }], Object.assign({}, c, { modes: ['kahoot', 'tf', 'order', 'who'] })); },
      help() { go('help'); }, bank() { go('bank'); },
      sound() { SFX.on = !SFX.on; render(); },
      addside() { A.sides.push({ name: 'فريق ' + (A.sides.length + 1), emoji: EMO[(A.sides.length * 3) % EMO.length], color: COL[A.sides.length % COL.length] }); render(); },
      delside() { if (A.sides.length > 1) A.sides.splice(+ds.i, 1); render(); },
      emo() { A.emoPick = A.emoPick === +ds.i ? null : +ds.i; render(); },
      setemo() { A.sides[+ds.i].emoji = ds.e; A.emoPick = null; render(); },
      myemo() { A.me.emoji = ds.e; store.set('me', A.me); render(); },
      mode() { const k = ds.k; c.modes = c.modes.includes(k) ? c.modes.filter(x => x !== k) : [...c.modes, k]; render(); },
      preset() { c.modes = { seen: ['board', 'final'], t30: ['know', 'auction', 'buzzer', 'final'], kahoot: ['kahoot', 'tf', 'order'], all: Object.keys(MODES) }[ds.p]; render(); },
      cat() { const k = ds.k; c.cats = c.cats.includes(k) ? c.cats.filter(x => x !== k) : [...c.cats, k]; render(); },
      catall() { c.cats = QB.order.slice(); render(); }, catnone() { c.cats = []; render(); },
      catrnd() { c.cats = QB.shuffle(QB.order).slice(0, 6); render(); },
      lvl() { const l = +ds.l; c.levels = c.levels.includes(l) ? c.levels.filter(x => x !== l) : [...c.levels, l].sort(); if (!c.levels.length) c.levels = [l]; render(); },
      lvlp() { c.levels = { mix: [1, 2, 3, 4], easy: [1, 2], pro: [3, 4] }[ds.p]; c.curve = ds.p === 'mix'; render(); },
      style() { c.style = ds.v; render(); }, copies() { c.copies = +ds.v; render(); }, lives() { c.lives = +ds.v; render(); },
      start() { if (!validate()) return; startLocal(A.sides, c); },
      openroom() { if (!validate()) return; saveCfg(); A.lobby = {}; A.myPid = 'host'; go('lobby'); NET.host(code => { A.code = code; render(); }); },
      team() { const pid = ds.p; if (pid === 'host') A.hostTeam = ((A.hostTeam || 0) + 1) % 4; else { A.lobby[pid].team = (A.lobby[pid].team + 1) % 4; hostLobbyBroadcast(); } render(); },
      hoststart() { startHost(); },
      dojoin() { const pin = (document.getElementById('pin').value || '').trim(); if (!A.me.name) { toast('اكتب اسمك أولاً'); return; } if (!/^\d{4}$/.test(pin)) { toast('الرمز 4 أرقام'); return; } store.set('me', A.me); A.code = pin; A.lobby = {}; go('wait'); NET.join(pin); },
      next() { send({ type: 'next' }); },
      skipround() { modal('إنهاء هذه الجولة والانتقال للتالية؟', ['نعم', 'إلغاء']).then(i => { if (i === 0) send({ type: 'skipround' }); }); },
      menu() { modal('القائمة', ['⏭️ تخطي الجولة', '🏠 إنهاء اللعبة', SFX.on ? '🔇 إيقاف الصوت' : '🔊 تشغيل الصوت', 'إغلاق']).then(i => { if (i === 0) send({ type: 'skipround' }); else if (i === 1) { leave(); go('home'); } else if (i === 2) { SFX.on = !SFX.on; } }); },
      ans() { const i = +ds.i; const d = A.V.d; if (d.two && A.sel.i === undefined && canAct(asSide || mySide())) { A.sel.i = i; render(); toast('اختر الإجابة الثانية'); return; } if (d.two && A.sel.i !== undefined) { send({ type: 'answer', i: A.sel.i, j: i, as: asSide }); A.sel.j = i; } else { A.sel.i = i; send({ type: 'answer', i, as: asSide }); } SFX.click(); },
      tf() { send({ type: 'answer', v: ds.v === '1', as: asSide }); SFX.click(); },
      ord() { const k = ds.k; if (A.ord.includes(k)) return; A.ord.push(k); SFX.click(); render(); },
      ordreset() { A.ord = []; render(); },
      ordsend() { send({ type: 'answer', arr: A.ord.slice(), as: asSide }); },
      helper() { send({ type: 'helper', h: ds.h, as: A.V.d.helpers && A.V.d.helpers.side }); },
      cell() { send({ type: 'cell', id: +ds.id, as: A.V.d.turn }); SFX.click(); },
      judge() { send({ type: 'judge', step: ds.step, ok: ds.ok === '1' }); },
      buzz() { send({ type: 'buzz', as: asSide }); },
      kgo() { send({ type: 'kgo', as: A.V.d.side }); },
      kend() { send({ type: 'kend', as: A.V.d.side }); },
      manual() { send({ type: 'manual' }); },
      bid() { send({ type: 'bid', n: +ds.n, as: asSide }); SFX.click(); },
      pass() { send({ type: 'pass', as: asSide }); },
      giveup() { send({ type: 'giveup' }); },
      wager() { const v = +(document.getElementById('wg') || {}).value || 0; send({ type: 'wager', n: v, as: asSide }); A.sel.w = 0; },
      again() { if (A.role === 'local') startLocal(A.V.sides.map(s => ({ name: s.name, emoji: s.emoji, color: s.color })), c); else startHost(); },
      addq() { const g = id => (document.getElementById(id).value || '').trim(); const q = { c: g('cq_c'), l: +g('cq_l'), q: g('cq_q'), a: g('cq_a'), w: [g('cq_w1'), g('cq_w2'), g('cq_w3')].filter(Boolean) }; if (!q.q || !q.a || q.w.length < 3) { toast('أكمل السؤال والإجابات الأربع'); return; } QB.saveCustom(q); toast('تم حفظ السؤال'); render(); },
      resetseen() { QB.resetSeen(); toast('تمت إعادة الضبط'); }
    };
    if (H[a]) H[a]();
  });
  $app.addEventListener('input', e => {
    const el = e.target; const k = el.dataset.in; if (!k) return; const c = A.cfg;
    if (k === 'sname') A.sides[+el.dataset.i].name = el.value;
    else if (k === 'myname') { A.me.name = el.value; store.set('me', A.me); }
    else if (['timer', 'n', 'knowTime', 'whoStep'].includes(k)) { c[k] = +el.value; el.nextElementSibling.textContent = el.value + (k === 'n' ? '' : ' ث'); }
    else if (k === 'wg') { A.sel.w = +el.value; document.getElementById('wgv').textContent = el.value; }
  });
  $app.addEventListener('change', e => {
    const el = e.target; const k = el.dataset.in; const c = A.cfg;
    if (k === 'curve') c.curve = el.checked;
    else if (k === 'teams') { c.teams = el.checked; hostLobbyBroadcast(); render(); }
    else if (k === 'hostPlays') { c.hostPlays = el.checked; render(); }
  });
  $app.addEventListener('submit', e => {
    e.preventDefault(); const f = e.target; const inp = f.querySelector('input'); const s = inp.value.trim(); if (!s) return;
    send({ type: 'text', s, as: f.dataset.as || (A.V && A.V.d.side) || undefined }); inp.value = ''; inp.focus();
  });

  function validate() { const c = A.cfg; if (!c.modes.length) { toast('اختر نمطاً واحداً على الأقل'); return false; } if (!c.cats.length) { toast('اختر فئة واحدة على الأقل'); return false; } return true; }
  function saveCfg() { store.set('cfg', A.cfg); store.set('sides', A.sides); }
  function startLocal(sides, cfg) {
    saveCfg(); A.role = 'local'; A.V = null;
    const S = sides.map((s, i) => ({ id: 's' + i, name: s.name || ('فريق ' + (i + 1)), emoji: s.emoji, color: s.color || COL[i % COL.length] }));
    const P = {}; S.forEach(s => P['L' + s.id] = { id: 'L' + s.id, name: s.name, side: s.id });
    A.myPid = 'L' + S[0].id; A.scr = 'game';
    E.init(cfg, S, P, true, A.myPid);
  }
  function startHost() {
    const c = A.cfg; const pl = Object.values(A.lobby);
    let S = [], P = {};
    const all = pl.slice(); if (c.hostPlays) all.unshift({ id: 'host', name: A.me.name || 'المضيف', emoji: A.me.emoji, team: A.hostTeam || 0 });
    if (c.teams) {
      const tn = ['الفريق الأحمر', 'الفريق الأزرق', 'الفريق الذهبي', 'الفريق الأخضر'], te = ['♛', '♞', '♜', '♝'];
      [...new Set(all.map(p => p.team))].sort().forEach(t => S.push({ id: 't' + t, name: tn[t], emoji: te[t], color: COL[t] }));
      all.forEach(p => P[p.id] = { id: p.id, name: p.name, emoji: p.emoji, side: 't' + p.team });
    } else all.forEach((p, i) => { S.push({ id: 's' + p.id, name: p.name, emoji: p.emoji, color: COL[i % COL.length] }); P[p.id] = { id: p.id, name: p.name, emoji: p.emoji, side: 's' + p.id }; });
    if (!S.length) { toast('لا يوجد لاعبون'); return; }
    if (!c.hostPlays) P.host = { id: 'host', name: 'المضيف', side: null };
    A.myPid = 'host'; A.scr = 'game'; A.V = null;
    E.init(c, S, P, false, 'host');
  }
  function leave() { E.stop(); NET.close(); A.V = null; A.lobby = null; A.localEnd = 0; }

  // زر الرجوع في أندرويد
  window.fahimBack = function () { if (document.querySelector('.modal')) { document.querySelector('.modal').remove(); return true; } if (A.scr === 'home') return false; if (A.scr === 'game' || A.scr === 'lobby') { modal('الخروج من اللعبة؟', ['نعم، اخرج', 'إلغاء']).then(i => { if (i === 0) { leave(); go('home'); } }); return true; } go('home'); return true; };

  // زخرفة الخلفية
  
  if (QB.lateGen) QB.lateGen(); QB.loadCustom(); QB.stats();
  render();
})();
