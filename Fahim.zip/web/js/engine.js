/* محرك فهيم: يعمل على جهاز المضيف فقط ويبث الحالة للجميع */
const MODES = {
  board: { name: 'سين جيم', e: '🎯', d: 'لوحة 6 فئات بنقاط 200 حتى 800 (سهل ← خبير)، مع وسائل مساعدة: اتصال بصديق، جاوب جوابين، الحفرة. والخطأ يفتح باب السرقة للخصم.' },
  kahoot: { name: 'تحدي السرعة', e: '⚡', d: 'على طريقة كاهوت: الجميع يجاوب معاً، الأسرع يكسب نقاطاً أكثر، ومكافأة على سلسلة الإجابات الصحيحة.' },
  buzzer: { name: 'الجرس', e: '🔔', d: 'من تحدي الثلاثين: السؤال يظهر وأول من يضغط الجرس يجاوب. الخطأ يخصم نقاطاً ويمنح الفرصة للباقين.' },
  know: { name: 'ماذا تعرف؟', e: '⏱️', d: 'من تحدي الثلاثين: موضوع ووقت محدد، اكتب أكبر عدد ممكن من الإجابات الصحيحة. كل إجابة = 100 نقطة.' },
  auction: { name: 'المزاد', e: '🔨', d: 'من تحدي الثلاثين: زايدوا على عدد ما تستطيعون ذكره في الموضوع، ثم يجب على الفائز بالمزاد إثبات ذلك!' },
  who: { name: 'من أنا؟', e: '🕵️', d: 'تلميحات تتكشف تباعاً من الأصعب للأسهل. خمّن مبكراً لتكسب 400، أو انتظر وتكسب أقل.' },
  tf: { name: 'صح أم خطأ', e: '✅', d: 'جولة خاطفة: سؤال وإجابة مقترحة... هل هي صحيحة أم خطأ؟ السرعة تصنع الفارق.' },
  order: { name: 'رتّب', e: '🔢', d: 'رتّب 4 عناصر زمنياً أو حسب الحجم أو الترتيب. الترتيب الكامل يمنح أعلى النقاط.' },
  survival: { name: 'الصمود', e: '🛡️', d: 'لكل لاعب محاولتان فقط، والأسئلة تصعب كل 3 أسئلة. آخر الصامدين يحصد مكافأة 1000.' },
  final: { name: 'التعويض', e: '💰', d: 'من تحدي الثلاثين: الجولة الأخيرة. راهن بجزء من نقاطك على سؤال صعب، والمتأخر يحصل على ضعف رهانه إن أصاب!' }
};
const LVL = ['', 'سهل', 'متوسط', 'صعب', 'خبير'];
const BOARD_VALS = [0, 200, 400, 600, 800];

const E = (function () {
  let G = null, TT = null;
  const now = () => Date.now();
  const S = id => G.sides.find(s => s.id === id);
  const alive = () => G.sides.filter(s => !s.gone);
  const nameOf = id => (S(id) || {}).name || '';
  function setT(ms, fn) { clearT(); G.tEnd = now() + ms; G.tTot = ms; TT = setTimeout(() => { TT = null; G.tEnd = 0; fn(); }, ms); }
  function clearT() { if (TT) clearTimeout(TT); TT = null; if (G) G.tEnd = 0; }
  function add(id, n) { const s = S(id); if (s) { s.score += n; s.last = n; } }
  function levelFor(i, n) {
    const L = G.cfg.levels.slice().sort();
    if (!G.cfg.curve) return QB.pick(L);
    return L[Math.min(L.length - 1, Math.floor(i / Math.max(1, n) * L.length))];
  }

  // ---------- الحالة العامة ----------
  function view() {
    return {
      sides: G.sides, players: G.players, local: G.local, ri: G.ri, rounds: G.rounds, mode: G.mode, ph: G.ph, d: G.d,
      t: G.tEnd ? Math.max(0, G.tEnd - now()) : 0, tot: G.tTot, cfg: { style: G.cfg.style, timer: G.cfg.timer, n: G.cfg.n }, seq: ++G.seq, host: G.hostPid
    };
  }
  function push() { const v = view(); if (E.onState) E.onState(v); }

  function init(cfg, sides, players, local, hostPid) {
    clearT();
    QB.newSession();
    const r = cfg.modes.filter(m => m !== 'final'); if (cfg.modes.includes('final')) r.push('final');
    G = { cfg, sides: sides.map((s, i) => ({ ...s, score: 0, streak: 0, last: 0 })), players, local, rounds: r, ri: -1, mode: null, ph: 'idle', d: {}, m: {}, seq: 0, hostPid, _next: null };
    nextRound();
  }
  function nextRound() {
    clearT();
    G.ri++;
    if (G.ri >= G.rounds.length) { G.ph = 'podium'; G.mode = null; G.d = { ranking: G.sides.slice().sort((a, b) => b.score - a.score).map(s => s.id) }; G._next = null; push(); return; }
    G.mode = G.rounds[G.ri]; G.ph = 'banner'; G.d = { mode: G.mode }; G.m = {};
    G._next = () => M[G.mode].start();
    push();
    setT(3200, () => M[G.mode].start());
  }
  function lb(next) { G.ph = 'lb'; G.d = { ranking: G.sides.slice().sort((a, b) => b.score - a.score).map(s => s.id) }; G._next = next; push(); setT(3500, next); }

  // ---------- آلية السؤال الموحدة ----------
  function ask(o) {
    clearT();
    G.ask = o; o.res = {}; o.t0 = now();
    G.ph = 'q';
    const q = o.q;
    G.d = { kind: o.kind, title: o.title || '', who: o.who, done: [], c: q.c, l: q.l, value: o.value || 0, hide: o.hide || [], two: false, helpers: o.helpers || null, sub: o.sub || '' };
    if (o.kind === 'mcq') { G.d.text = q.q; G.d.opts = q.opts; }
    else if (o.kind === 'tf') { G.d.text = q.q; G.d.shown = q.shown; }
    else if (o.kind === 'order') { G.d.text = q.q; G.d.items = q.shown; }
    if (G.cfg.style === 'open' && o.kind === 'mcq' && o.openOk) { G.ph = 'open'; G.d.step = 'ask'; }
    setT(o.time * 1000, () => { if (G.ph === 'open') { G.d.timeout = true; push(); } else finishAsk(); });
    push();
  }
  function answer(side, pid, a) {
    const o = G.ask; if (!o || G.ph !== 'q') return;
    if (!o.who.includes(side) || o.res[side]) return;
    let ok = false, part = 0;
    if (o.kind === 'mcq') ok = a.i === o.q.ans || (G.d.two && a.j === o.q.ans);
    else if (o.kind === 'tf') ok = (!!a.v) === o.q.truth;
    else if (o.kind === 'order') { const arr = a.arr || []; part = arr.filter((k, i) => k === o.q.correct[i]).length; ok = part === o.q.correct.length; }
    o.res[side] = { ok, part, t: now() - o.t0, ch: a.i, ch2: a.j, v: a.v, pid, arr: a.arr };
    G.d.done.push(side);
    if (o.who.every(s => o.res[s])) finishAsk(); else push();
  }
  function finishAsk() {
    const o = G.ask; if (!o) return; clearT();
    o.who.forEach(s => { if (!o.res[s]) o.res[s] = { ok: false, part: 0, t: o.time * 1000, timeout: true }; });
    if (o.decide && o.decide(o.res) === false) return;
    reveal(o);
  }
  function reveal(o) {
    const deltas = o.score ? o.score(o.res) : {};
    // إحصائيات التكيّف
    if (o.kind === 'mcq' || o.kind === 'tf') o.who.forEach(s => QB.record && QB.record(o.q.id, o.res[s].ok));
    G.ph = 'reveal';
    G.d.res = o.who.map(s => ({ s, ok: o.res[s].ok, part: o.res[s].part, d: deltas[s] || 0, ch: o.res[s].ch, ch2: o.res[s].ch2, v: o.res[s].v, timeout: o.res[s].timeout }));
    if (o.kind === 'mcq') G.d.ans = o.q.ans;
    if (o.kind === 'tf') { G.d.truth = o.q.truth; G.d.real = o.q.a; }
    if (o.kind === 'order') { G.d.correct = o.q.correct; G.d.vals = o.q.vals; }
    G.d.rate = QB.rate ? QB.rate(o.q.id) : null;
    G.ask = null;
    G._next = o.after;
    push();
    if (o.auto) setT(o.auto, o.after);
  }
  function revealPlain(q, title, next) {
    clearT(); G.ph = 'reveal';
    G.d = { kind: 'mcq', title, text: q.q, opts: q.opts, ans: q.ans, c: q.c, l: q.l, res: [], hide: [], who: [] };
    G._next = next; push(); setT(5000, next);
  }
  function rotateWho(i) { const al = alive(); return [al[i % al.length].id]; }

  // ---------- الأنماط ----------
  const M = {};
  M.kahoot = {
    start() { G.m = { i: 0, n: G.cfg.n }; this.next(); },
    next() {
      const m = G.m; if (m.i >= m.n * (G.local ? alive().length : 1)) return nextRound();
      const total = m.n * (G.local ? alive().length : 1);
      const lv = levelFor(m.i, total); const q = QB.getMCQ(G.cfg.cats, [lv]);
      const who = G.local ? rotateWho(m.i) : alive().map(s => s.id); m.i++;
      const T = G.cfg.timer;
      ask({
        kind: 'mcq', q, who, time: T, title: `سؤال ${m.i} من ${total}`, sub: G.local ? 'دور: ' + nameOf(who[0]) : '',
        score(res) { const d = {}; for (const s in res) { const r = res[s], sd = S(s); if (r.ok) { sd.streak = (sd.streak || 0) + 1; d[s] = Math.round(500 + 500 * (1 - r.t / (T * 1000))) + Math.min(sd.streak - 1, 5) * 100; } else { sd.streak = 0; d[s] = 0; } add(s, d[s]); } return d; },
        after: () => lb(() => M.kahoot.next()), auto: 4000
      });
    }
  };
  M.tf = {
    start() { G.m = { i: 0, n: Math.max(5, G.cfg.n) }; this.next(); },
    next() {
      const m = G.m; const total = m.n * (G.local ? alive().length : 1); if (m.i >= total) return nextRound();
      const q = QB.getTF(G.cfg.cats, [levelFor(m.i, total)]); const who = G.local ? rotateWho(m.i) : alive().map(s => s.id); m.i++;
      const T = Math.min(G.cfg.timer, 12);
      ask({
        kind: 'tf', q, who, time: T, title: `صح أم خطأ ${m.i}/${total}`, sub: G.local ? 'دور: ' + nameOf(who[0]) : '',
        score(res) { const d = {}; for (const s in res) { const r = res[s], sd = S(s); if (r.ok) { sd.streak = (sd.streak || 0) + 1; d[s] = Math.round(300 + 300 * (1 - r.t / (T * 1000))); } else { sd.streak = 0; d[s] = 0; } add(s, d[s]); } return d; },
        after: () => { if (m.i % 3 === 0) lb(() => M.tf.next()); else M.tf.next(); }, auto: 3000
      });
    }
  };
  M.order = {
    start() { G.m = { i: 0, n: Math.max(3, Math.ceil(G.cfg.n / 2)) }; this.next(); },
    next() {
      const m = G.m; const total = m.n * (G.local ? alive().length : 1); if (m.i >= total) return nextRound();
      const q = QB.getOrder(G.cfg.cats, G.cfg.levels); const who = G.local ? rotateWho(m.i) : alive().map(s => s.id); m.i++;
      const T = G.cfg.timer + 15;
      ask({
        kind: 'order', q, who, time: T, title: `رتّب ${m.i}/${total}`, sub: G.local ? 'دور: ' + nameOf(who[0]) : '',
        score(res) { const d = {}; for (const s in res) { const r = res[s]; d[s] = r.ok ? Math.round(600 + 400 * (1 - r.t / (T * 1000))) : (r.part || 0) * 100; add(s, d[s]); } return d; },
        after: () => lb(() => M.order.next()), auto: 6000
      });
    }
  };
  M.survival = {
    start() { G.m = { i: 0, lives: {}, out: [] }; alive().forEach(s => G.m.lives[s.id] = G.cfg.lives); this.next(); },
    left() { return alive().filter(s => !G.m.out.includes(s.id)); },
    next() {
      const m = G.m, L = this.left();
      const multi = alive().length > 1;
      if ((multi && L.length <= 1) || L.length === 0 || m.i >= 30) {
        L.forEach(s => add(s.id, 1000));
        G.d = {}; return lb(() => nextRound());
      }
      const step = Math.floor(m.i / (G.local ? 3 * L.length : 3));
      const Ls = G.cfg.levels.slice().sort(); const lv = Ls[Math.min(Ls.length - 1, step)];
      const q = QB.getMCQ(G.cfg.cats, [lv]);
      const who = G.local ? [L[m.i % L.length].id] : L.map(s => s.id); m.i++;
      ask({
        kind: 'mcq', q, who, time: G.cfg.timer, title: `الصمود — سؤال ${m.i}`, sub: who.length === 1 ? 'دور: ' + nameOf(who[0]) + ' — ❤️'.repeat(m.lives[who[0]]) : `الصامدون: ${L.length}`,
        score(res) { const d = {}; for (const s in res) { if (res[s].ok) { d[s] = 200 * lv; add(s, d[s]); } else { m.lives[s]--; d[s] = 0; if (m.lives[s] <= 0) m.out.push(s); } } return d; },
        after: () => M.survival.next(), auto: 4000
      });
      G.d.lives = m.lives; G.d.out = m.out; push();
    }
  };
  M.board = {
    start() {
      let cats = G.cfg.cats.filter(c => QB.mcq.some(q => q.c === c) || c === 'math');
      cats = QB.shuffle(cats).slice(0, 6);
      if (cats.length < 2) cats = QB.shuffle(QB.order.filter(c => QB.mcq.some(q => q.c === c))).slice(0, 6);
      const cells = []; let id = 0;
      cats.forEach((c, ci) => [1, 2, 3, 4].forEach(lv => { for (let k = 0; k < G.cfg.copies; k++) cells.push({ id: id++, ci, lv, v: BOARD_VALS[lv], used: false }); }));
      const helpers = {}; alive().forEach(s => helpers[s.id] = { call: 1, two: 1, hole: 1 });
      G.m = { cats, cells, turn: 0, helpers };
      this.pick();
    },
    turnSide() { const al = alive(); return al[G.m.turn % al.length].id; },
    pick() {
      clearT();
      if (G.m.cells.every(c => c.used)) return lb(() => nextRound());
      G.ph = 'pick';
      G.d = { cats: G.m.cats.map(c => ({ id: c, name: QB.cats[c].name, icon: QB.cats[c].icon })), cells: G.m.cells, turn: this.turnSide(), helpers: G.m.helpers, copies: G.cfg.copies };
      G._next = null; push();
    },
    open(cell) {
      cell.used = true;
      const cat = G.m.cats[cell.ci]; const side = this.turnSide();
      const q = QB.getMCQ([cat], [cell.lv]);
      G.m.cur = { cell, q, side, hole: false };
      const self = this;
      const al = alive(); const other = al.length > 1 ? al[(G.m.turn + 1) % al.length].id : null;
      ask({
        kind: 'mcq', q, who: [side], time: G.cfg.timer, title: `${QB.cats[cat].icon} ${QB.cats[cat].name} — ${cell.v}`, value: cell.v, openOk: true,
        helpers: { side, h: G.m.helpers[side] },
        decide(res) {
          if (res[side].ok || !other) return true;
          // فرصة السرقة: نخفي الخيار الخاطئ
          const hide = [res[side].ch, res[side].ch2].filter(x => x !== undefined);
          ask({
            kind: 'mcq', q, who: [other], time: Math.max(10, Math.round(G.cfg.timer * .6)), title: 'فرصة سرقة', sub: `${nameOf(side)} أخطأ — الفرصة لـ ${nameOf(other)}`, value: cell.v, hide,
            score(r2) { const d = { [side]: 0 }; if (r2[other].ok) { d[other] = cell.v; add(other, cell.v); } else d[other] = 0; return d; },
            after: () => self.nextTurn()
          });
          return false;
        },
        score(res) {
          const d = {};
          if (res[side].ok) {
            d[side] = cell.v; add(side, cell.v);
            if (G.m.cur.hole) { const opp = alive().filter(s => s.id !== side).sort((a, b) => b.score - a.score)[0]; if (opp) { add(opp.id, -cell.v); d[opp.id] = -cell.v; } }
          } else d[side] = 0;
          return d;
        },
        after: () => self.nextTurn()
      });
    },
    nextTurn() { G.m.turn++; this.pick(); },
    helper(side, h) {
      const hs = G.m.helpers[side]; if (!hs || !hs[h] || G.ph !== 'q' || !G.ask || !G.ask.who.includes(side)) return;
      hs[h] = 0;
      if (h === 'call') { const rem = Math.max(0, G.tEnd - now()); setT(rem + 30000, () => finishAsk()); G.d.msg = 'اتصال بصديق: أُضيفت 30 ثانية'; }
      if (h === 'two') { G.d.two = true; G.d.msg = 'جاوب جوابين: اختر إجابتين'; }
      if (h === 'hole') { G.m.cur.hole = true; G.d.msg = 'الحفرة: إن أصبت تُخصم القيمة من المتصدر'; }
      push();
    },
    // نمط الإجابة المفتوحة (الحكم يقرر)
    judge(a) {
      if (G.ph !== 'open') return;
      const cur = G.m.cur; const al = alive(); const other = al.length > 1 ? al[(G.m.turn + 1) % al.length].id : null;
      if (a.step === 'show') { G.d.step = 'shown'; G.d.answer = cur.q.a; clearT(); push(); return; }
      const fin = (deltas) => { G.ph = 'reveal'; G.d.kind = 'mcq'; G.d.ans = cur.q.ans; G.d.res = Object.keys(deltas).map(s => ({ s, ok: deltas[s] > 0, d: deltas[s] })); G._next = () => M.board.nextTurn(); push(); };
      if (G.d.step === 'shown' || G.d.step === 'ask') {
        if (a.ok) { add(cur.side, cur.cell.v); const d = { [cur.side]: cur.cell.v }; if (cur.hole) { const opp = al.filter(s => s.id !== cur.side).sort((x, y) => y.score - x.score)[0]; if (opp) { add(opp.id, -cur.cell.v); d[opp.id] = -cur.cell.v; } } fin(d); }
        else if (other) { G.d.step = 'steal'; G.d.stealer = other; G.d.answer = cur.q.a; push(); }
        else fin({ [cur.side]: 0 });
      } else if (G.d.step === 'steal') {
        if (a.ok) { add(other, cur.cell.v); fin({ [other]: cur.cell.v, [cur.side]: 0 }); } else fin({ [cur.side]: 0, [other]: 0 });
      }
    }
  };
  M.buzzer = {
    start() { G.m = { i: 0, n: G.cfg.n }; this.next(); },
    next() {
      const m = G.m; if (m.i >= m.n) return lb(() => nextRound());
      const lv = levelFor(m.i, m.n); const q = QB.getMCQ(G.cfg.cats, [lv]); m.i++;
      m.q = q; m.lv = lv; m.locked = [];
      G.ph = 'buzzq'; G.d = { text: q.q, c: q.c, l: q.l, title: `الجرس — سؤال ${m.i} من ${m.n}`, locked: [], value: lv * 100 };
      G._next = null;
      setT((G.cfg.timer + 5) * 1000, () => revealPlain(q, 'لم يضغط أحد الجرس!', () => M.buzzer.next()));
      push();
    },
    buzz(side) {
      const m = G.m; if (G.ph !== 'buzzq' || m.locked.includes(side)) return;
      const lv = m.lv, q = m.q;
      ask({
        kind: 'mcq', q, who: [side], time: Math.max(8, Math.round(G.cfg.timer * .6)), title: `${nameOf(side)} ضغط الجرس`, value: lv * 100, openOk: false,
        decide(res) {
          if (res[side].ok) return true;
          add(side, -lv * 50); m.locked.push(side);
          const rest = alive().filter(s => !m.locked.includes(s.id));
          if (rest.length) {
            G.ph = 'buzzq'; G.d = { text: q.q, c: q.c, l: q.l, title: 'إجابة خاطئة! الفرصة للباقين', locked: m.locked, value: lv * 100, wrong: side };
            setT(10000, () => revealPlain(q, 'انتهى الوقت', () => M.buzzer.next())); push(); return false;
          }
          return true;
        },
        score(res) { if (res[side].ok) { add(side, lv * 100); return { [side]: lv * 100 }; } return { [side]: -lv * 50 }; },
        after: () => M.buzzer.next(), auto: 4500
      });
    }
  };
  M.know = {
    start() { const q = []; for (let k = 0; k < G.cfg.knowTurns; k++) alive().forEach(s => q.push(s.id)); G.m = { queue: q, idx: 0 }; this.next(); },
    next() {
      const m = G.m; if (m.idx >= m.queue.length) return lb(() => nextRound());
      const side = m.queue[m.idx++]; const L = QB.getList(G.cfg.cats, G.cfg.levels, 6);
      m.cur = { side, L, found: [] };
      G.ph = 'kready'; G.d = { side, topic: L.t, total: L.items.length, c: L.c, l: L.l, title: `ماذا تعرف؟ ${m.idx}/${m.queue.length}`, time: G.cfg.knowTime };
      clearT(); G._next = () => M.know.go(); push();
    },
    go() { if (G.ph !== 'kready') return; G.ph = 'know'; G.d.found = []; G._next = null; setT(G.cfg.knowTime * 1000, () => M.know.end()); push(); },
    text(side, s) { const cur = G.m.cur; if (G.ph !== 'know' || side !== cur.side) return; tryItem(cur, s, side, 100); },
    manual(side) { const cur = G.m.cur; if (G.ph !== 'know') return; cur.found.push(-1); G.d.found.push('إجابة صحيحة (حَكَم)'); add(cur.side, 100); G.d.flash = 'ok'; G.d.fx = (G.d.fx || 0) + 1; push(); },
    end() { const cur = G.m.cur; clearT(); G.ph = 'kres'; G.d.missed = cur.L.items.filter((_, i) => !cur.found.includes(i)).map(x => x[0]).slice(0, 60); G.d.score = cur.found.length * 100; G._next = () => M.know.next(); push(); }
  };
  function tryItem(cur, s, side, pts) {
    const idx = cur.L.items.findIndex((al, i) => !cur.found.includes(i) && QB.match(s, al));
    if (idx >= 0) { cur.found.push(idx); G.d.found.push(cur.L.items[idx][0]); add(side, pts); G.d.flash = 'ok'; }
    else { const dup = cur.L.items.findIndex((al, i) => cur.found.includes(i) && QB.match(s, al)); G.d.flash = dup >= 0 ? 'dup' : 'bad'; G.d.lastBad = s; }
    G.d.fx = (G.d.fx || 0) + 1;
    push();
    return idx >= 0;
  }
  M.auction = {
    start() { G.m = { k: 0, rounds: Math.max(2, Math.min(4, alive().length * 2)), starter: 0 }; this.topic(); },
    topic() {
      const m = G.m; clearT();
      if (m.k >= m.rounds || alive().length < 1) return lb(() => nextRound());
      const L = QB.getList(G.cfg.cats, G.cfg.levels, 8); const al = alive();
      m.cur = { L, bid: 0, bidder: null, passed: [], turn: m.starter % al.length, found: [] };
      G.ph = 'bid'; G.d = { topic: L.t, total: L.items.length, c: L.c, l: L.l, bid: 0, bidder: null, turn: al[m.cur.turn].id, passed: [], title: `المزاد ${m.k + 1}/${m.rounds}` };
      G._next = null; push();
    },
    advance() {
      const cur = G.m.cur, al = alive();
      const live = al.filter(s => !cur.passed.includes(s.id));
      if (cur.bidder && live.length === 1 && live[0].id === cur.bidder) return this.prove();
      if (!cur.bidder && live.length === 0) { G.m.k++; G.m.starter++; return this.topic(); }
      if (al.length === 1 && cur.bidder) return this.prove();
      let t = cur.turn; for (let k = 0; k < al.length; k++) { t = (t + 1) % al.length; const id = al[t].id; if (!cur.passed.includes(id) && id !== cur.bidder) break; }
      cur.turn = t; G.d.turn = al[t].id; G.d.bid = cur.bid; G.d.bidder = cur.bidder; G.d.passed = cur.passed; push();
    },
    bid(side, n) { const cur = G.m.cur; if (G.ph !== 'bid' || G.d.turn !== side) return; n = Math.floor(+n); if (!(n > cur.bid) || n > cur.L.items.length) return; cur.bid = n; cur.bidder = side; this.advance(); },
    pass(side) { const cur = G.m.cur; if (G.ph !== 'bid' || G.d.turn !== side) return; cur.passed.push(side); this.advance(); },
    prove() {
      const cur = G.m.cur; const T = Math.min(120, Math.max(30, 15 + cur.bid * 5));
      G.ph = 'know'; G.d = { side: cur.bidder, topic: cur.L.t, total: cur.L.items.length, target: cur.bid, found: [], c: cur.L.c, l: cur.L.l, title: `${nameOf(cur.bidder)} يجب أن يذكر ${cur.bid}`, auction: true };
      setT(T * 1000, () => M.auction.end()); push();
    },
    text(side, s) { const cur = G.m.cur; if (G.ph !== 'know' || side !== cur.bidder) return; if (tryItem(cur, s, side, 0) && cur.found.length >= cur.bid) this.end(); },
    manual() { const cur = G.m.cur; if (G.ph !== 'know') return; cur.found.push(-1); G.d.found.push('إجابة صحيحة (حَكَم)'); G.d.flash = 'ok'; G.d.fx = (G.d.fx || 0) + 1; if (cur.found.length >= cur.bid) this.end(); else push(); },
    end() {
      const cur = G.m.cur; clearT(); const ok = cur.found.length >= cur.bid; const deltas = {};
      if (ok) { add(cur.bidder, cur.bid * 100); deltas[cur.bidder] = cur.bid * 100; }
      else { alive().filter(s => s.id !== cur.bidder).forEach(s => { add(s.id, cur.bid * 50); deltas[s.id] = cur.bid * 50; }); deltas[cur.bidder] = 0; }
      G.ph = 'kres'; G.d.auctionOk = ok; G.d.deltas = deltas; G.d.missed = cur.L.items.filter((_, i) => !cur.found.includes(i)).map(x => x[0]).slice(0, 60);
      G._next = () => { G.m.k++; G.m.starter++; M.auction.topic(); }; push();
    }
  };
  M.who = {
    start() { G.m = { i: 0, n: Math.max(3, Math.ceil(G.cfg.n / 2)) }; this.next(); },
    next() {
      const m = G.m; if (m.i >= m.n) return lb(() => nextRound());
      const w = QB.getWho(G.cfg.cats, G.cfg.levels); m.i++; m.w = w; m.shown = 1; m.locked = [];
      G.ph = 'who'; G.d = { clues: [w.clues[0]], total: w.clues.length, locked: [], buzzer: null, title: `من أنا؟ ${m.i}/${m.n}`, c: w.c, l: w.l, pts: 400 };
      G._next = null; this.tick(); push();
    },
    tick() {
      const m = G.m;
      setT(G.cfg.whoStep * 1000, () => {
        if (m.shown < m.w.clues.length) { m.shown++; G.d.clues = m.w.clues.slice(0, m.shown); m.locked = []; G.d.locked = []; G.d.pts = [400, 300, 200, 100][m.shown - 1] || 100; G.d.buzzer = null; this.tick(); push(); }
        else this.reveal(null, 0);
      });
    },
    buzz(side) { if (G.ph !== 'who' || G.m.locked.includes(side) || G.d.buzzer) return; G.d.buzzer = side; push(); },
    guess(side, s) {
      const m = G.m; if (G.ph !== 'who' || m.locked.includes(side)) return;
      if (G.local && G.d.buzzer !== side) return;
      if (QB.match(s, m.w.al)) { const pts = [400, 300, 200, 100][m.shown - 1] || 100; add(side, pts); this.reveal(side, pts); }
      else { m.locked.push(side); G.d.locked = m.locked.slice(); G.d.buzzer = null; G.d.wrong = { s: side, txt: s }; G.d.fx = (G.d.fx || 0) + 1; push(); }
    },
    giveup() { this.reveal(null, 0); },
    reveal(side, pts) { clearT(); const w = G.m.w; G.ph = 'reveal'; G.d = { kind: 'who', title: G.d.title, answer: w.a, clues: w.clues, res: side ? [{ s: side, ok: true, d: pts }] : [], c: w.c, l: w.l }; G._next = () => M.who.next(); push(); setT(6000, () => M.who.next()); }
  };
  M.final = {
    start() {
      G.m = { wagers: {}, qi: 0 };
      const al = alive(); const minS = Math.min(...al.map(s => s.score));
      G.m.last = al.filter(s => s.score === minS && al.length > 1).map(s => s.id);
      G.ph = 'wager'; G.d = { set: [], max: Object.fromEntries(al.map(s => [s.id, Math.max(500, s.score)])), last: G.m.last, title: 'جولة التعويض' };
      G._next = null; push();
    },
    wager(side, n) {
      if (G.ph !== 'wager' || G.m.wagers[side] !== undefined) return;
      const mx = G.d.max[side] || 500; n = Math.max(0, Math.min(mx, Math.floor(+n || 0)));
      G.m.wagers[side] = n; G.d.set.push(side);
      if (alive().every(s => G.m.wagers[s.id] !== undefined)) this.askNext(); else push();
    },
    askNext() {
      const al = alive(), m = G.m; const Ls = G.cfg.levels.slice().sort(); const lv = Ls[Ls.length - 1];
      if (G.local) { if (m.qi >= al.length) return nextRound(); }
      else if (m.qi >= 1) return nextRound();
      const who = G.local ? [al[m.qi].id] : al.map(s => s.id); m.qi++;
      const q = QB.getMCQ(G.cfg.cats, [lv]);
      ask({
        kind: 'mcq', q, who, time: G.cfg.timer + 10, title: 'سؤال التعويض', sub: who.length === 1 ? `${nameOf(who[0])} راهن بـ ${m.wagers[who[0]]}` : 'كل فريق على رهانه',
        score(res) { const d = {}; for (const s in res) { const w = m.wagers[s] || 0; d[s] = res[s].ok ? (m.last.includes(s) ? w * 2 : w) : -w; add(s, d[s]); } return d; },
        after: () => M.final.askNext()
      });
    }
  };

  // ---------- استقبال الأفعال ----------
  function act(pid, a) {
    if (!G) return;
    const p = G.players[pid]; let side = p ? p.side : null;
    if (G.local && a.as) side = a.as;
    const isHost = pid === G.hostPid || G.local;
    switch (a.type) {
      case 'next': if (isHost && G._next) { const f = G._next; G._next = null; clearT(); f(); } break;
      case 'answer': answer(side, pid, a); break;
      case 'cell': if (G.mode === 'board' && G.ph === 'pick' && (side === G.d.turn || isHost && G.local)) { const c = G.m.cells.find(x => x.id === a.id && !x.used); if (c) M.board.open(c); } break;
      case 'helper': if (G.mode === 'board') M.board.helper(side, a.h); break;
      case 'judge': if (isHost && G.mode === 'board') M.board.judge(a); break;
      case 'buzz': if (G.mode === 'buzzer') M.buzzer.buzz(side); else if (G.mode === 'who') M.who.buzz(side); break;
      case 'kgo': if (G.mode === 'know' && (side === G.d.side || isHost)) M.know.go(); break;
      case 'text': if (G.mode === 'know') M.know.text(side, a.s); else if (G.mode === 'auction') M.auction.text(side, a.s); else if (G.mode === 'who') M.who.guess(side, a.s); break;
      case 'manual': if (isHost) { if (G.mode === 'know') M.know.manual(); else if (G.mode === 'auction') M.auction.manual(); } break;
      case 'kend': if ((isHost || side === G.d.side) && G.ph === 'know') { if (G.mode === 'know') M.know.end(); else M.auction.end(); } break;
      case 'bid': if (G.mode === 'auction') M.auction.bid(side, a.n); break;
      case 'pass': if (G.mode === 'auction') M.auction.pass(side); break;
      case 'giveup': if (isHost && G.mode === 'who') M.who.giveup(); break;
      case 'wager': if (G.mode === 'final') M.final.wager(side, a.n); break;
      case 'skipround': if (isHost) nextRound(); break;
    }
  }
  function addPlayer(pid, pl, side) { if (!G) return; G.players[pid] = pl; if (side) G.sides.push({ ...side, score: 0, streak: 0, last: 0 }); push(); }
  function stop() { clearT(); G = null; }
  return { init, act, addPlayer, stop, get G() { return G; }, onState: null, M };
})();
