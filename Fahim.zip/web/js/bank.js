/* بنك الأسئلة: التحليل + المولّدات + الاختيار */
(function () {
  const QB = {
    cats: {}, mcq: [], who: [], lists: [], orders: [], gens: [],
    order: []
  };
  window.QB = QB;

  // ---------- أدوات ----------
  const rnd = (n) => Math.floor(Math.random() * n);
  const pick = (a) => a[rnd(a.length)];
  const shuffle = (a) => { a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = rnd(i + 1); [a[i], a[j]] = [a[j], a[i]]; } return a; };
  QB.rnd = rnd; QB.pick = pick; QB.shuffle = shuffle;

  function hash(s) { let h = 5381; for (let i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) | 0; return (h >>> 0).toString(36); }

  // تطبيع النص العربي للمقارنة
  QB.norm = function (s) {
    s = String(s || '').toLowerCase();
    s = s.replace(/[ً-ٰٟـ]/g, '');
    s = s.replace(/[أإآٱ]/g, 'ا').replace(/ة/g, 'ه').replace(/ى/g, 'ي').replace(/ؤ/g, 'و').replace(/ئ/g, 'ي');
    s = s.replace(/[^ء-يa-z0-9 ]/g, ' ');
    s = s.split(/\s+/).filter(Boolean).map(w => (w.length > 3 && w.startsWith('ال')) ? w.slice(2) : w).join('');
    return s;
  };
  function lev(a, b) {
    if (Math.abs(a.length - b.length) > 2) return 9;
    const d = Array.from({ length: a.length + 1 }, (_, i) => [i]);
    for (let j = 1; j <= b.length; j++) d[0][j] = j;
    for (let i = 1; i <= a.length; i++) for (let j = 1; j <= b.length; j++)
      d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
    return d[a.length][b.length];
  }
  // هل الإجابة المكتوبة تطابق أحد البدائل؟
  QB.match = function (input, aliases) {
    const x = QB.norm(input); if (!x) return false;
    for (const al of aliases) {
      const y = QB.norm(al); if (!y) continue;
      if (x === y) return true;
      const tol = y.length >= 8 ? 2 : (y.length >= 4 ? 1 : 0);
      if (tol && lev(x, y) <= tol) return true;
    }
    return false;
  };

  // ---------- الفئات ----------
  // group: للتنظيم في شاشة الاختيار
  QB.cat = function (id, name, icon, group) { QB.cats[id] = { id, name, icon, group, n: 0 }; QB.order.push(id); };

  // ---------- أسئلة مكتوبة ----------
  // الصيغة: مستوى|السؤال|الصحيح|خطأ1|خطأ2|خطأ3   (المستوى 1 سهل .. 4 شديد الصعوبة)
  QB.add = function (cat, text) {
    for (let line of text.split('\n')) {
      line = line.trim(); if (!line || line.startsWith('#')) continue;
      const p = line.split('|').map(s => s.trim());
      if (p.length < 4) continue;
      const l = +p[0] || 2;
      QB.mcq.push({ id: hash(cat + p[1]), c: cat, l, q: p[1], a: p[2], w: p.slice(3).filter(Boolean) });
    }
  };
  // من أنا: مستوى|الإجابة/بديل/بديل|تلميح1;تلميح2;تلميح3;تلميح4
  QB.addWho = function (cat, text) {
    for (let line of text.split('\n')) {
      line = line.trim(); if (!line || line.startsWith('#')) continue;
      const p = line.split('|').map(s => s.trim()); if (p.length < 3) continue;
      const al = p[1].split('/').map(s => s.trim());
      QB.who.push({ id: hash('w' + p[1]), c: cat, l: +p[0] || 2, a: al[0], al, clues: p[2].split(';').map(s => s.trim()).filter(Boolean) });
    }
  };
  // قوائم (ماذا تعرف/المزاد): مستوى|الموضوع|عنصر/بديل،عنصر،...
  QB.addList = function (cat, text) {
    for (let line of text.split('\n')) {
      line = line.trim(); if (!line || line.startsWith('#')) continue;
      const p = line.split('|').map(s => s.trim()); if (p.length < 3) continue;
      const items = p[2].split(/[،,]/).map(s => s.trim()).filter(Boolean).map(s => s.split('/').map(x => x.trim()));
      QB.lists.push({ id: hash('l' + p[1]), c: cat, l: +p[0] || 2, t: p[1], items });
    }
  };
  QB.addListRaw = function (cat, l, t, items) { QB.lists.push({ id: hash('l' + t), c: cat, l, t, items }); };
  // ترتيب: مستوى|السؤال|عنصر:قيمة،عنصر:قيمة ...  (يرتب تصاعدياً حسب القيمة)
  QB.addOrder = function (cat, text) {
    for (let line of text.split('\n')) {
      line = line.trim(); if (!line || line.startsWith('#')) continue;
      const p = line.split('|').map(s => s.trim()); if (p.length < 3) continue;
      const items = p[2].split('،').map(s => { const [k, v] = s.split(':'); return { k: k.trim(), v: parseFloat(v) }; });
      QB.orders.push({ id: hash('o' + p[1] + p[2]), c: cat, l: +p[0] || 2, q: p[1], items });
    }
  };
  // مصدر بيانات للترتيب المولّد: [{k, v}] مع عنوان
  QB.orderPools = [];
  QB.addOrderPool = function (cat, l, q, items, unit) { QB.orderPools.push({ c: cat, l, q, items, unit }); };

  // ---------- مولّد الأزواج ----------
  // كل سطر: مستوى|المفتاح|القيمة ؛ القوالب تستخدم {k} و {v}
  QB.addPairs = function (cat, fwd, rev, text, opts) {
    opts = opts || {};
    const rows = [];
    for (let line of text.split('\n')) {
      line = line.trim(); if (!line || line.startsWith('#')) continue;
      const p = line.split('|').map(s => s.trim()); if (p.length < 3) continue;
      rows.push({ l: +p[0] || 2, k: p[1], v: p[2] });
    }
    QB.addPairRows(cat, fwd, rev, rows, opts);
    return rows;
  };
  QB.addPairRows = function (cat, fwd, rev, rows, opts) {
    opts = opts || {};
    const vals = [...new Set(rows.map(r => r.v))], keys = [...new Set(rows.map(r => r.k))];
    for (const r of rows) {
      if (fwd) {
        const w = shuffle(vals.filter(v => v !== r.v)).slice(0, 3);
        if (w.length === 3) QB.mcq.push({ id: hash(cat + fwd + r.k), c: cat, l: Math.min(4, r.l + (opts.fl || 0)), q: fwd.replace('{k}', r.k), a: r.v, w, pool: vals, gen: 1 });
      }
      if (rev) {
        // السؤال العكسي فقط إذا القيمة فريدة
        if (rows.filter(x => x.v === r.v).length === 1) {
          const w = shuffle(keys.filter(k => k !== r.k)).slice(0, 3);
          if (w.length === 3) QB.mcq.push({ id: hash(cat + rev + r.v), c: cat, l: Math.min(4, r.l + (opts.rl || 0)), q: rev.replace('{v}', r.v), a: r.k, w, pool: keys, gen: 1 });
        }
      }
    }
  };

  // ---------- مولّد الرياضيات (لا نهائي) ----------
  QB.mathQ = function (l) {
    let q, a;
    if (l === 1) { const x = 2 + rnd(30), y = 2 + rnd(30); if (Math.random() < .5) { q = `${x} + ${y} = ؟`; a = x + y; } else { const m = Math.max(x, y), n = Math.min(x, y); q = `${m} − ${n} = ؟`; a = m - n; } }
    else if (l === 2) { const t = rnd(3); if (t === 0) { const x = 3 + rnd(10), y = 3 + rnd(10); q = `${x} × ${y} = ؟`; a = x * y; } else if (t === 1) { const y = 2 + rnd(9), a0 = 2 + rnd(12); q = `${a0 * y} ÷ ${y} = ؟`; a = a0; } else { const x = 10 + rnd(90), y = 10 + rnd(90), z = 2 + rnd(20); q = `${x} + ${y} − ${z} = ؟`; a = x + y - z; } }
    else if (l === 3) { const t = rnd(4); if (t === 0) { const x = 11 + rnd(15), y = 11 + rnd(15); q = `${x} × ${y} = ؟`; a = x * y; } else if (t === 1) { const p = pick([10, 20, 25, 50, 75, 15, 30]), b = pick([40, 60, 80, 120, 200, 240, 300, 400]); q = `كم يساوي ${p}% من ${b}؟`; a = p * b / 100; } else if (t === 2) { const x = 2 + rnd(9), y = 2 + rnd(9), z = 2 + rnd(9); q = `${x} + ${y} × ${z} = ؟`; a = x + y * z; } else { const n = 11 + rnd(14); q = `${n}² = ؟`; a = n * n; } }
    else { const t = rnd(4); if (t === 0) { const x = 2 + rnd(9), b = 3 + rnd(20), c = x * (2 + rnd(6)); const k = c / x; q = `إذا كان ${k}س + ${b} = ${c + b}، فما قيمة س؟`; a = x; } else if (t === 1) { const n = pick([2, 3]), e = n === 2 ? 5 + rnd(6) : 3 + rnd(3); q = `${n} أس ${e} = ؟`; a = Math.pow(n, e); } else if (t === 2) { const s = pick([4, 5, 6, 8, 10, 12]); q = `ما مجموع زوايا مضلع منتظم عدد أضلاعه ${s}؟`; a = (s - 2) * 180; } else { const x = 3 + rnd(7), y = 3 + rnd(7); q = `ما المضاعف المشترك الأصغر للعددين ${x} و ${y}؟`; a = lcm(x, y); } }
    const ws = new Set(); let tries = 0;
    while (ws.size < 3 && tries++ < 50) { const d = (rnd(2) ? 1 : -1) * (1 + rnd(Math.max(3, Math.round(Math.abs(a) * .15)))); const v = a + d; if (v !== a && v >= 0) ws.add(v); }
    while (ws.size < 3) ws.add(a + ws.size + 1);
    return { id: 'm' + q, c: 'math', l, q, a: String(a), w: [...ws].map(String), gen: 1 };
  };
  function gcd(a, b) { return b ? gcd(b, a % b) : a; } function lcm(a, b) { return a * b / gcd(a, b); }

  // ---------- صعوبة متكيفة حسب أداء اللاعبين ----------
  let st = {};
  try { st = JSON.parse(localStorage.getItem('qb_st') || '{}'); } catch (e) { st = {}; }
  QB.record = function (id, ok) { if (!id || String(id).startsWith('g') || String(id).startsWith('m')) return; const s = st[id] || [0, 0]; s[0]++; if (ok) s[1]++; st[id] = s; try { localStorage.setItem('qb_st', JSON.stringify(st)); } catch (e) { } };
  QB.rate = function (id) { const s = st[id]; return s && s[0] >= 3 ? Math.round(100 * s[1] / s[0]) : null; };
  QB.lvl = function (q) { const s = st[q.id]; if (s && s[0] >= 6) { const r = s[1] / s[0]; const e = r > .85 ? 1 : r > .6 ? 2 : r > .3 ? 3 : 4; return Math.round((e + q.l) / 2); } return q.l; };

  // ---------- الذاكرة: تجنب التكرار ----------
  let seen = {};
  try { seen = JSON.parse(localStorage.getItem('qb_seen') || '{}'); } catch (e) { seen = {}; }
  function markSeen(id) { seen[id] = 1; try { const ks = Object.keys(seen); if (ks.length > 20000) seen = {}; localStorage.setItem('qb_seen', JSON.stringify(seen)); } catch (e) { } }
  QB.markSeen = markSeen;
  QB.resetSeen = function () { seen = {}; try { localStorage.removeItem('qb_seen'); } catch (e) { } };

  const used = new Set(); // داخل الجلسة
  QB.newSession = function () { used.clear(); };

  function choose(pool, excludeFn) {
    let fresh = pool.filter(x => !used.has(x.id) && !seen[x.id] && (!excludeFn || excludeFn(x)));
    if (!fresh.length) fresh = pool.filter(x => !used.has(x.id) && (!excludeFn || excludeFn(x)));
    if (!fresh.length) fresh = pool;
    if (!fresh.length) return null;
    const x = pick(fresh); used.add(x.id); markSeen(x.id); return x;
  }

  // يحضر سؤال اختيار من متعدد جاهز للعرض
  QB.getMCQ = function (cats, levels, opt) {
    opt = opt || {};
    cats = cats && cats.length ? cats : QB.order;
    levels = levels && levels.length ? levels : [1, 2, 3, 4];
    // اختر فئة عشوائية أولاً لضمان التوازن بين الفئات
    const order = shuffle(cats);
    for (const c of order) {
      const lv = pick(levels);
      const hasGen = c === 'math' || (QB.generators && QB.generators[c]);
      let pool = QB.mcq.filter(q => q.c === c && QB.lvl(q) === lv);
      if (!pool.length) pool = QB.mcq.filter(q => q.c === c && levels.includes(QB.lvl(q)));
      if (!pool.length && !hasGen) continue;
      let q = null;
      const genRate = c === 'math' ? .75 : .3;
      if (hasGen && (!pool.length || Math.random() < genRate)) {
        q = (c === 'math' && Math.random() < .5) ? QB.mathQ(lv) : (QB.genQ(c, lv) || QB.mathQ(lv));
      } else q = choose(pool);
      if (q) return QB.present(q);
    }
    return QB.present(choose(QB.mcq) || QB.mathQ(2));
  };
  QB.present = function (q) {
    let w = q.w;
    if (q.pool && Math.random() < .7) w = shuffle(q.pool.filter(v => v !== q.a)).slice(0, 3); // تنويع المشتتات
    const opts = shuffle([q.a, ...w.slice(0, 3)]);
    return { id: q.id, c: q.c, l: q.l, q: q.q, opts, ans: opts.indexOf(q.a), a: q.a };
  };
  // صح أم خطأ: يعرض السؤال مع إجابة مقترحة
  QB.getTF = function (cats, levels) {
    const m = QB.getMCQ(cats, levels);
    const truth = Math.random() < .5;
    const shown = truth ? m.a : m.opts.filter((_, i) => i !== m.ans)[rnd(m.opts.length - 1)];
    return { id: m.id, c: m.c, l: m.l, q: m.q, shown, truth, a: m.a };
  };
  QB.getWho = function (cats, levels) {
    cats = cats && cats.length ? cats : QB.order;
    let pool = QB.who.filter(x => cats.includes(x.c) && (!levels || levels.includes(x.l)));
    if (pool.length < 3) pool = QB.who.filter(x => cats.includes(x.c));
    if (pool.length < 3) pool = QB.who;
    return choose(pool);
  };
  QB.getList = function (cats, levels, minItems) {
    cats = cats && cats.length ? cats : QB.order;
    minItems = minItems || 5;
    let pool = QB.lists.filter(x => cats.includes(x.c) && x.items.length >= minItems && (!levels || levels.includes(x.l)));
    if (pool.length < 2) pool = QB.lists.filter(x => cats.includes(x.c) && x.items.length >= minItems);
    if (pool.length < 2) pool = QB.lists.filter(x => x.items.length >= minItems);
    return choose(pool);
  };
  QB.getOrder = function (cats, levels) {
    cats = cats && cats.length ? cats : QB.order;
    const fixed = QB.orders.filter(x => cats.includes(x.c));
    const pools = QB.orderPools.filter(x => cats.includes(x.c));
    const usePool = pools.length && (!fixed.length || Math.random() < .6);
    let o;
    if (usePool) {
      const P = pick(pools);
      // اختر 4 عناصر بقيم مختلفة
      let items = []; let tries = 0;
      while (items.length < 4 && tries++ < 60) { const it = pick(P.items); if (!items.some(x => x.k === it.k || x.v === it.v)) items.push(it); }
      o = { id: 'op' + P.q + items.map(i => i.k).join(), c: P.c, l: P.l, q: P.q, items };
    } else {
      const all = fixed.length ? fixed : QB.orders;
      o = choose(all);
      if (!o) { const P = pick(QB.orderPools); return QB.getOrder([P.c]); }
      o = { ...o, items: shuffle(o.items).slice(0, 4) };
    }
    const correct = o.items.slice().sort((a, b) => a.v - b.v).map(i => i.k);
    return { id: o.id, c: o.c, l: o.l, q: o.q, shown: shuffle(o.items.map(i => i.k)), correct, vals: o.items };
  };

  QB.stats = function () {
    for (const id in QB.cats) QB.cats[id].n = 0;
    for (const q of QB.mcq) if (QB.cats[q.c]) QB.cats[q.c].n++;
    for (const q of QB.who) if (QB.cats[q.c]) QB.cats[q.c].n++;
    for (const q of QB.lists) if (QB.cats[q.c]) QB.cats[q.c].n++;
    return { mcq: QB.mcq.length, who: QB.who.length, lists: QB.lists.length, orders: QB.orders.length + QB.orderPools.length };
  };

  // أسئلة المستخدم المضافة
  QB.loadCustom = function () {
    try {
      const arr = JSON.parse(localStorage.getItem('qb_custom') || '[]');
      for (const q of arr) QB.mcq.push(q);
      return arr;
    } catch (e) { return []; }
  };
  QB.saveCustom = function (q) {
    let arr = []; try { arr = JSON.parse(localStorage.getItem('qb_custom') || '[]'); } catch (e) { }
    q.id = hash('u' + q.q + Date.now()); arr.push(q); QB.mcq.push(q);
    try { localStorage.setItem('qb_custom', JSON.stringify(arr)); } catch (e) { }
  };
})();
