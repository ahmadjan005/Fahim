// شعار فهيم (بومة بقبعة تخرج) + الأصوات
window.OWL = `<svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
<defs>
<radialGradient id="ob" cx="50%" cy="40%" r="60%"><stop offset="0" stop-color="#8b5cf6"/><stop offset="1" stop-color="#4c1d95"/></radialGradient>
<radialGradient id="obl" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#f5e9ff"/><stop offset="1" stop-color="#c4b5fd"/></radialGradient>
<linearGradient id="og" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffe27a"/><stop offset="1" stop-color="#ff9f1c"/></linearGradient>
</defs>
<ellipse cx="100" cy="186" rx="52" ry="8" fill="#000" opacity=".25"/>
<path d="M52 70 L40 38 L72 58 Z" fill="#5b21b6"/><path d="M148 70 L160 38 L128 58 Z" fill="#5b21b6"/>
<ellipse cx="100" cy="112" rx="62" ry="70" fill="url(#ob)"/>
<ellipse cx="100" cy="132" rx="38" ry="44" fill="url(#obl)"/>
<path d="M78 120 q6 6 12 0 M94 132 q6 6 12 0 M110 120 q6 6 12 0 M86 146 q6 6 12 0 M102 146 q6 6 12 0" stroke="#a78bfa" stroke-width="3" fill="none" stroke-linecap="round"/>
<circle cx="74" cy="88" r="26" fill="url(#og)"/><circle cx="126" cy="88" r="26" fill="url(#og)"/>
<circle cx="74" cy="88" r="19" fill="#fff"/><circle cx="126" cy="88" r="19" fill="#fff"/>
<circle cx="77" cy="90" r="10" fill="#1e1b4b"/><circle cx="123" cy="90" r="10" fill="#1e1b4b"/>
<circle cx="80" cy="86" r="3.5" fill="#fff"/><circle cx="126" cy="86" r="3.5" fill="#fff"/>
<path d="M92 104 L100 118 L108 104 Z" fill="#ff9f1c"/>
<path d="M40 128 q-14 22 4 40 q10-16 14-34z" fill="#5b21b6"/><path d="M160 128 q14 22 -4 40 q-10-16 -14-34z" fill="#5b21b6"/>
<path d="M82 178 l-6 8 M88 178 l0 9 M118 178 l6 8 M112 178 l0 9" stroke="#ff9f1c" stroke-width="4" stroke-linecap="round"/>
<g transform="translate(100 44) rotate(-6)"><path d="M-46 0 L0 -18 L46 0 L0 18 Z" fill="#1e1b4b"/><rect x="-24" y="2" width="48" height="16" rx="4" fill="#1e1b4b"/><path d="M30 2 q6 14 4 26" stroke="#ffc93c" stroke-width="3" fill="none"/><circle cx="34" cy="30" r="5" fill="#ffc93c"/></g>
<text x="100" y="168" font-size="20" text-anchor="middle" fill="#7c3aed" font-weight="900">؟</text>
</svg>`;

window.SFX = (function () {
  let ctx = null, on = true;
  try { on = localStorage.getItem('fahim_sound') !== '0'; } catch (e) { }
  function C() { if (!ctx) { try { ctx = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) { } } if (ctx && ctx.state === 'suspended') ctx.resume(); return ctx; }
  function tone(f, d, type, vol, when) {
    const c = C(); if (!c || !on) return;
    const t = c.currentTime + (when || 0);
    const o = c.createOscillator(), g = c.createGain();
    o.type = type || 'sine'; o.frequency.setValueAtTime(f, t);
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol || .2, t + .02); g.gain.exponentialRampToValueAtTime(0.0001, t + d);
    o.connect(g); g.connect(c.destination); o.start(t); o.stop(t + d + .05);
  }
  return {
    get on() { return on; }, set on(v) { on = v; try { localStorage.setItem('fahim_sound', v ? '1' : '0'); } catch (e) { } },
    unlock: C,
    ok() { [523, 659, 784, 1047].forEach((f, i) => tone(f, .18, 'triangle', .22, i * .08)); },
    bad() { tone(196, .25, 'sawtooth', .15); tone(147, .4, 'sawtooth', .15, .18); },
    tick() { tone(1200, .04, 'square', .05); },
    tock() { tone(800, .05, 'square', .07); },
    buzz() { tone(110, .35, 'square', .25); tone(220, .35, 'square', .12); },
    click() { tone(660, .05, 'triangle', .12); },
    reveal() { tone(392, .12, 'triangle', .15); tone(523, .2, 'triangle', .15, .1); },
    start() { [392, 523, 659, 784, 659, 784].forEach((f, i) => tone(f, .14, 'triangle', .2, i * .11)); },
    win() { [523, 523, 523, 659, 587, 523, 659, 784, 1047].forEach((f, i) => tone(f, .22, 'triangle', .22, i * .15)); },
    coin() { tone(988, .08, 'square', .1); tone(1319, .25, 'square', .1, .08); },
    whoosh() { const c = C(); if (!c || !on) return; const t = c.currentTime; const o = c.createOscillator(), g = c.createGain(); o.frequency.setValueAtTime(300, t); o.frequency.exponentialRampToValueAtTime(1200, t + .25); g.gain.setValueAtTime(.12, t); g.gain.exponentialRampToValueAtTime(.0001, t + .3); o.connect(g); g.connect(c.destination); o.start(t); o.stop(t + .32); }
  };
})();

window.confetti = function () {
  const cv = document.createElement('canvas'); cv.style.cssText = 'position:fixed;inset:0;pointer-events:none;z-index:50';
  cv.width = innerWidth; cv.height = innerHeight; document.body.appendChild(cv);
  const x = cv.getContext('2d'); const cols = ['#ffc93c', '#e21b3c', '#1368ce', '#26890c', '#a78bfa', '#fff'];
  const P = Array.from({ length: 160 }, () => ({ x: Math.random() * cv.width, y: -20 - Math.random() * cv.height * .5, vx: (Math.random() - .5) * 4, vy: 2 + Math.random() * 4, r: 4 + Math.random() * 6, c: cols[Math.random() * cols.length | 0], a: Math.random() * 6 }));
  let n = 0; (function f() { x.clearRect(0, 0, cv.width, cv.height); P.forEach(p => { p.x += p.vx; p.y += p.vy; p.a += .1; x.save(); x.translate(p.x, p.y); x.rotate(p.a); x.fillStyle = p.c; x.fillRect(-p.r / 2, -p.r / 2, p.r, p.r * .6); x.restore(); }); if (++n < 260) requestAnimationFrame(f); else cv.remove(); })();
};
