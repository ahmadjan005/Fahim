// شعار فهيم (بومة بقبعة تخرج) + الأصوات
window.OWL = `<svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
<defs>
<linearGradient id="gg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f6e7b0"/><stop offset=".45" stop-color="#d4af37"/><stop offset="1" stop-color="#8a6a1c"/></linearGradient>
<radialGradient id="gb" cx="50%" cy="40%" r="65%"><stop offset="0" stop-color="#1c2336"/><stop offset="1" stop-color="#0b0f1a"/></radialGradient>
</defs>
<g fill="none" stroke="url(#gg)" stroke-linejoin="round" stroke-linecap="round">
<path d="M100 8 L118 30 L146 26 L150 54 L176 66 L166 92 L184 114 L162 132 L166 160 L138 164 L124 190 L100 176 L76 190 L62 164 L34 160 L38 132 L16 114 L34 92 L24 66 L50 54 L54 26 L82 30 Z" stroke-width="2.2" fill="url(#gb)"/>
<path d="M100 22 L114 40 L136 37 L139 59 L160 69 L152 90 L166 108 L148 122 L151 145 L129 148 L118 168 L100 157 L82 168 L71 148 L49 145 L52 122 L34 108 L48 90 L40 69 L61 59 L64 37 L86 40 Z" stroke-width="1" opacity=".55"/>
<path d="M66 70 L80 86 M134 70 L120 86" stroke-width="4"/>
<path d="M62 64 Q100 52 138 64 Q150 98 132 128 Q118 148 100 152 Q82 148 68 128 Q50 98 62 64 Z" stroke-width="3.2"/>
<circle cx="83" cy="96" r="15" stroke-width="3.2"/><circle cx="117" cy="96" r="15" stroke-width="3.2"/>
<circle cx="83" cy="96" r="5.5" fill="#d4af37" stroke="none"/><circle cx="117" cy="96" r="5.5" fill="#d4af37" stroke="none"/>
<path d="M94 112 L100 124 L106 112" stroke-width="3"/>
<path d="M80 134 Q100 144 120 134 M86 140 Q100 148 114 140" stroke-width="1.6" opacity=".7"/>
</g></svg>`;
window.ICON = (function () {
  const w = (p, vb) => `<svg viewBox="${vb || '0 0 24 24'}" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">${p}</svg>`;
  return {
    local: w('<rect x="5" y="2.5" width="14" height="19" rx="2.5"/><path d="M9 6.5h6M10.5 18h3"/><circle cx="12" cy="12" r="2.5"/>'),
    host: w('<path d="M5 12a7 7 0 0 1 14 0M8 12a4 4 0 0 1 8 0"/><circle cx="12" cy="12" r="1.3" fill="currentColor"/><path d="M12 13.5V21M8.5 21h7"/>'),
    join: w('<circle cx="8" cy="15" r="4"/><path d="M11 12l9-9M17 6l3 3M14.5 8.5l2 2"/>'),
    practice: w('<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.5" fill="currentColor"/>'),
    bank: w('<path d="M4 5.5A2.5 2.5 0 0 1 6.5 3H20v15H6.5A2.5 2.5 0 0 0 4 20.5z"/><path d="M4 20.5A2.5 2.5 0 0 0 6.5 23H20v-5"/><path d="M9 8h7M9 11.5h5"/>'),
    help: w('<circle cx="12" cy="12" r="9"/><path d="M9.5 9.3a2.6 2.6 0 0 1 5 .9c0 1.8-2.5 2.2-2.5 4"/><circle cx="12" cy="17.2" r=".6" fill="currentColor"/>'),
    sound: w('<path d="M4 9.5h3.5L12 5v14l-4.5-4.5H4z"/><path d="M15.5 9a4.5 4.5 0 0 1 0 6M18 6.5a8 8 0 0 1 0 11"/>'),
    mute: w('<path d="M4 9.5h3.5L12 5v14l-4.5-4.5H4z"/><path d="M16 9.5l5 5M21 9.5l-5 5"/>'),
    back: w('<path d="M9 5l7 7-7 7"/>'),
    menu: w('<circle cx="12" cy="5" r="1.4" fill="currentColor"/><circle cx="12" cy="12" r="1.4" fill="currentColor"/><circle cx="12" cy="19" r="1.4" fill="currentColor"/>'),
    trophy: w('<path d="M7 4h10v4a5 5 0 0 1-10 0z"/><path d="M7 6H4a3 3 0 0 0 3 4M17 6h3a3 3 0 0 1-3 4M12 13v4M8.5 21h7M9.5 17h5v4h-5z"/>'),
    users: w('<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20a6.5 6.5 0 0 1 13 0"/><circle cx="17" cy="9" r="2.6"/><path d="M16 14.2a5 5 0 0 1 6 5.3"/>'),
    grid: w('<path d="M5 9h14M19 13.5H5"/>'),
    board: w('<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 9.5h18M3 15h18M9 4v16M15 4v16"/>'),
    kahoot: w('<path d="M13 2L4.5 13.5H11L10 22l8.5-11.5H12z"/>'),
    buzzer: w('<path d="M6 16v-5a6 6 0 0 1 12 0v5l1.5 2h-15z"/><path d="M10 21a2 2 0 0 0 4 0"/>'),
    know: w('<circle cx="12" cy="13.5" r="7.5"/><path d="M12 9.5v4l2.5 2M10 2.5h4M12 2.5V6"/>'),
    auction: w('<path d="M14.5 3.5l6 6M12 6l6 6M10.5 12.5l-7 7M8.5 7.5l8 8"/><path d="M3 21h9"/>'),
    who: w('<circle cx="12" cy="8.5" r="4.5"/><path d="M4 21a8 8 0 0 1 16 0"/><path d="M10.3 7.3a1.8 1.8 0 0 1 3.4.7c0 1.1-1.7 1.3-1.7 2.4"/>'),
    tf: w('<path d="M3.5 12.5l3.5 3.5 6-7"/><path d="M15 8l6 6M21 8l-6 6"/>'),
    order: w('<path d="M10 6h11M10 12h11M10 18h11"/><path d="M4 5l1.5-1v5M3.5 13.5a1.5 1.5 0 1 1 2.6 1L3.5 17h3"/>'),
    survival: w('<path d="M12 2.5l8 3v6c0 5-3.5 8.5-8 10-4.5-1.5-8-5-8-10v-6z"/><path d="M8.5 12l2.5 2.5 4.5-5"/>'),
    final: w('<ellipse cx="12" cy="6" rx="7" ry="3"/><path d="M5 6v4c0 1.7 3.1 3 7 3s7-1.3 7-3V6M5 10v4c0 1.7 3.1 3 7 3s7-1.3 7-3v-4M5 14v4c0 1.7 3.1 3 7 3s7-1.3 7-3v-4"/>'),
    plus: w('<path d="M12 5v14M5 12h14"/>'),
    close: w('<path d="M6 6l12 12M18 6L6 18"/>'),
    check: w('<path d="M4 12.5l5 5L20 6.5"/>'),
    x: w('<path d="M6 6l12 12M18 6L6 18"/>'),
    phone: w('<path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2z"/>'),
    two: w('<path d="M8 7v10M16 7v10M4 12h4M16 12h4"/>'),
    hole: w('<ellipse cx="12" cy="15" rx="8" ry="3.5"/><path d="M8 13.5c0-4 1.8-9 4-9s4 5 4 9"/>'),
    heart: w('<path d="M12 20s-7.5-4.5-7.5-10A4.3 4.3 0 0 1 12 7.5 4.3 4.3 0 0 1 19.5 10c0 5.5-7.5 10-7.5 10z" fill="currentColor"/>'),
    fire: w('<path d="M12 21c-3.9 0-6.5-2.6-6.5-6.2 0-3.9 3.3-5.7 3.9-9.3 2.6 1.5 3.9 3.6 3.9 5.7 1-.8 1.6-2 1.6-3.3 2.2 1.5 3.6 4.1 3.6 6.9 0 3.6-2.6 6.2-6.5 6.2z"/>')
  };
})();
window.GLYPHS = ['♛', '♞', '♜', '♝', '✦', '★', '◆', '✪', '☾', '⬢', '❖', '✧', '♠', '♣', '♥', '♦', '⚜', '☀', '⚡', '♚', '▲', '●', '■', '✵'];

window.SFX = (function () {
  let ctx = null, on = true;
  try { on = localStorage.getItem('fahim_sound') !== '0'; } catch (e) { }
  function C() { if (!ctx) { try { ctx = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) { } } if (ctx && ctx.state === 'suspended') ctx.resume(); return ctx; }
  function tone(f, d, type, vol, when) {
    const c = C(); if (!c || !on) return;
    const t = c.currentTime + (when || 0);
    const o = c.createOscillator(), g = c.createGain();
    o.type = type || 'sine'; o.frequency.setValueAtTime(f, t);
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol || .2, t + .02); g.gain.exponentialRampToValueAtTime(0.0001, t + d);
    o.connect(g); g.connect(c.destination); o.start(t); o.stop(t + d + .05);
  }
  return {
    get on() { return on; }, set on(v) { on = v; try { localStorage.setItem('fahim_sound', v ? '1' : '0'); } catch (e) { } },
    unlock: C,
    ok() { [523, 659, 784, 1047].forEach((f, i) => tone(f, .18, 'triangle', .22, i * .08)); },
    bad() { tone(196, .25, 'sawtooth', .15); tone(147, .4, 'sawtooth', .15, .18); },
    tick() { tone(1200, .04, 'square', .05); },
    tock() { tone(800, .05, 'square', .07); },
    buzz() { tone(110, .35, 'square', .25); tone(220, .35, 'square', .12); },
    click() { tone(660, .05, 'triangle', .12); },
    reveal() { tone(392, .12, 'triangle', .15); tone(523, .2, 'triangle', .15, .1); },
    start() { [392, 523, 659, 784, 659, 784].forEach((f, i) => tone(f, .14, 'triangle', .2, i * .11)); },
    win() { [523, 523, 523, 659, 587, 523, 659, 784, 1047].forEach((f, i) => tone(f, .22, 'triangle', .22, i * .15)); },
    coin() { tone(988, .08, 'square', .1); tone(1319, .25, 'square', .1, .08); },
    whoosh() { const c = C(); if (!c || !on) return; const t = c.currentTime; const o = c.createOscillator(), g = c.createGain(); o.frequency.setValueAtTime(300, t); o.frequency.exponentialRampToValueAtTime(1200, t + .25); g.gain.setValueAtTime(.12, t); g.gain.exponentialRampToValueAtTime(.0001, t + .3); o.connect(g); g.connect(c.destination); o.start(t); o.stop(t + .32); }
  };
})();

window.confetti = function () {
  const cv = document.createElement('canvas'); cv.style.cssText = 'position:fixed;inset:0;pointer-events:none;z-index:50';
  cv.width = innerWidth; cv.height = innerHeight; document.body.appendChild(cv);
  const x = cv.getContext('2d'); const cols = ['#f6e7b0', '#d4af37', '#b8902a', '#ffffff', '#e9d8a6', '#8a6a1c'];
  const P = Array.from({ length: 160 }, () => ({ x: Math.random() * cv.width, y: -20 - Math.random() * cv.height * .5, vx: (Math.random() - .5) * 4, vy: 2 + Math.random() * 4, r: 4 + Math.random() * 6, c: cols[Math.random() * cols.length | 0], a: Math.random() * 6 }));
  let n = 0; (function f() { x.clearRect(0, 0, cv.width, cv.height); P.forEach(p => { p.x += p.vx; p.y += p.vy; p.a += .1; x.save(); x.translate(p.x, p.y); x.rotate(p.a); x.fillStyle = p.c; x.fillRect(-p.r / 2, -p.r / 2, p.r, p.r * .6); x.restore(); }); if (++n < 260) requestAnimationFrame(f); else cv.remove(); })();
};
